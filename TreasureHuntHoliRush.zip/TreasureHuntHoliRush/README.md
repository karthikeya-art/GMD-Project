# TREASURE HUNT — HOLI RUSH

An original 3D three-lane endless runner set during a Holi festival. Everything (character, trains,
obstacles, collectibles, five festival zones, UI, particle effects and audio) is generated in code,
so the project contains no third-party or copyrighted assets.

## Quick start

1. Unity Hub → **Add project from disk** → select this `TreasureHuntHoliRush` folder.
   Recommended editor: **Unity 2022.3 LTS** (Unity 6 should also work; Hub will offer to upgrade).
2. Wait for the first import. If Unity asks to enable the new Input System backends, either answer works
   (the code supports both the old Input Manager and the Input System).
3. On first open, the editor tool runs automatically and creates `Assets/Scenes/HoliRush.unity`,
   materials, ~50 prefabs, lighting and build settings. If it does not run (or you want to rebuild),
   use the menu **Holi Rush → 1. Build Complete Game Setup**.
4. Press **Play**. (Even in an empty scene, `GameBootstrap` creates itself and builds the game.)

## Controls

| Action | PC | Mobile |
|---|---|---|
| Move left / right | ← → or A / D | swipe left / right |
| Jump | ↑, W or Space | swipe up |
| Slide (fast-fall in the air) | ↓ or S | swipe down |
| Pause / resume | Esc or P | pause button |
| Start / retry | Enter or Space | buttons |

## Gameplay

- **Zones:** Rang Nagar Junction (railway station), Gulal Gali (festival street with dancers and fountain),
  Saptarang Setu (bridge over a river), Abeer Bazaar (colour market with lanterns), and the rare
  Maha Holi Utsav grand celebration with continuous colour explosions. Zone names are fictional.
- **Obstacles:** static, ramp and moving "Rang Express" trains (run on their roofs!), wooden and
  construction barriers, powder barrels, rolling colour barrels (jump); low banners and flag arches (slide);
  festival carts, water tanks, barricades, stalls, barrel stacks and pole clusters (change lane).
- **Fairness:** a safe lane is planned for every obstacle row and moves at most one lane per row;
  only passable (jump/slide) obstacles may appear in it, and trains are only placed on stretches that are
  never the safe lane. Moving trains stop inside their reserved stretch.
- **Side bumps:** hitting the side of something bounces you back; two bumps within 3 s ends the run.
- **Collectibles:** coins, five colour tokens, gems, festival keys, treasure boxes, the rare golden colour
  token and the Lucky Color.
- **Power-ups:** Color Burst (instant pickup radius + bonus), Color Magnet, Water Shield (absorbs one hit),
  Rainbow Dash (faster, x2 score, smashes through obstacles), Festival Multiplier (x2).
- **Revive:** costs gems (1, then doubling each revive in a run); clears obstacles around and ahead of you
  and gives 2.5 s of invincibility. 3 starter gems are granted once so you can try it.
- Your hero's clothes get more colourful the further you run.

## Tuning

Select **GameBootstrap** in the scene; every number (speeds, power-up durations, revive cost, scores)
lives in its `Config` section.

## Project layout

```
Assets/
  Editor/            HoliRushSetup.cs (auto setup + validation), HoliRushBuild.cs (APK / Windows / .unitypackage)
  Scripts/
    GameManager/     GameBootstrap (builds & wires everything), GameManager, GameConfig
    Player/          PlayerController, PlayerVisual (procedural character + animation), CameraFollow
    TrackGeneration/ TrackGenerator (endless rows, safe-lane planner, recycling)
    Environment/     EnvironmentManager (5 zones), HoliFX (pooled gulal particles), Bobber
    Trains/          TrainController + TrainFactory
    Obstacles/       Obstacle, ObstacleSpawner, RollingBarrel
    Collectibles/    Collectible, CollectibleManager (central animation + magnet)
    PowerUps/        PowerUpManager
    UI/              UIManager (menu, HUD, pause, game over, settings - built in code)
    Audio/           AudioManager (all sounds synthesised at runtime)
    SaveSystem/      SaveManager (PlayerPrefs)
    Utilities/       ObjectPool, Palette, ShapeFactory (mesh baking), InputReader (keys + swipe)
  Scenes/ Prefabs/ Materials/ Models/ Textures/  ← filled by the setup tool
```

## Menu: Holi Rush

1. Build Complete Game Setup · 2. Open Game Scene · 3. Validate Project ·
4. Build Android APK · 5. Build Windows (PC) · 6. Export .unitypackage

Batch mode: `Unity -batchmode -quit -projectPath <path> -executeMethod HoliRush.EditorTools.HoliRushSetup.BatchSetup`
then `-executeMethod HoliRush.EditorTools.HoliRushBuild.BatchBuildAndroid`.

## Performance notes

Object pooling for every track piece, obstacle, collectible and particle burst; decoration and model
primitives are merged into one mesh per material; no real-time shadows (blob shadow instead);
one central Update animates all coins/dancers; capped particle counts; 60 FPS target.

## Using the .unitypackage instead

Import `TreasureHuntHoliRush.unitypackage` into a new 3D project (2022.3+). Also install
**Input System** from the Package Manager *only if* your project's Active Input Handling is set to
"Input System Package (New)". The setup tool then runs automatically.
