All game audio (dhol-inspired percussion loop, crowd ambience, coin/jump/slide/crash/power-up sounds)
is SYNTHESISED IN CODE at startup by Assets/Scripts/Audio/AudioManager.cs.
No audio files are required, so the game always runs with sound.
