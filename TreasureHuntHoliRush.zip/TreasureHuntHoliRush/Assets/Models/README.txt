All 3D models (player "Rangu", Rang Express trains, obstacles, collectibles, zones) are generated
procedurally from Unity primitives and merged into optimised meshes at runtime.
Running "Holi Rush > 1. Build Complete Game Setup" also saves those meshes here (Models/Generated)
so the prefabs in Assets/Prefabs can be inspected in the editor.
