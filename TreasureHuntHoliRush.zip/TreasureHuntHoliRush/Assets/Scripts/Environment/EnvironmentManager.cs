using System.Collections.Generic;
using UnityEngine;

namespace HoliRush
{
    public enum Zone { HoliStation = 0, ColorStreet = 1, HoliBridge = 2, ColorMarket = 3, GrandCelebration = 4 }

    /// <summary>
    /// Owns the five Holi zones: zone sequencing, floor pieces, side decorations,
    /// zone gates, distant scenery, fog/sky tint and the Grand Celebration fireworks of colour.
    /// </summary>
    public class EnvironmentManager : MonoBehaviour
    {
        public const int ZoneCount = 5;
        public const float DecorChunk = 20f;
        public static readonly string[] ZoneNames = { "RANG NAGAR JUNCTION", "GULAL GALI", "SAPTARANG SETU", "ABEER BAZAAR", "MAHA HOLI UTSAV" };

        static readonly Color[] SkyColors =
        {
            new Color(1f, 0.82f, 0.88f), new Color(1f, 0.88f, 0.75f), new Color(0.75f, 0.9f, 1f),
            new Color(1f, 0.85f, 0.7f), new Color(0.95f, 0.75f, 1f)
        };
        static readonly Color[] GroundColors =
        {
            new Color(0.62f, 0.6f, 0.62f), new Color(0.85f, 0.72f, 0.55f), new Color(0.72f, 0.4f, 0.3f),
            new Color(0.8f, 0.6f, 0.42f), new Color(0.7f, 0.35f, 0.6f)
        };

        ObjectPool pool;
        GameManager gm;
        Zone current = Zone.HoliStation;
        int remaining = 4;
        bool lastWasGrand;
        Transform horizon;
        float grandTimer;
        public Zone PlayerZone { get; set; }

        public void Init(GameManager g, ObjectPool p)
        {
            gm = g; pool = p;
            for (int z = 0; z < ZoneCount; z++)
            {
                int zz = z;
                pool.Register("floor_" + z, () => BuildFloor((Zone)zz));
                pool.Register("arch_" + z, () => BuildArch((Zone)zz));
                for (int v = 0; v < 2; v++)
                {
                    int vv = v;
                    pool.Register("decor_" + z + "_" + v, () => BuildDecor((Zone)zz, vv));
                }
            }
            BuildHorizon();
            ApplyAtmosphere(Zone.HoliStation, true);
        }

        public void ResetZones()
        {
            current = Zone.HoliStation; remaining = 4; lastWasGrand = false;
            PlayerZone = Zone.HoliStation;
            ApplyAtmosphere(Zone.HoliStation, true);
        }

        /// <summary>Zone for the next generated segment. Returns true if a new zone starts.</summary>
        public Zone NextSegmentZone(out bool newZone)
        {
            newZone = false;
            if (remaining <= 0)
            {
                Zone next;
                if (!lastWasGrand && current != Zone.GrandCelebration && Random.value < 0.2f) next = Zone.GrandCelebration;
                else
                {
                    do { next = (Zone)Random.Range(0, 4); } while (next == current);
                }
                lastWasGrand = next == Zone.GrandCelebration;
                current = next;
                remaining = next == Zone.GrandCelebration ? 2 : Random.Range(3, 6);
                newZone = true;
            }
            remaining--;
            return current;
        }

        /// <summary>Spawns floor + both sides of decoration for a segment.</summary>
        public void Decorate(Zone zone, float zStart, float length, bool newZone, List<GameObject> owned, Transform parent)
        {
            owned.Add(pool.Get("floor_" + (int)zone, new Vector3(0, 0, zStart), parent));
            if (newZone)
                owned.Add(pool.Get("arch_" + (int)zone, new Vector3(0, 0, zStart + 2f), parent));
            int chunks = Mathf.RoundToInt(length / DecorChunk);
            for (int i = 0; i < chunks; i++)
            {
                float z0 = zStart + i * DecorChunk;
                // right side
                var r = pool.Get("decor_" + (int)zone + "_" + Random.Range(0, 2), new Vector3(0, 0, z0), parent);
                r.transform.rotation = Quaternion.identity;
                owned.Add(r);
                // left side (same piece turned around)
                var l = pool.Get("decor_" + (int)zone + "_" + Random.Range(0, 2), new Vector3(0, 0, z0 + DecorChunk), parent);
                l.transform.rotation = Quaternion.Euler(0, 180f, 0);
                owned.Add(l);
            }
        }

        void Update()
        {
            float dt = Time.deltaTime;
            float t = Time.time;
            var list = Bobber.Active;
            for (int i = 0; i < list.Count; i++)
            {
                var b = list[i];
                var lp = b.transform.localPosition;
                lp.y = b.baseY + Mathf.Abs(Mathf.Sin(t * b.frequency + b.offset)) * b.amplitude;
                b.transform.localPosition = lp;
                if (b.sway != 0f) b.transform.localRotation = Quaternion.Euler(0, Mathf.Sin(t * b.frequency * 0.5f + b.offset) * b.sway * 3f, Mathf.Sin(t * b.frequency + b.offset) * b.sway);
            }
            if (gm == null || gm.Player == null) return;
            Vector3 pp = gm.Player.transform.position;
            if (horizon != null) horizon.position = new Vector3(0, 0, pp.z);
            ApplyAtmosphere(PlayerZone, false);

            if (PlayerZone == Zone.GrandCelebration && gm.State == GameState.Playing && HoliFX.Instance != null)
            {
                grandTimer -= dt;
                if (grandTimer <= 0f)
                {
                    grandTimer = Random.Range(0.35f, 0.8f);
                    float side = Random.value < 0.5f ? -1f : 1f;
                    HoliFX.Instance.Explosion(new Vector3(side * Random.Range(7f, 14f), Random.Range(3f, 9f), pp.z + Random.Range(20f, 60f)), Random.Range(1f, 1.8f));
                }
            }
        }

        void ApplyAtmosphere(Zone z, bool instant)
        {
            Color target = SkyColors[(int)z];
            Color c = instant ? target : Color.Lerp(RenderSettings.fogColor, target, 1f - Mathf.Exp(-1.5f * Time.deltaTime));
            RenderSettings.fogColor = c;
            if (Camera.main != null) Camera.main.backgroundColor = c;
        }

        // ================================================================== builders
        static Color Pastel(Color c) { return Color.Lerp(c, Color.white, 0.35f); }

        public GameObject BuildFloor(Zone zone)
        {
            float L = 60f;
            var root = ShapeFactory.Root("Floor_" + zone);
            var v = ShapeFactory.Root("V", root.transform).transform;
            Color g = GroundColors[(int)zone];
            float lw = 2.6f;
            bool bridge = zone == Zone.HoliBridge;

            // main slab
            ShapeFactory.Box(v, new Vector3(0, -0.35f, L / 2), new Vector3(9.6f, 0.6f, L), g * 0.85f);
            // tracks
            for (int lane = -1; lane <= 1; lane++)
            {
                float x = lane * lw;
                ShapeFactory.Box(v, new Vector3(x, -0.04f, L / 2), new Vector3(2.2f, 0.04f, L), new Color(0.45f, 0.4f, 0.38f));
                for (float z = 1f; z < L; z += 2.5f)
                    ShapeFactory.Box(v, new Vector3(x, 0.0f, z), new Vector3(2.0f, 0.06f, 0.45f), new Color(0.4f, 0.28f, 0.2f));
                ShapeFactory.Box(v, new Vector3(x - 0.6f, 0.08f, L / 2), new Vector3(0.1f, 0.12f, L), new Color(0.75f, 0.75f, 0.8f));
                ShapeFactory.Box(v, new Vector3(x + 0.6f, 0.08f, L / 2), new Vector3(0.1f, 0.12f, L), new Color(0.75f, 0.75f, 0.8f));
            }
            // gulal patches on the ground
            for (int i = 0; i < 18; i++)
            {
                float s = Random.Range(0.8f, 2.2f);
                ShapeFactory.Prim(PrimitiveType.Cylinder, v, new Vector3(Random.Range(-4.3f, 4.3f), 0.03f, Random.Range(1f, L - 1f)),
                                  new Vector3(s, 0.01f, s * Random.Range(0.6f, 1.2f)), Palette.Lit(Pastel(Palette.RandomPowder())));
            }

            if (bridge)
            {
                for (int s = -1; s <= 1; s += 2)
                {
                    ShapeFactory.Box(v, new Vector3(s * 4.9f, 1.0f, L / 2), new Vector3(0.2f, 0.15f, L), Palette.Yellow);
                    ShapeFactory.Box(v, new Vector3(s * 4.9f, -0.2f, L / 2), new Vector3(0.4f, 0.5f, L), Palette.Magenta);
                    for (float z = 1.5f; z < L; z += 3f)
                        ShapeFactory.Box(v, new Vector3(s * 4.9f, 0.45f, z), new Vector3(0.15f, 1.0f, 0.15f), Palette.Powder[(int)(z / 3f) % Palette.Powder.Length]);
                }
                for (float z = 10f; z < L; z += 20f)
                    for (int s = -1; s <= 1; s += 2)
                        ShapeFactory.Cyl(v, new Vector3(s * 3.2f, -4.5f, z), new Vector3(1.6f, 4.2f, 1.6f), new Color(0.75f, 0.55f, 0.5f));
                // water far below
                ShapeFactory.Prim(PrimitiveType.Cube, v, new Vector3(0, -8.5f, L / 2), new Vector3(240f, 0.2f, L), Palette.Lit(Palette.Water, 0.9f));
                for (int i = 0; i < 10; i++)
                    ShapeFactory.Prim(PrimitiveType.Sphere, v, new Vector3(Random.Range(-60f, 60f), -8.35f, Random.Range(0f, L)),
                                      new Vector3(Random.Range(3f, 8f), 0.05f, Random.Range(1f, 3f)), Palette.Lit(Pastel(Palette.RandomPowder())));
            }
            else
            {
                // walkway / platform strips and the wide ground on both sides
                float platH = zone == Zone.HoliStation ? 1.0f : 0.25f;
                for (int s = -1; s <= 1; s += 2)
                {
                    ShapeFactory.Box(v, new Vector3(s * 6.4f, platH / 2 - 0.05f, L / 2), new Vector3(3.2f, platH, L), Pastel(g));
                    ShapeFactory.Box(v, new Vector3(s * 4.95f, platH - 0.03f, L / 2), new Vector3(0.3f, 0.06f, L), Palette.Yellow);
                    ShapeFactory.Box(v, new Vector3(s * 28f, -0.1f, L / 2), new Vector3(40f, 0.1f, L), g);
                }
            }
            ShapeFactory.Bake(v.gameObject, root.transform);
            return root;
        }

        public GameObject BuildArch(Zone zone)
        {
            var root = ShapeFactory.Root("ZoneGate_" + zone);
            var v = ShapeFactory.Root("V", root.transform).transform;
            Color a = Palette.Powder[(int)zone * 2 % Palette.Powder.Length], b = Palette.Powder[((int)zone * 2 + 3) % Palette.Powder.Length];
            float baseY = zone == Zone.HoliBridge ? 0f : 0f;
            for (int s = -1; s <= 1; s += 2)
            {
                ShapeFactory.Box(v, new Vector3(s * 5.6f, baseY + 3.5f, 0), new Vector3(0.9f, 7f, 0.9f), a);
                ShapeFactory.Ball(v, new Vector3(s * 5.6f, baseY + 7.6f, 0), new Vector3(1.4f, 1.4f, 1.4f), b);
                ShapeFactory.Prim(PrimitiveType.Sphere, v, new Vector3(s * 5.6f, baseY + 8.5f, 0), Vector3.one * 0.5f, Palette.Glow(Palette.Gold));
            }
            ShapeFactory.Box(v, new Vector3(0, baseY + 7.0f, 0), new Vector3(12f, 1.5f, 0.6f), b);
            ShapeFactory.Box(v, new Vector3(0, baseY + 7.0f, -0.32f), new Vector3(10.8f, 1.1f, 0.05f), Palette.Cream);
            ShapeFactory.Bunting(v, new Vector3(-5.2f, baseY + 6.1f, -0.3f), new Vector3(5.2f, baseY + 6.1f, -0.3f), 14);
            for (int i = 0; i < 12; i++)
                ShapeFactory.Prim(PrimitiveType.Sphere, v, new Vector3(-5.5f + i, baseY + 7.85f, -0.3f), Vector3.one * 0.25f, Palette.Glow(Palette.Powder[i % Palette.Powder.Length]));
            ShapeFactory.Bake(v.gameObject, root.transform);

            // sign text (fictional festival names)
            var tgo = ShapeFactory.Root("Sign", root.transform);
            tgo.transform.localPosition = new Vector3(0, baseY + 7.0f, -0.4f);
            var tm = tgo.AddComponent<TextMesh>();
            var font = Palette.BuiltinFont();
            if (font != null)
            {
                tm.font = font;
                tgo.GetComponent<MeshRenderer>().sharedMaterial = font.material;
            }
            tm.text = ZoneNames[(int)zone];
            tm.anchor = TextAnchor.MiddleCenter;
            tm.alignment = TextAlignment.Center;
            tm.fontSize = 64;
            tm.characterSize = 0.07f;
            tm.color = Palette.Dark;
            return root;
        }

        GameObject Dancer(Transform parent, Vector3 pos)
        {
            var d = ShapeFactory.Root("Dancer", parent);
            d.transform.localPosition = pos;
            Color cloth = Palette.RandomPowder();
            ShapeFactory.Prim(PrimitiveType.Capsule, d.transform, new Vector3(0, 0.85f, 0), new Vector3(0.5f, 0.6f, 0.4f), Palette.Lit(cloth));
            ShapeFactory.Prim(PrimitiveType.Sphere, d.transform, new Vector3(0, 1.75f, 0), Vector3.one * 0.38f, Palette.Lit(Palette.Skin));
            ShapeFactory.Prim(PrimitiveType.Sphere, d.transform, new Vector3(0, 1.85f, 0), new Vector3(0.4f, 0.25f, 0.4f), Palette.Lit(Palette.Dark));
            ShapeFactory.Prim(PrimitiveType.Capsule, d.transform, new Vector3(-0.35f, 1.5f, 0), new Vector3(0.12f, 0.35f, 0.12f), Palette.Lit(Palette.Skin), new Vector3(0, 0, -150));
            ShapeFactory.Prim(PrimitiveType.Capsule, d.transform, new Vector3(0.35f, 1.5f, 0), new Vector3(0.12f, 0.35f, 0.12f), Palette.Lit(Palette.Skin), new Vector3(0, 0, 150));
            ShapeFactory.Splashes(d.transform, new Vector3(0, 1.1f, 0), new Vector3(0.2f, 0.4f, 0.2f), 3, 0.2f);
            var b = d.AddComponent<Bobber>();
            b.amplitude = 0.3f; b.frequency = Random.Range(4f, 6f); b.sway = 8f;
            return d;
        }

        GameObject Lantern(Transform parent, Vector3 pos, Color c)
        {
            var l = ShapeFactory.Root("Lantern", parent);
            l.transform.localPosition = pos;
            ShapeFactory.Prim(PrimitiveType.Sphere, l.transform, Vector3.zero, new Vector3(0.6f, 0.75f, 0.6f), Palette.Glow(c));
            ShapeFactory.Prim(PrimitiveType.Cylinder, l.transform, new Vector3(0, -0.42f, 0), new Vector3(0.3f, 0.05f, 0.3f), Palette.Lit(Palette.Gold));
            var b = l.AddComponent<Bobber>();
            b.amplitude = 0.5f; b.frequency = Random.Range(0.6f, 1.2f); b.sway = 4f;
            return l;
        }

        /// <summary>Right-hand side decoration chunk (x &gt; 0, z 0..20). Left side is the same piece rotated 180 degrees.</summary>
        public GameObject BuildDecor(Zone zone, int variant)
        {
            var root = ShapeFactory.Root("Decor_" + zone + "_" + variant);
            var v = ShapeFactory.Root("V", root.transform).transform;
            float L = DecorChunk;
            switch (zone)
            {
                case Zone.HoliStation:
                {
                    // platform canopy, pillars, benches, colour-covered wall
                    for (int i = 0; i < 2; i++)
                    {
                        float z = 5f + i * 10f;
                        ShapeFactory.Cyl(v, new Vector3(7.0f, 2.6f, z), new Vector3(0.3f, 1.6f, 0.3f), Palette.Cream);
                        ShapeFactory.Box(v, new Vector3(6.2f, 1.25f, z + 2.5f), new Vector3(0.6f, 0.45f, 1.8f), Palette.Wood);
                    }
                    for (int i = 0; i < 5; i++)
                        ShapeFactory.Box(v, new Vector3(6.4f, 4.3f + (i % 2) * 0.05f, i * 4f + 2f), new Vector3(3.4f, 0.2f, 4f), i % 2 == 0 ? Palette.Magenta : Palette.Yellow);
                    ShapeFactory.Box(v, new Vector3(9.2f, 3.0f, L / 2), new Vector3(0.6f, 6f, L), Palette.Stone);
                    ShapeFactory.Splashes(v, new Vector3(8.85f, 3f, L / 2), new Vector3(0.1f, 2.5f, L / 2), 22, 1.2f);
                    ShapeFactory.Bunting(v, new Vector3(5.2f, 3.9f, 0.2f), new Vector3(5.2f, 3.9f, L - 0.2f), 14);
                    if (variant == 1)
                    {
                        // ticket booth + clock
                        ShapeFactory.Box(v, new Vector3(7.3f, 2.4f, 10f), new Vector3(2f, 2.8f, 2.4f), Palette.Cyan);
                        ShapeFactory.Box(v, new Vector3(6.28f, 2.6f, 10f), new Vector3(0.05f, 1.0f, 1.6f), Palette.Dark);
                        ShapeFactory.Cyl(v, new Vector3(6.3f, 3.6f, 15f), new Vector3(0.9f, 0.05f, 0.9f), Palette.Cream, new Vector3(0, 0, 90));
                    }
                    else ShapeFactory.Rangoli(v, new Vector3(7.0f, 1.01f, 10f), 1.0f);
                    break;
                }
                case Zone.ColorStreet:
                {
                    float z = 0.5f;
                    int n = 0;
                    while (z < L - 2f)
                    {
                        float w = Random.Range(6f, 9f);
                        w = Mathf.Min(w, L - z - 0.5f);
                        float h = Random.Range(6f, 12f);
                        Color c = Pastel(Palette.Powder[(n + variant * 3) % Palette.Powder.Length]);
                        ShapeFactory.Box(v, new Vector3(11.5f, h / 2, z + w / 2), new Vector3(5f, h, w), c);
                        for (float wy = 2.5f; wy < h - 1f; wy += 2.5f)
                            for (float wz = z + 1.2f; wz < z + w - 0.8f; wz += 2f)
                            {
                                ShapeFactory.Box(v, new Vector3(8.98f, wy, wz), new Vector3(0.06f, 1.2f, 0.9f), new Color(0.25f, 0.2f, 0.35f));
                                ShapeFactory.Box(v, new Vector3(8.9f, wy - 0.7f, wz), new Vector3(0.3f, 0.12f, 1.1f), Palette.Cream);
                            }
                        // balcony + chhatri dome
                        ShapeFactory.Box(v, new Vector3(8.6f, h * 0.55f, z + w / 2), new Vector3(0.9f, 0.15f, w * 0.6f), Palette.Wood);
                        ShapeFactory.Ball(v, new Vector3(11.5f, h + 0.6f, z + w / 2), new Vector3(2.2f, 1.6f, 2.2f), Palette.Powder[(n + 2) % Palette.Powder.Length]);
                        ShapeFactory.Splashes(v, new Vector3(8.95f, h * 0.4f, z + w / 2), new Vector3(0.05f, h * 0.35f, w * 0.4f), 6, 0.9f);
                        z += w + 0.4f; n++;
                    }
                    ShapeFactory.Bunting(v, new Vector3(8.8f, 5.5f, 1f), new Vector3(8.8f, 5.5f, L - 1f), 12);
                    if (variant == 0)
                    {
                        // colour fountain
                        ShapeFactory.Cyl(v, new Vector3(6.6f, 0.5f, 10f), new Vector3(2.2f, 0.25f, 2.2f), Palette.Stone);
                        ShapeFactory.Cyl(v, new Vector3(6.6f, 0.78f, 10f), new Vector3(1.9f, 0.03f, 1.9f), Palette.Cyan);
                        ShapeFactory.Cyl(v, new Vector3(6.6f, 1.5f, 10f), new Vector3(0.3f, 0.8f, 0.3f), Palette.Stone);
                        ShapeFactory.Ball(v, new Vector3(6.6f, 2.4f, 10f), new Vector3(1.1f, 0.5f, 1.1f), Palette.Pink);
                    }
                    ShapeFactory.Bake(v.gameObject, root.transform);
                    Dancer(root.transform, new Vector3(6.4f, 0.2f, 4f + variant * 3f));
                    Dancer(root.transform, new Vector3(7.2f, 0.2f, 15f));
                    return root;
                }
                case Zone.HoliBridge:
                {
                    for (int i = 0; i < 2; i++)
                    {
                        float z = 4f + i * 10f;
                        ShapeFactory.Cyl(v, new Vector3(5.3f, 2.5f, z), new Vector3(0.18f, 2.5f, 0.18f), Palette.Dark);
                        ShapeFactory.Prim(PrimitiveType.Sphere, v, new Vector3(5.3f, 5.1f, z), Vector3.one * 0.55f, Palette.Glow(Palette.Yellow));
                        ShapeFactory.Box(v, new Vector3(5.35f, 3.3f, z + 0.6f), new Vector3(0.05f, 2.2f, 1.0f), Palette.Powder[(i + variant * 2) % Palette.Powder.Length]);
                    }
                    // distant boats & islands on the river
                    for (int i = 0; i < 2; i++)
                    {
                        float bx = Random.Range(25f, 70f), bz = Random.Range(0f, L);
                        ShapeFactory.Ball(v, new Vector3(bx, -8.2f, bz), new Vector3(3f, 0.8f, 7f), Palette.Wood);
                        ShapeFactory.Box(v, new Vector3(bx, -6.6f, bz), new Vector3(0.1f, 3f, 0.1f), Palette.Dark);
                        ShapeFactory.Box(v, new Vector3(bx + 0.2f, -6.2f, bz), new Vector3(0.05f, 2f, 2.2f), Palette.RandomPowder());
                    }
                    if (variant == 1)
                        ShapeFactory.Ball(v, new Vector3(Random.Range(40f, 80f), -8.5f, 10f), new Vector3(24f, 6f, 16f), new Color(0.4f, 0.75f, 0.4f));
                    break;
                }
                case Zone.ColorMarket:
                {
                    for (int i = 0; i < 3; i++)
                    {
                        float z = 3.5f + i * 6.5f;
                        Color c = Palette.Powder[(i + variant * 3) % Palette.Powder.Length];
                        ShapeFactory.Box(v, new Vector3(7.0f, 0.75f, z), new Vector3(2.0f, 1.0f, 3.5f), Palette.Wood);
                        // heaps of gulal in bowls
                        for (int k = 0; k < 3; k++)
                        {
                            ShapeFactory.Cyl(v, new Vector3(6.6f, 1.3f, z - 1.1f + k * 1.1f), new Vector3(0.8f, 0.08f, 0.8f), Palette.Cream);
                            ShapeFactory.Ball(v, new Vector3(6.6f, 1.45f, z - 1.1f + k * 1.1f), new Vector3(0.7f, 0.55f, 0.7f), Palette.Powder[(i * 3 + k) % Palette.Powder.Length]);
                        }
                        // umbrella
                        ShapeFactory.Cyl(v, new Vector3(7.6f, 2.3f, z), new Vector3(0.1f, 1.5f, 0.1f), Palette.Dark);
                        ShapeFactory.Ball(v, new Vector3(7.6f, 3.8f, z), new Vector3(3.6f, 0.9f, 3.6f), c);
                        ShapeFactory.Ball(v, new Vector3(7.6f, 3.95f, z), new Vector3(1.0f, 0.5f, 1.0f), Palette.Cream);
                        // hanging fabrics
                        ShapeFactory.Box(v, new Vector3(8.8f, 2.3f, z), new Vector3(0.05f, 2.4f, 1.6f), Palette.Powder[(i + 5) % Palette.Powder.Length]);
                    }
                    ShapeFactory.Box(v, new Vector3(10.5f, 2.5f, L / 2), new Vector3(1f, 5f, L), Pastel(Palette.Orange));
                    ShapeFactory.Splashes(v, new Vector3(9.95f, 2.5f, L / 2), new Vector3(0.05f, 2f, L / 2), 14, 1f);
                    ShapeFactory.Bake(v.gameObject, root.transform);
                    for (int i = 0; i < 3; i++)
                        Lantern(root.transform, new Vector3(Random.Range(5.5f, 9f), Random.Range(5f, 8f), Random.Range(1f, L - 1f)), Palette.RandomPowder());
                    return root;
                }
                case Zone.GrandCelebration:
                {
                    // giant stacked colour towers with lights
                    float z0 = variant == 0 ? 6f : 12f;
                    for (int k = 0; k < 5; k++)
                        ShapeFactory.Cyl(v, new Vector3(12f, 1.5f + k * 3f, z0), new Vector3(4f - k * 0.6f, 1.5f, 4f - k * 0.6f), Palette.Powder[(k + variant) % Palette.Powder.Length]);
                    for (int k = 0; k < 10; k++)
                        ShapeFactory.Prim(PrimitiveType.Sphere, v, new Vector3(12f + Mathf.Cos(k) * 2.2f, 1f + k * 1.4f, z0 + Mathf.Sin(k) * 2.2f), Vector3.one * 0.35f, Palette.Glow(Palette.Powder[k % 8]));
                    // stage with dhol drums
                    ShapeFactory.Box(v, new Vector3(8.5f, 0.6f, 16f), new Vector3(5f, 1.2f, 6f), Palette.Purple);
                    for (int k = 0; k < 3; k++)
                        ShapeFactory.Cyl(v, new Vector3(7.5f + k * 1.2f, 1.7f, 16f), new Vector3(0.7f, 0.5f, 0.7f), Palette.Red, new Vector3(90, 0, 0));
                    ShapeFactory.Rangoli(v, new Vector3(7.5f, 0.05f, variant == 0 ? 15f : 4f), 1.6f);
                    ShapeFactory.Bunting(v, new Vector3(5.5f, 6f, 0f), new Vector3(5.5f, 6f, L), 16);
                    ShapeFactory.Bake(v.gameObject, root.transform);
                    Dancer(root.transform, new Vector3(6.2f, 0.2f, 3f));
                    Dancer(root.transform, new Vector3(7.4f, 0.2f, 8f));
                    Dancer(root.transform, new Vector3(8.0f, 1.2f, 15f));
                    Lantern(root.transform, new Vector3(6.5f, 7.5f, 10f), Palette.Gold);
                    return root;
                }
            }
            ShapeFactory.Bake(v.gameObject, root.transform);
            return root;
        }

        void BuildHorizon()
        {
            horizon = ShapeFactory.Root("Horizon", transform).transform;
            var v = ShapeFactory.Root("V", horizon).transform;
            // rolling hills and skyline far away (inside fog for a soft pastel look)
            for (int i = 0; i < 14; i++)
            {
                float side = i % 2 == 0 ? -1f : 1f;
                ShapeFactory.Ball(v, new Vector3(side * Random.Range(60f, 120f), -6f, Random.Range(60f, 260f)),
                                  new Vector3(Random.Range(50f, 90f), Random.Range(20f, 45f), Random.Range(40f, 70f)),
                                  Pastel(Palette.Powder[i % Palette.Powder.Length]));
            }
            for (int i = 0; i < 6; i++)
                ShapeFactory.Box(v, new Vector3(Random.Range(-60f, 60f), 10f, Random.Range(230f, 290f)),
                                 new Vector3(Random.Range(10f, 25f), Random.Range(20f, 40f), 10f), Pastel(Palette.Purple));
            ShapeFactory.Prim(PrimitiveType.Sphere, v, new Vector3(-40f, 70f, 300f), Vector3.one * 30f, Palette.Glow(new Color(1f, 0.85f, 0.4f)));
            ShapeFactory.Bake(v.gameObject, horizon);
        }
    }
}
