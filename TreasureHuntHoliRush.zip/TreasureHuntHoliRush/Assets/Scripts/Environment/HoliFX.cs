using UnityEngine;

namespace HoliRush
{
    /// <summary>
    /// Pooled, mobile-friendly gulal powder effects. A small fixed set of ParticleSystems is
    /// reused for every burst (no Instantiate during play), plus one ambient floating-powder system.
    /// </summary>
    public class HoliFX : MonoBehaviour
    {
        public static HoliFX Instance { get; private set; }

        const int BurstSystems = 6;
        const int MaxPerSystem = 160;
        ParticleSystem[] bursts;
        int next;
        ParticleSystem ambient;

        void Awake()
        {
            Instance = this;
            bursts = new ParticleSystem[BurstSystems];
            for (int i = 0; i < BurstSystems; i++) bursts[i] = CreateBurstSystem("PowderBurst_" + i);
        }

        ParticleSystem CreateBurstSystem(string name)
        {
            var go = new GameObject(name);
            go.transform.SetParent(transform, false);
            var ps = go.AddComponent<ParticleSystem>();
            ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            var main = ps.main;
            main.playOnAwake = false;
            main.loop = false;
            main.duration = 1f;
            main.maxParticles = MaxPerSystem;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            main.startLifetime = new ParticleSystem.MinMaxCurve(0.6f, 1.2f);
            main.startSpeed = new ParticleSystem.MinMaxCurve(3f, 9f);
            main.startSize = new ParticleSystem.MinMaxCurve(0.4f, 1.1f);
            main.gravityModifier = 0.35f;
            var em = ps.emission; em.enabled = true; em.rateOverTime = 0f;
            var sh = ps.shape; sh.enabled = true; sh.shapeType = ParticleSystemShapeType.Sphere; sh.radius = 0.4f;
            var col = ps.colorOverLifetime; col.enabled = true;
            var g = new Gradient();
            g.SetKeys(new[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.white, 1f) },
                      new[] { new GradientAlphaKey(0.95f, 0f), new GradientAlphaKey(0.7f, 0.5f), new GradientAlphaKey(0f, 1f) });
            col.color = new ParticleSystem.MinMaxGradient(g);
            var size = ps.sizeOverLifetime; size.enabled = true;
            size.size = new ParticleSystem.MinMaxCurve(1f, AnimationCurve.EaseInOut(0f, 0.6f, 1f, 1.8f));
            var limit = ps.limitVelocityOverLifetime; limit.enabled = true; limit.limit = 3f; limit.dampen = 0.15f;
            var r = go.GetComponent<ParticleSystemRenderer>();
            r.sharedMaterial = Palette.Particle();
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            r.receiveShadows = false;
            ps.Play();
            return ps;
        }

        /// <summary>Single-colour gulal burst.</summary>
        public void Burst(Vector3 pos, Color color, int count = 25, float speedScale = 1f)
        {
            var ps = bursts[next];
            next = (next + 1) % bursts.Length;
            var ep = new ParticleSystem.EmitParams();
            ep.applyShapeToPosition = true;
            for (int i = 0; i < count; i++)
            {
                ep.position = pos;
                Color c = Color.Lerp(color, Color.white, Random.Range(0f, 0.25f));
                ep.startColor = c;
                ep.velocity = Random.onUnitSphere * Random.Range(2.5f, 8f) * speedScale + Vector3.up * 2f;
                ep.startSize = Random.Range(0.35f, 1.0f) * Mathf.Sqrt(speedScale);
                ep.startLifetime = Random.Range(0.6f, 1.2f);
                ps.Emit(ep, 1);
            }
            if (!ps.isPlaying) ps.Play();
        }

        /// <summary>Multi-colour Holi explosion (Color Burst, Lucky Color, celebration zone).</summary>
        public void Explosion(Vector3 pos, float scale = 1f)
        {
            for (int i = 0; i < 4; i++)
                Burst(pos + Random.insideUnitSphere * scale, Palette.Powder[Random.Range(0, Palette.Powder.Length)],
                      Mathf.RoundToInt(28 * Mathf.Clamp(scale, 0.5f, 1.6f)), 1.3f * scale);
        }

        /// <summary>Floating powder that drifts across the screen in front of the camera.</summary>
        public void CreateAmbient(Transform follow)
        {
            var go = new GameObject("AmbientGulal");
            go.transform.SetParent(follow, false);
            go.transform.localPosition = new Vector3(0, 2f, 22f);
            ambient = go.AddComponent<ParticleSystem>();
            ambient.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            var main = ambient.main;
            main.loop = true;
            main.playOnAwake = false;
            main.maxParticles = 60;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            main.startLifetime = 5f;
            main.startSpeed = 0.4f;
            main.startSize = new ParticleSystem.MinMaxCurve(0.3f, 1.2f);
            var colors = new Gradient();
            var keys = new GradientColorKey[Palette.Powder.Length > 8 ? 8 : Palette.Powder.Length];
            for (int i = 0; i < keys.Length; i++) keys[i] = new GradientColorKey(Palette.Powder[i], i / (float)(keys.Length - 1));
            colors.SetKeys(keys, new[] { new GradientAlphaKey(0.55f, 0f), new GradientAlphaKey(0.55f, 1f) });
            main.startColor = new ParticleSystem.MinMaxGradient(colors) { mode = ParticleSystemGradientMode.RandomColor };
            var em = ambient.emission; em.rateOverTime = 10f;
            var sh = ambient.shape; sh.shapeType = ParticleSystemShapeType.Box; sh.scale = new Vector3(26f, 8f, 30f);
            var col = ambient.colorOverLifetime; col.enabled = true;
            var g = new Gradient();
            g.SetKeys(new[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.white, 1f) },
                      new[] { new GradientAlphaKey(0f, 0f), new GradientAlphaKey(0.8f, 0.25f), new GradientAlphaKey(0f, 1f) });
            col.color = new ParticleSystem.MinMaxGradient(g);
            var noise = ambient.noise; noise.enabled = true; noise.strength = 0.6f; noise.frequency = 0.3f;
            noise.quality = ParticleSystemNoiseQuality.Low;
            var r = go.GetComponent<ParticleSystemRenderer>();
            r.sharedMaterial = Palette.Particle();
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            ambient.Play();
        }
    }
}
