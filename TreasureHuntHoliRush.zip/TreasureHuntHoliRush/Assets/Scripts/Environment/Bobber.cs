using System.Collections.Generic;
using UnityEngine;

namespace HoliRush
{
    /// <summary>Simple bob / sway animation for dancers and lanterns (animated centrally).</summary>
    public class Bobber : MonoBehaviour
    {
        public static readonly List<Bobber> Active = new List<Bobber>();
        public float amplitude = 0.25f, frequency = 3f, sway = 10f;
        [System.NonSerialized] public float baseY, offset;
        void Awake() { baseY = transform.localPosition.y; offset = Random.value * 10f; }
        void OnEnable() { Active.Add(this); }
        void OnDisable() { Active.Remove(this); }
    }
}
