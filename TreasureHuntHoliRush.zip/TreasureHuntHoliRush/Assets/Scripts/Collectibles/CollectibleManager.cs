using UnityEngine;

namespace HoliRush
{
    /// <summary>
    /// Builds collectible models, animates every active collectible in ONE Update (instead of one
    /// Update per coin) and runs the Color Magnet pull.
    /// </summary>
    public class CollectibleManager : MonoBehaviour
    {
        public static CollectibleManager Instance { get; private set; }
        ObjectPool pool;
        static readonly Color[] TokenColors = { Palette.Red, Palette.Blue, Palette.Yellow, Palette.Green, Palette.Purple };

        public void Init(ObjectPool p)
        {
            Instance = this;
            pool = p;
            pool.Register("coin", Coin);
            for (int i = 0; i < 5; i++) { int c = i; pool.Register("token_" + c, () => Token((TokenColor)c)); }
            pool.Register("gem", Gem);
            pool.Register("key", Key);
            pool.Register("treasure", Treasure);
            pool.Register("golden_token", GoldenToken);
            pool.Register("lucky_color", LuckyColor);
            pool.Register("pu_" + PowerUpType.ColorBurst, () => PowerUpObj(PowerUpType.ColorBurst));
            pool.Register("pu_" + PowerUpType.ColorMagnet, () => PowerUpObj(PowerUpType.ColorMagnet));
            pool.Register("pu_" + PowerUpType.WaterShield, () => PowerUpObj(PowerUpType.WaterShield));
            pool.Register("pu_" + PowerUpType.RainbowDash, () => PowerUpObj(PowerUpType.RainbowDash));
            pool.Register("pu_" + PowerUpType.FestivalMultiplier, () => PowerUpObj(PowerUpType.FestivalMultiplier));
            pool.Prewarm("coin", 120);
        }

        void Update()
        {
            var gm = GameManager.Instance;
            if (gm == null || gm.State == GameState.Paused) return;
            float t = Time.time;
            float spin = 160f * Time.deltaTime;
            Vector3 playerPos = gm.Player != null ? gm.Player.transform.position + Vector3.up * 1f : Vector3.zero;
            bool magnet = gm.State == GameState.Playing && gm.PowerUps != null && gm.PowerUps.IsActive(PowerUpType.ColorMagnet);
            float r2 = gm.Config.magnetRadius * gm.Config.magnetRadius;

            var list = Collectible.Active;
            for (int i = list.Count - 1; i >= 0; i--)
            {
                var c = list[i];
                if (c.spinner != null) c.spinner.Rotate(0f, spin, 0f, Space.World);
                if (magnet && (c.kind == CollectibleKind.Coin || c.kind == CollectibleKind.Gem || c.kind == CollectibleKind.ColorToken))
                {
                    Vector3 d = playerPos - c.transform.position;
                    if (c.magnetised || d.sqrMagnitude < r2)
                    {
                        c.magnetised = true;
                        float step = (gm.CurrentSpeed + 25f) * Time.deltaTime;
                        if (d.magnitude <= step + 0.6f) { gm.Collect(c); continue; }
                        c.transform.position += d.normalized * step;
                        continue;
                    }
                }
                if (!c.magnetised)
                {
                    var lp = c.transform.localPosition;
                    lp.y = c.baseY + Mathf.Sin(t * 3f + c.transform.position.z * 0.3f) * 0.12f;
                    c.transform.localPosition = lp;
                }
            }
        }

        /// <summary>Builds a fresh collectible model by pool key (used by the editor prefab generator).</summary>
        public static GameObject BuildByKey(string key)
        {
            if (key == "coin") return Coin();
            if (key == "gem") return Gem();
            if (key == "key") return Key();
            if (key == "treasure") return Treasure();
            if (key == "golden_token") return GoldenToken();
            if (key == "lucky_color") return LuckyColor();
            if (key.StartsWith("token_")) return Token((TokenColor)int.Parse(key.Substring(6)));
            if (key.StartsWith("pu_")) return PowerUpObj((PowerUpType)System.Enum.Parse(typeof(PowerUpType), key.Substring(3)));
            return null;
        }

        public GameObject Spawn(string key, Vector3 pos, Transform parent)
        {
            var go = pool.Get(key, pos, parent);
            var c = go.GetComponent<Collectible>();
            if (c != null) { c.baseY = go.transform.localPosition.y; c.magnetised = false; }
            return go;
        }

        /// <summary>Color Burst: instantly collect everything in a radius.</summary>
        public int CollectInRadius(Vector3 center, float radius)
        {
            var gm = GameManager.Instance;
            int n = 0;
            float r2 = radius * radius;
            var list = Collectible.Active;
            for (int i = list.Count - 1; i >= 0; i--)
            {
                if (i >= list.Count) continue;
                var c = list[i];
                if (c.kind == CollectibleKind.PowerUp || c.kind == CollectibleKind.LuckyColor) continue;
                if ((c.transform.position - center).sqrMagnitude <= r2) { gm.Collect(c); n++; }
            }
            return n;
        }

        // ------------------------------------------------------------------ builders
        static GameObject Make(string name, CollectibleKind kind, out Transform spinner, float radius = 0.65f)
        {
            var root = ShapeFactory.Root(name);
            var sc = root.AddComponent<SphereCollider>();
            sc.isTrigger = true; sc.radius = radius;
            var spin = ShapeFactory.Root("Spinner", root.transform);
            var c = root.AddComponent<Collectible>();
            c.kind = kind; c.spinner = spin.transform;
            spinner = spin.transform;
            return root;
        }

        static GameObject Coin()
        {
            Transform s;
            var root = Make("Coin", CollectibleKind.Coin, out s);
            ShapeFactory.Prim(PrimitiveType.Cylinder, s, Vector3.zero, new Vector3(0.6f, 0.05f, 0.6f), Palette.Glow(Palette.Gold), new Vector3(90, 0, 0));
            ShapeFactory.Prim(PrimitiveType.Cylinder, s, Vector3.zero, new Vector3(0.36f, 0.06f, 0.36f), Palette.Glow(Palette.Orange), new Vector3(90, 0, 0));
            root.GetComponent<Collectible>().fxColor = Palette.Gold;
            return root;
        }

        static GameObject Token(TokenColor tc)
        {
            Transform s;
            var root = Make("ColorToken_" + tc, CollectibleKind.ColorToken, out s);
            Color col = TokenColors[(int)tc];
            ShapeFactory.Prim(PrimitiveType.Sphere, s, Vector3.zero, new Vector3(0.6f, 0.6f, 0.25f), Palette.Glow(col));
            ShapeFactory.Prim(PrimitiveType.Cylinder, s, new Vector3(0, 0, -0.12f), new Vector3(0.3f, 0.02f, 0.3f), Palette.Glow(Color.white), new Vector3(90, 0, 0));
            var c = root.GetComponent<Collectible>();
            c.tokenColor = tc; c.fxColor = col;
            return root;
        }

        static GameObject Gem()
        {
            Transform s;
            var root = Make("Gem", CollectibleKind.Gem, out s);
            ShapeFactory.Prim(PrimitiveType.Cube, s, Vector3.zero, Vector3.one * 0.5f, Palette.Glow(Palette.Cyan), new Vector3(45, 0, 45));
            ShapeFactory.Prim(PrimitiveType.Cube, s, Vector3.zero, Vector3.one * 0.38f, Palette.Glow(Palette.Magenta), new Vector3(0, 45, 0));
            root.GetComponent<Collectible>().fxColor = Palette.Cyan;
            return root;
        }

        static GameObject Key()
        {
            Transform s;
            var root = Make("FestivalKey", CollectibleKind.FestivalKey, out s);
            ShapeFactory.Prim(PrimitiveType.Cylinder, s, new Vector3(0, 0.25f, 0), new Vector3(0.4f, 0.05f, 0.4f), Palette.Glow(Palette.Gold), new Vector3(90, 0, 0));
            ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(0, -0.15f, 0), new Vector3(0.1f, 0.6f, 0.1f), Palette.Glow(Palette.Gold));
            ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(0.12f, -0.38f, 0), new Vector3(0.2f, 0.08f, 0.1f), Palette.Glow(Palette.Gold));
            ShapeFactory.Prim(PrimitiveType.Sphere, s, new Vector3(0, 0.25f, 0), Vector3.one * 0.15f, Palette.Glow(Palette.Magenta));
            root.GetComponent<Collectible>().fxColor = Palette.Gold;
            return root;
        }

        static GameObject Treasure()
        {
            Transform s;
            var root = Make("TreasureBox", CollectibleKind.TreasureBox, out s, 0.9f);
            ShapeFactory.Box(s, new Vector3(0, -0.1f, 0), new Vector3(0.9f, 0.55f, 0.6f), Palette.Wood);
            ShapeFactory.Prim(PrimitiveType.Cylinder, s, new Vector3(0, 0.2f, 0), new Vector3(0.6f, 0.45f, 0.6f), Palette.Lit(Palette.Magenta), new Vector3(0, 0, 90));
            ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(0, 0.0f, -0.31f), new Vector3(0.15f, 0.2f, 0.05f), Palette.Glow(Palette.Gold));
            ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(0, -0.1f, 0), new Vector3(0.95f, 0.08f, 0.65f), Palette.Glow(Palette.Gold));
            root.GetComponent<Collectible>().fxColor = Palette.Gold;
            return root;
        }

        static GameObject GoldenToken()
        {
            Transform s;
            var root = Make("GoldenColorToken", CollectibleKind.GoldenToken, out s);
            ShapeFactory.Prim(PrimitiveType.Sphere, s, Vector3.zero, new Vector3(0.8f, 0.8f, 0.3f), Palette.Glow(Palette.Gold));
            for (int i = 0; i < 6; i++)
            {
                float a = i / 6f * Mathf.PI * 2f;
                ShapeFactory.Prim(PrimitiveType.Sphere, s, new Vector3(Mathf.Cos(a) * 0.5f, Mathf.Sin(a) * 0.5f, 0), Vector3.one * 0.18f, Palette.Glow(Palette.Powder[i]));
            }
            root.GetComponent<Collectible>().fxColor = Palette.Gold;
            return root;
        }

        static GameObject LuckyColor()
        {
            Transform s;
            var root = Make("LuckyColor", CollectibleKind.LuckyColor, out s, 0.9f);
            for (int i = 0; i < 6; i++)
            {
                float a = i / 6f * Mathf.PI * 2f;
                ShapeFactory.Prim(PrimitiveType.Sphere, s, new Vector3(Mathf.Cos(a) * 0.3f, Mathf.Sin(a) * 0.3f, 0), Vector3.one * 0.45f, Palette.Glow(Palette.Powder[i]));
            }
            ShapeFactory.Prim(PrimitiveType.Sphere, s, Vector3.zero, Vector3.one * 0.4f, Palette.Glow(Color.white));
            root.GetComponent<Collectible>().fxColor = Palette.Magenta;
            return root;
        }

        public static Color PowerUpColor(PowerUpType t)
        {
            switch (t)
            {
                case PowerUpType.ColorBurst: return Palette.Magenta;
                case PowerUpType.ColorMagnet: return Palette.Red;
                case PowerUpType.WaterShield: return Palette.Cyan;
                case PowerUpType.RainbowDash: return Palette.Purple;
                default: return Palette.Yellow;
            }
        }

        static GameObject PowerUpObj(PowerUpType t)
        {
            Transform s;
            var root = Make("PowerUp_" + t, CollectibleKind.PowerUp, out s, 0.9f);
            Color c = PowerUpColor(t);
            // a glowing "festival lamp" orb with an icon-like core per type
            ShapeFactory.Prim(PrimitiveType.Sphere, s, Vector3.zero, Vector3.one * 0.95f, Palette.Transparent(new Color(c.r, c.g, c.b, 0.45f)));
            switch (t)
            {
                case PowerUpType.ColorBurst:
                    for (int i = 0; i < 5; i++)
                        ShapeFactory.Prim(PrimitiveType.Sphere, s, Quaternion.Euler(0, 0, i * 72) * Vector3.up * 0.22f, Vector3.one * 0.22f, Palette.Glow(Palette.Powder[i]));
                    break;
                case PowerUpType.ColorMagnet:
                    ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(-0.17f, 0, 0), new Vector3(0.12f, 0.45f, 0.12f), Palette.Glow(Palette.Red));
                    ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(0.17f, 0, 0), new Vector3(0.12f, 0.45f, 0.12f), Palette.Glow(Palette.Red));
                    ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(0, -0.2f, 0), new Vector3(0.46f, 0.12f, 0.12f), Palette.Glow(Palette.Red));
                    ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(-0.17f, 0.25f, 0), new Vector3(0.13f, 0.08f, 0.13f), Palette.Glow(Color.white));
                    ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(0.17f, 0.25f, 0), new Vector3(0.13f, 0.08f, 0.13f), Palette.Glow(Color.white));
                    break;
                case PowerUpType.WaterShield:
                    ShapeFactory.Prim(PrimitiveType.Sphere, s, new Vector3(0, -0.05f, 0), new Vector3(0.35f, 0.4f, 0.35f), Palette.Glow(Palette.Blue));
                    ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(0, 0.15f, 0), new Vector3(0.18f, 0.18f, 0.18f), Palette.Glow(Palette.Blue), new Vector3(0, 0, 45));
                    break;
                case PowerUpType.RainbowDash:
                    for (int i = 0; i < 5; i++)
                        ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(0, 0.24f - i * 0.12f, 0), new Vector3(0.5f - i * 0.05f, 0.1f, 0.1f), Palette.Glow(Palette.Powder[i]));
                    break;
                default:
                    ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(-0.1f, 0, 0), new Vector3(0.08f, 0.35f, 0.08f), Palette.Glow(Palette.Yellow), new Vector3(0, 0, 35));
                    ShapeFactory.Prim(PrimitiveType.Cube, s, new Vector3(-0.1f, 0, 0), new Vector3(0.08f, 0.35f, 0.08f), Palette.Glow(Palette.Yellow), new Vector3(0, 0, -35));
                    ShapeFactory.Prim(PrimitiveType.Cylinder, s, new Vector3(0.15f, 0, 0), new Vector3(0.2f, 0.04f, 0.2f), Palette.Glow(Palette.Yellow), new Vector3(90, 0, 0));
                    break;
            }
            var col = root.GetComponent<Collectible>();
            col.powerUp = t; col.fxColor = c;
            return root;
        }
    }
}
