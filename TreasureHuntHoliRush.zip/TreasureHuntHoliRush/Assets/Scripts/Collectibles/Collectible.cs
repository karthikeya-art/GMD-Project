using System.Collections.Generic;
using UnityEngine;

namespace HoliRush
{
    public enum CollectibleKind { Coin, ColorToken, Gem, FestivalKey, TreasureBox, GoldenToken, LuckyColor, PowerUp }
    public enum PowerUpType { None, ColorBurst, ColorMagnet, WaterShield, RainbowDash, FestivalMultiplier }
    public enum TokenColor { Red, Blue, Yellow, Green, Purple }

    /// <summary>Data-only component; animation and magnet logic run centrally in CollectibleManager.</summary>
    public class Collectible : MonoBehaviour
    {
        public static readonly List<Collectible> Active = new List<Collectible>();

        public CollectibleKind kind;
        public PowerUpType powerUp;
        public TokenColor tokenColor;
        public Color fxColor = Color.yellow;
        public Transform spinner;
        [System.NonSerialized] public float baseY;
        [System.NonSerialized] public bool magnetised;

        void OnEnable()
        {
            Active.Add(this);
            magnetised = false;
            baseY = transform.localPosition.y;
        }
        void OnDisable() { Active.Remove(this); }
    }
}
