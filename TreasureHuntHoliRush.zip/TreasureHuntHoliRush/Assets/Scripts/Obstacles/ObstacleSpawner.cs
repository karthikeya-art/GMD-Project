using System.Collections.Generic;
using UnityEngine;

namespace HoliRush
{
    /// <summary>
    /// Registers every obstacle type with the ObjectPool and builds their original
    /// procedural models. TrackGenerator asks for obstacles by kind; this class picks a fitting model.
    /// </summary>
    public class ObstacleSpawner : MonoBehaviour
    {
        public static readonly string[] JumpKeys = { "obs_wood_barrier", "obs_construction", "obs_powder_barrel", "obs_rolling_barrel" };
        public static readonly string[] SlideKeys = { "obs_low_banner", "obs_flag_arch" };
        public static readonly string[] BlockKeys = { "obs_festival_cart", "obs_water_tank", "obs_barricade", "obs_stall", "obs_barrel_stack", "obs_poles" };

        ObjectPool pool;

        public void Init(ObjectPool p)
        {
            pool = p;
            pool.Register("obs_wood_barrier", WoodBarrier);
            pool.Register("obs_construction", ConstructionBarrier);
            pool.Register("obs_powder_barrel", PowderBarrel);
            pool.Register("obs_rolling_barrel", RollingBarrelObj);
            pool.Register("obs_low_banner", LowBanner);
            pool.Register("obs_flag_arch", FlagArch);
            pool.Register("obs_festival_cart", FestivalCart);
            pool.Register("obs_water_tank", WaterTank);
            pool.Register("obs_barricade", Barricade);
            pool.Register("obs_stall", Stall);
            pool.Register("obs_barrel_stack", BarrelStack);
            pool.Register("obs_poles", Poles);
            for (int cars = 1; cars <= 3; cars++)
            {
                int c = cars;
                pool.Register("train_" + c, () => TrainFactory.Build(c, false, false, Random.Range(0, 5)));
                pool.Register("train_ramp_" + c, () => TrainFactory.Build(c, true, false, Random.Range(0, 5)));
                pool.Register("train_moving_" + c, () => TrainFactory.Build(c, false, true, Random.Range(0, 5)));
            }
        }

        /// <summary>Builds a fresh obstacle model by pool key (used by the editor prefab generator).</summary>
        public static GameObject BuildByKey(string key)
        {
            switch (key)
            {
                case "obs_wood_barrier": return WoodBarrier();
                case "obs_construction": return ConstructionBarrier();
                case "obs_powder_barrel": return PowderBarrel();
                case "obs_rolling_barrel": return RollingBarrelObj();
                case "obs_low_banner": return LowBanner();
                case "obs_flag_arch": return FlagArch();
                case "obs_festival_cart": return FestivalCart();
                case "obs_water_tank": return WaterTank();
                case "obs_barricade": return Barricade();
                case "obs_stall": return Stall();
                case "obs_barrel_stack": return BarrelStack();
                case "obs_poles": return Poles();
            }
            return null;
        }

        public static string KeyFor(ObstacleKind kind, float difficulty)
        {
            switch (kind)
            {
                case ObstacleKind.Jump:
                    // rolling barrels only appear once the run has warmed up
                    int max = difficulty > 0.25f ? JumpKeys.Length : JumpKeys.Length - 1;
                    return JumpKeys[Random.Range(0, max)];
                case ObstacleKind.Slide:
                    return SlideKeys[Random.Range(0, SlideKeys.Length)];
                default:
                    return BlockKeys[Random.Range(0, BlockKeys.Length)];
            }
        }

        public GameObject Spawn(string key, Vector3 pos, Transform parent)
        {
            var go = pool.Get(key, pos, parent);
            var rb = go.GetComponent<RollingBarrel>();
            if (rb != null)
            {
                if (rb.spinner != null) rb.spinner.localRotation = Quaternion.Euler(0, 0, 90);
                rb.Arm();
            }
            return go;
        }

        // ------------------------------------------------------------------ builders
        // Every obstacle: root at lane centre / ground level, deadly trigger on child "Hit".

        static GameObject Finish(GameObject root, GameObject visual, ObstacleKind kind, Vector3 center, Vector3 size)
        {
            if (visual != null) ShapeFactory.Bake(visual, root.transform);
            var hit = ShapeFactory.Root("Hit", root.transform);
            ShapeFactory.AddBox(hit, center, size, true);
            var o = hit.AddComponent<Obstacle>();
            o.kind = kind;
            o.root = root;
            return root;
        }

        static GameObject WoodBarrier()
        {
            var root = ShapeFactory.Root("WoodBarrier");
            var v = ShapeFactory.Root("V", root.transform).transform;
            for (int s = -1; s <= 1; s += 2)
                ShapeFactory.Box(v, new Vector3(s * 0.95f, 0.45f, 0), new Vector3(0.15f, 0.9f, 0.3f), Palette.Wood);
            ShapeFactory.Box(v, new Vector3(0, 0.75f, 0), new Vector3(2.2f, 0.22f, 0.15f), Palette.Yellow);
            ShapeFactory.Box(v, new Vector3(0, 0.4f, 0), new Vector3(2.2f, 0.22f, 0.15f), Palette.Magenta);
            ShapeFactory.Splashes(v, new Vector3(0, 0.6f, -0.1f), new Vector3(1f, 0.2f, 0.05f), 5, 0.35f);
            return Finish(root, v.gameObject, ObstacleKind.Jump, new Vector3(0, 0.45f, 0), new Vector3(2.2f, 0.9f, 0.5f));
        }

        static GameObject ConstructionBarrier()
        {
            var root = ShapeFactory.Root("ConstructionBarrier");
            var v = ShapeFactory.Root("V", root.transform).transform;
            for (int i = 0; i < 5; i++)
                ShapeFactory.Box(v, new Vector3(-0.9f + i * 0.45f, 0.42f, 0), new Vector3(0.42f, 0.84f, 0.4f), i % 2 == 0 ? Palette.Orange : Palette.Cream);
            ShapeFactory.Prim(PrimitiveType.Sphere, v, new Vector3(-1f, 0.95f, 0), Vector3.one * 0.18f, Palette.Glow(Palette.Red));
            ShapeFactory.Prim(PrimitiveType.Sphere, v, new Vector3(1f, 0.95f, 0), Vector3.one * 0.18f, Palette.Glow(Palette.Red));
            return Finish(root, v.gameObject, ObstacleKind.Jump, new Vector3(0, 0.45f, 0), new Vector3(2.2f, 0.9f, 0.5f));
        }

        static GameObject PowderBarrel()
        {
            var root = ShapeFactory.Root("PowderBarrels");
            var v = ShapeFactory.Root("V", root.transform).transform;
            for (int i = -1; i <= 1; i++)
            {
                Color c = Palette.Powder[(i + 4) % Palette.Powder.Length];
                ShapeFactory.Cyl(v, new Vector3(i * 0.72f, 0.4f, 0), new Vector3(0.65f, 0.4f, 0.65f), Palette.Wood);
                ShapeFactory.Ball(v, new Vector3(i * 0.72f, 0.8f, 0), new Vector3(0.6f, 0.3f, 0.6f), c);
            }
            return Finish(root, v.gameObject, ObstacleKind.Jump, new Vector3(0, 0.45f, 0), new Vector3(2.2f, 0.9f, 0.6f));
        }

        static GameObject RollingBarrelObj()
        {
            var root = ShapeFactory.Root("RollingBarrel");
            var spin = ShapeFactory.Root("Spinner", root.transform);
            spin.transform.localPosition = new Vector3(0, 0.45f, 0);
            spin.transform.localRotation = Quaternion.Euler(0, 0, 90);
            var v = ShapeFactory.Root("V", spin.transform).transform;
            ShapeFactory.Cyl(v, Vector3.zero, new Vector3(0.85f, 1.0f, 0.85f), Palette.Purple);
            ShapeFactory.Cyl(v, new Vector3(0, 0.6f, 0), new Vector3(0.9f, 0.05f, 0.9f), Palette.Yellow);
            ShapeFactory.Cyl(v, new Vector3(0, -0.6f, 0), new Vector3(0.9f, 0.05f, 0.9f), Palette.Yellow);
            ShapeFactory.Splashes(v, Vector3.zero, new Vector3(0.35f, 0.6f, 0.35f), 6, 0.3f);
            ShapeFactory.Bake(v.gameObject, spin.transform);
            var rb = root.AddComponent<RollingBarrel>();
            rb.spinner = spin.transform;
            return Finish(root, null, ObstacleKind.Jump, new Vector3(0, 0.45f, 0), new Vector3(2.0f, 0.9f, 0.8f));
        }

        static GameObject LowBanner()
        {
            var root = ShapeFactory.Root("LowBanner");
            var v = ShapeFactory.Root("V", root.transform).transform;
            for (int s = -1; s <= 1; s += 2)
                ShapeFactory.Cyl(v, new Vector3(s * 1.2f, 1.3f, 0), new Vector3(0.12f, 1.3f, 0.12f), Palette.Wood);
            ShapeFactory.Box(v, new Vector3(0, 1.75f, 0), new Vector3(2.4f, 1.0f, 0.06f), Palette.Magenta);
            ShapeFactory.Box(v, new Vector3(0, 1.75f, -0.04f), new Vector3(2.0f, 0.55f, 0.02f), Palette.Yellow);
            for (int i = 0; i < 3; i++)
                ShapeFactory.Cyl(v, new Vector3(-0.6f + i * 0.6f, 1.75f, -0.07f), new Vector3(0.38f, 0.02f, 0.38f),
                                 Palette.Powder[i * 2], new Vector3(90, 0, 0));
            for (int i = 0; i < 6; i++) ShapeFactory.Ball(v, new Vector3(-1f + i * 0.4f, 1.22f, 0), Vector3.one * 0.15f, Palette.Orange);
            return Finish(root, v.gameObject, ObstacleKind.Slide, new Vector3(0, 1.85f, 0), new Vector3(2.3f, 1.5f, 0.4f));
        }

        static GameObject FlagArch()
        {
            var root = ShapeFactory.Root("FlagArch");
            var v = ShapeFactory.Root("V", root.transform).transform;
            for (int s = -1; s <= 1; s += 2)
                ShapeFactory.Box(v, new Vector3(s * 1.2f, 1.4f, 0), new Vector3(0.18f, 2.8f, 0.18f), Palette.Purple);
            ShapeFactory.Box(v, new Vector3(0, 2.5f, 0), new Vector3(2.6f, 0.6f, 0.2f), Palette.Cyan);
            ShapeFactory.Bunting(v, new Vector3(-1.2f, 2.2f, -0.12f), new Vector3(1.2f, 2.2f, -0.12f), 7);
            ShapeFactory.Box(v, new Vector3(0, 1.6f, 0), new Vector3(2.3f, 0.5f, 0.05f), Palette.Pink);
            return Finish(root, v.gameObject, ObstacleKind.Slide, new Vector3(0, 1.95f, 0), new Vector3(2.3f, 1.7f, 0.4f));
        }

        static GameObject FestivalCart()
        {
            var root = ShapeFactory.Root("FestivalCart");
            var v = ShapeFactory.Root("V", root.transform).transform;
            ShapeFactory.Box(v, new Vector3(0, 1.0f, 0), new Vector3(2.0f, 0.9f, 2.4f), Palette.Orange);
            ShapeFactory.Box(v, new Vector3(0, 1.5f, 0), new Vector3(2.1f, 0.12f, 2.5f), Palette.Wood);
            for (int i = 0; i < 6; i++)
                ShapeFactory.Ball(v, new Vector3(-0.6f + (i % 3) * 0.6f, 1.75f, -0.5f + (i / 3) * 1.0f), Vector3.one * 0.5f, Palette.Powder[i]);
            for (int s = -1; s <= 1; s += 2)
                ShapeFactory.Cyl(v, new Vector3(s * 1.05f, 0.5f, 0), new Vector3(1.0f, 0.06f, 1.0f), Palette.Dark, new Vector3(0, 0, 90));
            ShapeFactory.Cyl(v, new Vector3(0, 2.4f, 0), new Vector3(0.08f, 0.6f, 0.08f), Palette.Wood);
            ShapeFactory.Ball(v, new Vector3(0, 3.0f, 0), new Vector3(1.8f, 0.4f, 1.8f), Palette.Pink);
            return Finish(root, v.gameObject, ObstacleKind.Block, new Vector3(0, 1.4f, 0), new Vector3(2.1f, 2.8f, 2.4f));
        }

        static GameObject WaterTank()
        {
            var root = ShapeFactory.Root("WaterTank");
            var v = ShapeFactory.Root("V", root.transform).transform;
            ShapeFactory.Cyl(v, new Vector3(0, 1.3f, 0), new Vector3(2.0f, 1.3f, 2.0f), Palette.Blue);
            ShapeFactory.Cyl(v, new Vector3(0, 2.65f, 0), new Vector3(2.1f, 0.06f, 2.1f), Palette.Cyan);
            ShapeFactory.Cyl(v, new Vector3(0, 1.3f, 0), new Vector3(2.05f, 0.1f, 2.05f), Palette.Yellow);
            ShapeFactory.Splashes(v, new Vector3(0, 1.4f, -0.9f), new Vector3(0.8f, 0.8f, 0.1f), 8, 0.45f);
            return Finish(root, v.gameObject, ObstacleKind.Block, new Vector3(0, 1.35f, 0), new Vector3(2.0f, 2.7f, 2.0f));
        }

        static GameObject Barricade()
        {
            var root = ShapeFactory.Root("RoadBarricade");
            var v = ShapeFactory.Root("V", root.transform).transform;
            for (int s = -1; s <= 1; s += 2)
                ShapeFactory.Box(v, new Vector3(s * 0.95f, 1.3f, 0), new Vector3(0.2f, 2.6f, 0.4f), Palette.Dark);
            for (int i = 0; i < 4; i++)
                ShapeFactory.Box(v, new Vector3(0, 0.5f + i * 0.6f, 0), new Vector3(2.2f, 0.35f, 0.18f), i % 2 == 0 ? Palette.Red : Palette.Cream);
            ShapeFactory.Prim(PrimitiveType.Sphere, v, new Vector3(0, 2.8f, 0), Vector3.one * 0.3f, Palette.Glow(Palette.Orange));
            return Finish(root, v.gameObject, ObstacleKind.Block, new Vector3(0, 1.4f, 0), new Vector3(2.2f, 2.8f, 0.6f));
        }

        static GameObject Stall()
        {
            var root = ShapeFactory.Root("FestivalStall");
            var v = ShapeFactory.Root("V", root.transform).transform;
            ShapeFactory.Box(v, new Vector3(0, 0.6f, 0), new Vector3(2.2f, 1.2f, 1.4f), Palette.Wood);
            for (int s = -1; s <= 1; s += 2)
                for (int f = -1; f <= 1; f += 2)
                    ShapeFactory.Cyl(v, new Vector3(s * 1.0f, 1.6f, f * 0.6f), new Vector3(0.08f, 1.6f, 0.08f), Palette.Cream);
            for (int i = 0; i < 5; i++)
                ShapeFactory.Box(v, new Vector3(-0.88f + i * 0.44f, 3.2f, 0), new Vector3(0.44f, 0.15f, 1.6f), i % 2 == 0 ? Palette.Pink : Palette.Yellow);
            for (int i = 0; i < 4; i++)
                ShapeFactory.Ball(v, new Vector3(-0.75f + i * 0.5f, 1.35f, 0), new Vector3(0.45f, 0.3f, 0.45f), Palette.Powder[i + 2]);
            return Finish(root, v.gameObject, ObstacleKind.Block, new Vector3(0, 1.6f, 0), new Vector3(2.2f, 3.2f, 1.4f));
        }

        static GameObject BarrelStack()
        {
            var root = ShapeFactory.Root("BarrelStack");
            var v = ShapeFactory.Root("V", root.transform).transform;
            for (int i = -1; i <= 1; i++)
                ShapeFactory.Cyl(v, new Vector3(i * 0.7f, 0.55f, 0), new Vector3(0.65f, 0.55f, 0.65f), Palette.Powder[i + 3]);
            for (int i = 0; i < 2; i++)
                ShapeFactory.Cyl(v, new Vector3(-0.35f + i * 0.7f, 1.65f, 0), new Vector3(0.65f, 0.55f, 0.65f), Palette.Powder[i + 5]);
            ShapeFactory.Cyl(v, new Vector3(0, 2.75f, 0), new Vector3(0.65f, 0.55f, 0.65f), Palette.Magenta);
            return Finish(root, v.gameObject, ObstacleKind.Block, new Vector3(0, 1.6f, 0), new Vector3(2.1f, 3.2f, 0.7f));
        }

        static GameObject Poles()
        {
            var root = ShapeFactory.Root("DecorativePoles");
            var v = ShapeFactory.Root("V", root.transform).transform;
            for (int i = -1; i <= 1; i++)
            {
                ShapeFactory.Cyl(v, new Vector3(i * 0.75f, 1.5f, 0), new Vector3(0.22f, 1.5f, 0.22f), Palette.Powder[i + 1]);
                ShapeFactory.Ball(v, new Vector3(i * 0.75f, 3.1f, 0), Vector3.one * 0.4f, Palette.Gold);
            }
            ShapeFactory.Bunting(v, new Vector3(-0.8f, 2.8f, 0), new Vector3(0.8f, 2.8f, 0), 5);
            ShapeFactory.Box(v, new Vector3(0, 1.2f, 0), new Vector3(1.9f, 0.6f, 0.08f), Palette.Yellow);
            return Finish(root, v.gameObject, ObstacleKind.Block, new Vector3(0, 1.5f, 0), new Vector3(2.0f, 3.0f, 0.5f));
        }
    }
}
