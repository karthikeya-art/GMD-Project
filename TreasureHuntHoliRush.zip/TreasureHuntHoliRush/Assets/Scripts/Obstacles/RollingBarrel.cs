using UnityEngine;

namespace HoliRush
{
    /// <summary>Rolling colour barrel - rolls toward the player inside its reserved stretch.</summary>
    public class RollingBarrel : MonoBehaviour
    {
        public float speed = 4f;
        public float travel = 6f;
        public Transform spinner;
        float startZ;
        bool activated;

        public void Arm() { startZ = transform.position.z; activated = false; }

        void Update()
        {
            var gm = GameManager.Instance;
            if (gm == null || gm.State != GameState.Playing || gm.Player == null) return;
            float dz = transform.position.z - gm.Player.transform.position.z;
            if (!activated) { if (dz < 45f && dz > 0f) activated = true; else return; }
            if (startZ - transform.position.z >= travel) return;
            float step = speed * Time.deltaTime;
            transform.position += Vector3.back * step;
            if (spinner != null) spinner.Rotate(-step / 0.45f * Mathf.Rad2Deg, 0f, 0f, Space.World);
        }
    }
}
