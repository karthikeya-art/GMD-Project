using System.Collections.Generic;
using UnityEngine;

namespace HoliRush
{
    public enum ObstacleKind
    {
        Block,   // must change lane
        Jump,    // low - jump over it
        Slide    // high - slide under it
    }

    /// <summary>Put on the GameObject that owns the deadly trigger collider.</summary>
    public class Obstacle : MonoBehaviour
    {
        public static readonly List<Obstacle> Active = new List<Obstacle>();

        public ObstacleKind kind;
        public GameObject root;          // the whole pooled object (hidden when smashed)
        [System.NonSerialized] public Collider hitCollider;

        void Awake() { hitCollider = GetComponent<Collider>(); if (root == null) root = gameObject; }
        void OnEnable() { Active.Add(this); }
        void OnDisable() { Active.Remove(this); }
    }

}
