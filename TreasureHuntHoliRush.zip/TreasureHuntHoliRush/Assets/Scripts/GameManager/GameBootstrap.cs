using UnityEngine;
using UnityEngine.EventSystems;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

namespace HoliRush
{
    /// <summary>
    /// ONE component that builds and wires the entire game at startup: lighting, camera, managers,
    /// player, track, UI. The editor setup tool places it in the main scene and assigns the
    /// material templates. If you press Play in ANY scene without it, it creates itself automatically.
    /// </summary>
    [DefaultExecutionOrder(-1000)]
    public class GameBootstrap : MonoBehaviour
    {
        [Tooltip("Lit material used as a template for every generated colour (assigned by Holi Rush > Build Complete Game Setup)")]
        public Material litTemplate;
        [Tooltip("Sprites/Default material used for particles, shield bubble and transparent effects")]
        public Material unlitTemplate;
        [Tooltip("Lit material with emission enabled, used for glowing coins, lamps and power-ups")]
        public Material glowTemplate;
        public GameConfig config = new GameConfig();

        static bool built;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void AutoCreate()
        {
#if UNITY_2022_2_OR_NEWER
            var existing = FindFirstObjectByType<GameBootstrap>();
#else
            var existing = FindObjectOfType<GameBootstrap>();
#endif
            if (existing == null)
            {
                Debug.Log("[HoliRush] No GameBootstrap in scene - creating one automatically.");
                new GameObject("GameBootstrap").AddComponent<GameBootstrap>();
            }
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics()
        {
            built = false;
            Palette.ClearCache();
            Collectible.Active.Clear();
            Obstacle.Active.Clear();
            Bobber.Active.Clear();
        }

        void Awake()
        {
            if (built) { Destroy(gameObject); return; }
            built = true;
            Application.targetFrameRate = 60;
            QualitySettings.vSyncCount = 0;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Build();
        }

        void Build()
        {
            if (litTemplate != null) Palette.LitTemplate = litTemplate;
            if (unlitTemplate != null) Palette.UnlitTemplate = unlitTemplate;
            if (glowTemplate != null) Palette.GlowTemplate = glowTemplate;

            SetupLighting();
            var cam = SetupCamera();
            SetupEventSystem();

            var pool = Make<ObjectPool>("ObjectPool");
            Make<AudioManager>("AudioManager");
            var fx = Make<HoliFX>("HoliFX");
            var env = Make<EnvironmentManager>("EnvironmentManager");
            var obstacles = Make<ObstacleSpawner>("ObstacleSpawner");
            var collectibles = Make<CollectibleManager>("CollectibleManager");
            var track = Make<TrackGenerator>("TrackGenerator");
            var powerUps = Make<PowerUpManager>("PowerUpManager");
            var gm = Make<GameManager>("GameManager");
            var ui = Make<UIManager>("UIManager");

            var playerGo = new GameObject("Player");
            playerGo.AddComponent<InputReader>();
            var player = playerGo.AddComponent<PlayerController>();

            var camRig = cam.gameObject.GetComponent<CameraFollow>();
            if (camRig == null) camRig = cam.gameObject.AddComponent<CameraFollow>();

            // wire everything (order matters: GameManager first so others can use Instance)
            gm.Init(config, player, camRig, powerUps, track, ui);
            env.Init(gm, pool);
            obstacles.Init(pool);
            collectibles.Init(pool);
            track.Init(gm, pool, env, obstacles, collectibles);
            powerUps.Init(gm);
            player.Init(gm);
            camRig.Init(gm, cam);
            fx.CreateAmbient(cam.transform);
            ui.Init(gm);

            gm.GoToMenu();
        }

        T Make<T>(string n) where T : Component
        {
            var go = new GameObject(n);
            go.transform.SetParent(transform, false);
            return go.AddComponent<T>();
        }

        void SetupLighting()
        {
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(1f, 0.85f, 0.95f);
            RenderSettings.ambientEquatorColor = new Color(0.95f, 0.75f, 0.7f);
            RenderSettings.ambientGroundColor = new Color(0.55f, 0.45f, 0.5f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 55f;
            RenderSettings.fogEndDistance = 250f;
            RenderSettings.fogColor = new Color(1f, 0.82f, 0.88f);
            RenderSettings.skybox = null;

            Light sun = null;
            foreach (var l in FindLights())
                if (l.type == LightType.Directional) { sun = l; break; }
            if (sun == null)
            {
                sun = new GameObject("Holi Sun").AddComponent<Light>();
                sun.type = LightType.Directional;
            }
            sun.transform.rotation = Quaternion.Euler(48f, -35f, 0f);
            sun.color = new Color(1f, 0.93f, 0.82f);
            sun.intensity = 1.15f;
            sun.shadows = LightShadows.None;   // blob shadows instead - cheap on mobile
        }

        static Light[] FindLights()
        {
#if UNITY_2022_2_OR_NEWER
            return FindObjectsByType<Light>(FindObjectsSortMode.None);
#else
            return FindObjectsOfType<Light>();
#endif
        }

        Camera SetupCamera()
        {
            var cam = Camera.main;
            if (cam == null)
            {
                var go = new GameObject("Main Camera");
                go.tag = "MainCamera";
                cam = go.AddComponent<Camera>();
            }
            if (cam.GetComponent<AudioListener>() == null) cam.gameObject.AddComponent<AudioListener>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = RenderSettings.fogColor;
            return cam;
        }

        void SetupEventSystem()
        {
#if UNITY_2022_2_OR_NEWER
            if (FindFirstObjectByType<EventSystem>() != null) return;
#else
            if (FindObjectOfType<EventSystem>() != null) return;
#endif
            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
#if ENABLE_INPUT_SYSTEM
            var module = es.AddComponent<InputSystemUIInputModule>();
            module.AssignDefaultActions();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }
    }
}
