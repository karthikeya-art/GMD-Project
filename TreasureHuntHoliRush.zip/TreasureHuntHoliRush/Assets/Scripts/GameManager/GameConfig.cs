using UnityEngine;

namespace HoliRush
{
    /// <summary>All tunable numbers in one place. Edit them on the GameBootstrap object in the Inspector.</summary>
    [System.Serializable]
    public class GameConfig
    {
        [Header("Track")]
        public float laneWidth = 2.6f;
        public float segmentLength = 60f;
        public int segmentsAhead = 6;
        public int safeStartSegments = 1;

        [Header("Speed")]
        public float startSpeed = 13f;
        public float maxSpeed = 30f;
        public float acceleration = 0.18f;     // units per second, per second

        [Header("Player")]
        public float laneChangeSpeed = 16f;
        public float jumpVelocity = 9.5f;
        public float gravity = 28f;
        public float slideDuration = 0.75f;

        [Header("Power-ups (seconds)")]
        public float magnetDuration = 10f;
        public float magnetRadius = 9f;
        public float shieldDuration = 30f;
        public float rainbowDashDuration = 6f;
        public float rainbowDashSpeedMultiplier = 1.45f;
        public float multiplierDuration = 15f;
        public float colorBurstRadius = 14f;

        [Header("Economy")]
        public int reviveGemCost = 1;
        public int startingGems = 3;           // granted once on first launch so Revive can be tried
        public int coinScore = 10;
        public int colorTokenScore = 50;
        public int gemScore = 250;
        public int luckyColorScore = 5000;
    }
}
