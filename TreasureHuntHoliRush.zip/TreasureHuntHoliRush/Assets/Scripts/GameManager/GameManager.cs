using System;
using UnityEngine;

namespace HoliRush
{
    public enum GameState { Menu, Playing, Paused, GameOver }

    /// <summary>
    /// Run state, score, speed, collecting, crash / revive / retry flow.
    /// Other systems talk to each other through this class and C# events, never through the Inspector.
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        public GameConfig Config { get; private set; }
        public GameState State { get; private set; }
        public PlayerController Player { get; private set; }
        public CameraFollow CameraRig { get; private set; }
        public PowerUpManager PowerUps { get; private set; }
        public TrackGenerator Track { get; private set; }
        public UIManager UI { get; private set; }

        public float Distance { get; private set; }
        public float Score { get; private set; }
        public int RunCoins { get; private set; }
        public int RunGems { get; private set; }
        public int RunKeys { get; private set; }
        public int RunTokens { get; private set; }
        public int RunTreasures { get; private set; }
        public int ReviveCount { get; private set; }
        public bool NewBest { get; private set; }

        public float CurrentBaseSpeed { get; private set; }
        public float CurrentSpeed { get { return CurrentBaseSpeed * (PowerUps != null ? PowerUps.SpeedMultiplier : 1f); } }
        public float ScoreMultiplier { get { return PowerUps != null ? PowerUps.ScoreMultiplier : 1f; } }
        public int ReviveCost { get { return Config.reviveGemCost * (1 << Mathf.Min(ReviveCount, 6)); } }

        public event Action<GameState> StateChanged;
        public event Action<string, Color> Toast;      // short centre-screen messages

        float runTime;
        int pauseFrame = -1;
        int committedCoins, committedGems, committedKeys, committedTokens;

        public void Init(GameConfig cfg, PlayerController player, CameraFollow cam, PowerUpManager pu, TrackGenerator track, UIManager ui)
        {
            Instance = this;
            Config = cfg; Player = player; CameraRig = cam; PowerUps = pu; Track = track; UI = ui;
            SaveManager.EnsureInitialised(cfg.startingGems);
        }

        void SetState(GameState s)
        {
            State = s;
            if (StateChanged != null) StateChanged(s);
        }

        // ------------------------------------------------------------------ flow
        public void GoToMenu()
        {
            Time.timeScale = 1f;
            CommitRun();
            ResetRunData();
            SetState(GameState.Menu);
            if (AudioManager.Instance != null) AudioManager.Instance.SetMusicPaused(false);
        }

        public void StartRun()
        {
            Time.timeScale = 1f;
            if (State != GameState.Menu) { CommitRun(); ResetRunData(); }
            SetState(GameState.Playing);
            CameraRig.BeginBlend();
            if (AudioManager.Instance != null) { AudioManager.Instance.StartMusic(); AudioManager.Instance.SetMusicPaused(false); }
            ShowToast("RUN!", Palette.Yellow);
        }

        public void Retry()
        {
            Time.timeScale = 1f;
            CommitRun();
            ResetRunData();
            SetState(GameState.Playing);
            CameraRig.Snap();
            if (AudioManager.Instance != null) AudioManager.Instance.SetMusicPaused(false);
        }

        void ResetRunData()
        {
            Distance = 0f; Score = 0f; runTime = 0f;
            RunCoins = RunGems = RunKeys = RunTokens = RunTreasures = 0;
            committedCoins = committedGems = committedKeys = committedTokens = 0;
            ReviveCount = 0; NewBest = false;
            CurrentBaseSpeed = Config.startSpeed;
            PowerUps.ResetAll();
            Player.ResetRun();
            Track.ResetTrack();
            CameraRig.Snap();
        }

        public void TogglePause()
        {
            if (State == GameState.Playing) Pause();
            else if (State == GameState.Paused) Resume();
        }

        public void Pause()
        {
            if (State != GameState.Playing) return;
            Time.timeScale = 0f;
            pauseFrame = Time.frameCount;
            SetState(GameState.Paused);
            if (AudioManager.Instance != null) AudioManager.Instance.SetMusicPaused(true);
        }

        public void Resume()
        {
            if (State != GameState.Paused) return;
            Time.timeScale = 1f;
            SetState(GameState.Playing);
            if (AudioManager.Instance != null) AudioManager.Instance.SetMusicPaused(false);
        }

        public void OnPlayerCrashed()
        {
            CommitRun();
            SetState(GameState.GameOver);
            if (AudioManager.Instance != null)
            {
                AudioManager.Instance.Play(Sfx.GameOver, 0.8f);
                AudioManager.Instance.SetMusicPaused(true);
            }
        }

        public bool CanRevive { get { return State == GameState.GameOver && SaveManager.Gems >= ReviveCost; } }

        public bool TryRevive()
        {
            if (!CanRevive) return false;
            int cost = ReviveCost;
            if (!SaveManager.TrySpendGems(cost)) return false;
            ReviveCount++;
            float z = Player.transform.position.z;
            Track.ClearObstacles(z - 6f, z + 50f);   // never revive into an obstacle
            Player.Revive();
            SetState(GameState.Playing);
            CameraRig.Snap();
            if (AudioManager.Instance != null) { AudioManager.Instance.SetMusicPaused(false); AudioManager.Instance.Play(Sfx.PowerUp); }
            if (HoliFX.Instance != null) HoliFX.Instance.Explosion(Player.transform.position + Vector3.up, 1.2f);
            ShowToast("REVIVED!  -" + cost + " GEM" + (cost > 1 ? "S" : ""), Palette.Cyan);
            return true;
        }

        /// <summary>Saves the not-yet-saved part of this run (safe to call many times).</summary>
        void CommitRun()
        {
            if (Score <= 0f && RunCoins == 0 && RunGems == 0) return;
            bool best = SaveManager.SubmitRun(Mathf.FloorToInt(Score),
                RunCoins - committedCoins, RunGems - committedGems, RunKeys - committedKeys, RunTokens - committedTokens);
            if (best) NewBest = true;
            committedCoins = RunCoins; committedGems = RunGems; committedKeys = RunKeys; committedTokens = RunTokens;
        }

        void OnApplicationPause(bool paused)
        {
            if (paused && State == GameState.Playing) Pause();
        }

        void OnApplicationQuit() { CommitRun(); }

        // ------------------------------------------------------------------ per frame
        void Update()
        {
            if (State == GameState.Paused && Time.frameCount != pauseFrame && Player.Input.PausePressed()) { Resume(); return; }
            if (State == GameState.Menu && Player.Input.ConfirmPressed()) { StartRun(); return; }
            if (State != GameState.Playing) return;
            float dt = Time.deltaTime;
            runTime += dt;
            CurrentBaseSpeed = Mathf.Min(Config.maxSpeed, Config.startSpeed + Config.acceleration * runTime);
            float moved = CurrentSpeed * dt;
            Distance += moved;
            Score += moved * ScoreMultiplier;
            // the hero's clothes get more colourful as the run goes on
            Player.Visual.SetColorLevel(Mathf.Min(16, Mathf.FloorToInt(Distance / 150f) + RunTokens / 10));
        }

        public void AddScore(float s) { Score += s * ScoreMultiplier; }

        public void ShowToast(string msg, Color c) { if (Toast != null) Toast(msg, c); }

        // ------------------------------------------------------------------ collecting
        public void Collect(Collectible c)
        {
            if (c == null || !c.gameObject.activeInHierarchy) return;
            var a = AudioManager.Instance;
            var fx = HoliFX.Instance;
            Vector3 p = c.transform.position;
            switch (c.kind)
            {
                case CollectibleKind.Coin:
                    RunCoins++; AddScore(Config.coinScore);
                    if (a != null) a.Play(Sfx.Coin, 0.55f, 1f + (RunCoins % 5) * 0.03f);
                    break;
                case CollectibleKind.ColorToken:
                    RunTokens++; AddScore(Config.colorTokenScore);
                    if (a != null) a.Play(Sfx.Token, 0.7f);
                    if (fx != null) fx.Burst(p, c.fxColor, 14, 0.7f);
                    break;
                case CollectibleKind.Gem:
                    RunGems++; AddScore(Config.gemScore);
                    if (a != null) a.Play(Sfx.Gem);
                    if (fx != null) fx.Burst(p, c.fxColor, 22, 0.9f);
                    ShowToast("+1 GEM", Palette.Cyan);
                    break;
                case CollectibleKind.FestivalKey:
                    RunKeys++; AddScore(300);
                    if (a != null) a.Play(Sfx.Gem, 1f, 0.8f);
                    if (fx != null) fx.Burst(p, Palette.Gold, 22, 0.9f);
                    ShowToast("FESTIVAL KEY!", Palette.Gold);
                    break;
                case CollectibleKind.TreasureBox:
                    RunTreasures++;
                    RunCoins += 50; AddScore(1000);
                    if (UnityEngine.Random.value < 0.35f) { RunGems++; ShowToast("TREASURE!  +50 COINS +1 GEM", Palette.Gold); }
                    else ShowToast("TREASURE!  +50 COINS", Palette.Gold);
                    if (a != null) a.Play(Sfx.Lucky, 0.8f);
                    if (fx != null) fx.Explosion(p, 0.9f);
                    break;
                case CollectibleKind.GoldenToken:
                    RunTokens += 10; RunGems += 2; AddScore(2500);
                    if (a != null) a.Play(Sfx.Lucky);
                    if (fx != null) { fx.Burst(p, Palette.Gold, 40, 1.4f); fx.Explosion(p, 1f); }
                    ShowToast("GOLDEN COLOR TOKEN!", Palette.Gold);
                    break;
                case CollectibleKind.LuckyColor:
                    RunCoins += 100; AddScore(Config.luckyColorScore);
                    if (a != null) a.Play(Sfx.Lucky);
                    if (fx != null) { fx.Explosion(p, 1.8f); fx.Explosion(p + Vector3.up * 2f, 1.5f); }
                    CameraRig.Shake(0.2f, 0.4f);
                    ShowToast("LUCKY COLOR!  +" + Config.luckyColorScore, Palette.Magenta);
                    break;
                case CollectibleKind.PowerUp:
                    c.gameObject.SetActive(false);
                    PowerUps.Activate(c.powerUp);
                    ShowToast(PowerUpManager.DisplayName(c.powerUp), CollectibleManager.PowerUpColor(c.powerUp));
                    return;
            }
            c.gameObject.SetActive(false);
        }
    }
}
