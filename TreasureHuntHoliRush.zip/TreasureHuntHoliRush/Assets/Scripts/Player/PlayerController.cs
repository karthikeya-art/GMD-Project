using UnityEngine;

namespace HoliRush
{
    /// <summary>
    /// Endless-runner movement: auto-run, 3 lanes, jump, slide, roof running, collisions.
    /// The player uses a trigger capsule + kinematic Rigidbody; movement is fully scripted
    /// so it feels precise and never gets stuck on physics.
    /// </summary>
    [RequireComponent(typeof(InputReader))]
    public class PlayerController : MonoBehaviour
    {
        public PlayerVisual Visual { get; private set; }
        public bool Alive { get; private set; }
        public int Lane { get { return lane; } }
        public InputReader Input { get { return input; } }

        GameManager gm;
        InputReader input;
        CapsuleCollider capsule;
        Transform blobShadow;

        int lane, previousLane;
        float x, feetY, vy;
        bool grounded = true;
        float slideTimer;
        bool queuedSlide;
        float invincibleTimer, stumbleTimer, stepTimer;
        readonly RaycastHit[] hits = new RaycastHit[8];

        const float StandHeight = 1.8f, SlideHeight = 0.8f, Radius = 0.38f;

        public bool IsSliding { get { return slideTimer > 0f; } }
        public bool IsInvincible { get { return invincibleTimer > 0f; } }
        public float FeetY { get { return feetY; } }

        public void Init(GameManager g)
        {
            gm = g;
            input = GetComponent<InputReader>();
            capsule = gameObject.AddComponent<CapsuleCollider>();
            capsule.isTrigger = true;
            capsule.radius = Radius;
            var rb = gameObject.AddComponent<Rigidbody>();
            rb.isKinematic = true;
            rb.useGravity = false;
            rb.interpolation = RigidbodyInterpolation.None;
            Visual = gameObject.AddComponent<PlayerVisual>();
            Visual.Build();
            blobShadow = transform.Find("BlobShadow");
            ResetRun();
        }

        public void ResetRun()
        {
            lane = previousLane = 0;
            x = 0f; feetY = 0f; vy = 0f; grounded = true;
            slideTimer = 0f; queuedSlide = false;
            invincibleTimer = 0f; stumbleTimer = 0f;
            Alive = true;
            transform.position = Vector3.zero;
            SetCapsule(false);
            Visual.ResetPose();
            Visual.SetColorLevel(0);
            Visual.ClearTrail();
        }

        void SetCapsule(bool sliding)
        {
            float h = sliding ? SlideHeight : StandHeight;
            capsule.height = h;
            capsule.center = new Vector3(0, h * 0.5f + 0.1f, 0);
        }

        void Update()
        {
            if (gm == null) return;
            float dt = Time.deltaTime;
            switch (gm.State)
            {
                case GameState.Menu:
                    Visual.Animate(PoseMode.Idle, 0f, dt);
                    return;
                case GameState.Paused:
                    return;
                case GameState.GameOver:
                    Visual.Animate(PoseMode.Dead, 0f, dt);
                    return;
            }
            if (!Alive) return;

            HandleInput(input.Poll());

            // ---- forward
            float speed = gm.CurrentSpeed;
            Vector3 pos = transform.position;
            pos.z += speed * dt;

            // ---- lateral
            float targetX = lane * gm.Config.laneWidth;
            x = Mathf.MoveTowards(x, targetX, gm.Config.laneChangeSpeed * dt);
            pos.x = x;

            // ---- vertical (ground can be the rails, a ramp or a train roof)
            float groundY = GroundHeight(new Vector3(x, feetY, pos.z));
            if (grounded)
            {
                if (groundY < feetY - 0.05f) { grounded = false; vy = 0f; }
                else feetY = groundY;
            }
            if (!grounded)
            {
                vy -= gm.Config.gravity * dt;
                feetY += vy * dt;
                if (feetY <= groundY && vy <= 0f)
                {
                    feetY = groundY; vy = 0f; grounded = true;
                    if (queuedSlide) { queuedSlide = false; StartSlide(); }
                }
            }
            pos.y = feetY;
            transform.position = pos;
            if (blobShadow != null)
            {
                blobShadow.position = new Vector3(pos.x, groundY + 0.02f, pos.z);
                float s = Mathf.Lerp(0.9f, 0.45f, Mathf.Clamp01((feetY - groundY) / 2f));
                blobShadow.localScale = new Vector3(s, 0.005f, s);
            }

            // ---- timers
            if (slideTimer > 0f)
            {
                slideTimer -= dt;
                if (slideTimer <= 0f) SetCapsule(false);
            }
            if (stumbleTimer > 0f) stumbleTimer -= dt;
            if (invincibleTimer > 0f)
            {
                invincibleTimer -= dt;
                Visual.SetVisible(invincibleTimer <= 0f || Mathf.Repeat(invincibleTimer, 0.2f) > 0.08f);
            }

            // ---- animation + footsteps
            PoseMode pose = !grounded ? PoseMode.Jump : (slideTimer > 0f ? PoseMode.Slide : PoseMode.Run);
            Visual.Animate(pose, speed, dt);
            if (pose == PoseMode.Run)
            {
                stepTimer -= dt;
                if (stepTimer <= 0f)
                {
                    stepTimer = Mathf.Lerp(0.32f, 0.2f, (speed - 12f) / 20f);
                    if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Step, 0.35f, Random.Range(0.9f, 1.1f));
                }
            }
        }

        void HandleInput(RunnerAction a)
        {
            switch (a)
            {
                case RunnerAction.Left: ChangeLane(-1); break;
                case RunnerAction.Right: ChangeLane(1); break;
                case RunnerAction.Jump:
                    if (grounded)
                    {
                        if (slideTimer > 0f) { slideTimer = 0f; SetCapsule(false); }
                        grounded = false;
                        vy = gm.Config.jumpVelocity;
                        if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Jump, 0.8f);
                    }
                    break;
                case RunnerAction.Slide:
                    if (grounded) StartSlide();
                    else { vy = -gm.Config.jumpVelocity * 1.6f; queuedSlide = true; }   // fast-fall then slide
                    break;
                case RunnerAction.Pause: gm.TogglePause(); break;
            }
        }

        void ChangeLane(int dir)
        {
            int nl = Mathf.Clamp(lane + dir, -1, 1);
            if (nl == lane) return;
            previousLane = lane;
            lane = nl;
        }

        void StartSlide()
        {
            slideTimer = gm.Config.slideDuration;
            SetCapsule(true);
            if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Slide, 0.8f);
        }

        float GroundHeight(Vector3 feet)
        {
            float best = 0f;
            var origin = feet + Vector3.up * 1.2f;
            int n = Physics.RaycastNonAlloc(origin, Vector3.down, hits, 6f, ~0, QueryTriggerInteraction.Ignore);
            for (int i = 0; i < n; i++)
            {
                var h = hits[i];
                if (h.point.y > feet.y + 0.6f) continue;            // too high to step onto
                if (h.collider.GetComponent<Walkable>() == null) continue;
                if (h.point.y > best) best = h.point.y;
            }
            return best;
        }

        // ------------------------------------------------------------------ collisions
        void OnTriggerEnter(Collider other)
        {
            if (gm == null || gm.State != GameState.Playing || !Alive) return;

            var c = other.GetComponent<Collectible>();
            if (c != null) { gm.Collect(c); return; }

            var o = other.GetComponent<Obstacle>();
            if (o != null) HitObstacle(o, other);
        }

        void HitObstacle(Obstacle o, Collider col)
        {
            if (invincibleTimer > 0f) return;

            // Rainbow Dash smashes straight through
            if (gm.PowerUps.IsActive(PowerUpType.RainbowDash))
            {
                Smash(o);
                gm.AddScore(100);
                return;
            }

            float px = transform.position.x;
            bool changingLane = Mathf.Abs(px - lane * gm.Config.laneWidth) > 0.05f;
            bool fromSide = changingLane && transform.position.z > col.bounds.min.z + 0.6f;

            if (fromSide)
            {
                // bumped the side of something: bounce back to the old lane and stumble
                int tmp = lane; lane = previousLane; previousLane = tmp;
                gm.CameraRig.Shake(0.2f, 0.25f);
                if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Stumble);
                if (stumbleTimer > 0f) { Crash(); return; }   // second stumble in a short time = caught!
                stumbleTimer = 3f;
                return;
            }

            if (gm.PowerUps.IsActive(PowerUpType.WaterShield))
            {
                gm.PowerUps.ConsumeShield();
                Smash(o);
                invincibleTimer = 1.0f;
                if (HoliFX.Instance != null) HoliFX.Instance.Burst(transform.position + Vector3.up, Palette.Cyan, 40, 1.4f);
                return;
            }
            Crash();
        }

        void Smash(Obstacle o)
        {
            if (HoliFX.Instance != null) HoliFX.Instance.Explosion(o.transform.position + Vector3.up * 1.2f, 1f);
            if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Crash, 0.5f, 1.4f);
            gm.CameraRig.Shake(0.15f, 0.2f);
            o.root.SetActive(false);
        }

        void Crash()
        {
            Alive = false;
            slideTimer = 0f; SetCapsule(false);
            Visual.SetVisible(true);
            Visual.SetTrail(false, false);
            if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Crash);
            if (HoliFX.Instance != null) HoliFX.Instance.Explosion(transform.position + Vector3.up, 0.8f);
            gm.CameraRig.Shake(0.45f, 0.4f);
            gm.OnPlayerCrashed();
        }

        /// <summary>Revive safely: obstacles near/ahead are cleared and the player blinks invincible.</summary>
        public void Revive()
        {
            Alive = true;
            Visual.ResetPose();
            x = lane * gm.Config.laneWidth;
            vy = 0f; slideTimer = 0f; queuedSlide = false; stumbleTimer = 0f;
            SetCapsule(false);
            feetY = GroundHeight(new Vector3(x, feetY, transform.position.z));
            grounded = true;
            transform.position = new Vector3(x, feetY, transform.position.z);
            invincibleTimer = 2.5f;
        }
    }
}
