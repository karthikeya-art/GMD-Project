using System.Collections.Generic;
using UnityEngine;

namespace HoliRush
{
    public enum PoseMode { Idle, Run, Jump, Slide, Dead }

    /// <summary>
    /// The original treasure-hunter character ("Rangu"), built from primitives and animated
    /// procedurally (no Animator needed): run cycle, jump tuck, slide, crash.
    /// Clothes gradually get covered in Holi colours as the run goes on.
    /// </summary>
    public class PlayerVisual : MonoBehaviour
    {
        Transform model, hips, torso, armL, armR, legL, legR, scarf;
        GameObject shield, magnetIcon;
        TrailRenderer trail;
        readonly List<GameObject> splashes = new List<GameObject>();
        float phase;
        float deadT;

        public void Build()
        {
            model = ShapeFactory.Root("Model", transform).transform;
            hips = ShapeFactory.Root("Hips", model).transform;
            hips.localPosition = new Vector3(0, 0.95f, 0);

            Color kurta = Palette.Cream, pants = new Color(0.2f, 0.55f, 0.85f), skin = Palette.Skin;

            torso = ShapeFactory.Root("Torso", hips).transform;
            ShapeFactory.Prim(PrimitiveType.Capsule, torso, new Vector3(0, 0.38f, 0), new Vector3(0.62f, 0.42f, 0.42f), Palette.Lit(kurta), null, true);
            ShapeFactory.Prim(PrimitiveType.Cylinder, torso, new Vector3(0, 0.05f, 0), new Vector3(0.66f, 0.06f, 0.46f), Palette.Lit(Palette.Magenta)); // sash
            // head
            var head = ShapeFactory.Root("Head", torso).transform;
            head.localPosition = new Vector3(0, 0.98f, 0);
            ShapeFactory.Prim(PrimitiveType.Sphere, head, Vector3.zero, Vector3.one * 0.46f, Palette.Lit(skin), null, true);
            ShapeFactory.Prim(PrimitiveType.Sphere, head, new Vector3(0, 0.08f, -0.03f), new Vector3(0.48f, 0.38f, 0.48f), Palette.Lit(Palette.Dark));
            ShapeFactory.Prim(PrimitiveType.Cylinder, head, new Vector3(0, 0.12f, 0), new Vector3(0.5f, 0.05f, 0.5f), Palette.Lit(Palette.Orange)); // bandana
            ShapeFactory.Prim(PrimitiveType.Cube, head, new Vector3(0.05f, 0.1f, -0.27f), new Vector3(0.08f, 0.06f, 0.25f), Palette.Lit(Palette.Orange), new Vector3(20, 15, 0));
            ShapeFactory.Prim(PrimitiveType.Sphere, head, new Vector3(-0.09f, 0.02f, 0.21f), Vector3.one * 0.06f, Palette.Lit(Palette.Dark));
            ShapeFactory.Prim(PrimitiveType.Sphere, head, new Vector3(0.09f, 0.02f, 0.21f), Vector3.one * 0.06f, Palette.Lit(Palette.Dark));
            // gulal on cheeks
            ShapeFactory.Prim(PrimitiveType.Sphere, head, new Vector3(-0.15f, -0.06f, 0.17f), new Vector3(0.1f, 0.06f, 0.04f), Palette.Lit(Palette.Pink));
            ShapeFactory.Prim(PrimitiveType.Sphere, head, new Vector3(0.15f, -0.06f, 0.17f), new Vector3(0.1f, 0.06f, 0.04f), Palette.Lit(Palette.Green));
            // backpack (faces the camera)
            ShapeFactory.Prim(PrimitiveType.Cube, torso, new Vector3(0, 0.45f, -0.3f), new Vector3(0.45f, 0.5f, 0.22f), Palette.Lit(Palette.Orange), null, true);
            ShapeFactory.Prim(PrimitiveType.Cube, torso, new Vector3(0, 0.6f, -0.42f), new Vector3(0.35f, 0.12f, 0.04f), Palette.Lit(Palette.Yellow));
            ShapeFactory.Prim(PrimitiveType.Cylinder, torso, new Vector3(0, 0.75f, -0.32f), new Vector3(0.12f, 0.2f, 0.12f), Palette.Lit(Palette.Wood), new Vector3(0, 0, 90)); // map roll
            // scarf
            scarf = ShapeFactory.Root("Scarf", torso).transform;
            scarf.localPosition = new Vector3(0, 0.78f, -0.15f);
            ShapeFactory.Prim(PrimitiveType.Cube, scarf, new Vector3(0, 0, -0.25f), new Vector3(0.14f, 0.04f, 0.5f), Palette.Lit(Palette.Purple));

            armL = Limb("ArmL", torso, new Vector3(-0.38f, 0.7f, 0), 0.62f, 0.13f, kurta, skin);
            armR = Limb("ArmR", torso, new Vector3(0.38f, 0.7f, 0), 0.62f, 0.13f, kurta, skin);
            legL = Limb("LegL", hips, new Vector3(-0.15f, 0f, 0), 0.82f, 0.17f, pants, Palette.Red);
            legR = Limb("LegR", hips, new Vector3(0.15f, 0f, 0), 0.82f, 0.17f, pants, Palette.Red);

            // hidden colour splashes revealed during the run
            for (int i = 0; i < 16; i++)
            {
                Transform parent = i < 10 ? torso : (i % 2 == 0 ? legL : legR);
                Vector3 p = i < 10
                    ? new Vector3(Random.Range(-0.28f, 0.28f), Random.Range(0.1f, 0.7f), (i % 2 == 0 ? 0.21f : -0.21f))
                    : new Vector3(0, -Random.Range(0.15f, 0.6f), (i % 4 < 2 ? 0.09f : -0.09f));
                float s = Random.Range(0.12f, 0.22f);
                var g = ShapeFactory.Prim(PrimitiveType.Sphere, parent, p, new Vector3(s, s, s * 0.3f), Palette.Lit(Palette.Powder[i % Palette.Powder.Length]));
                g.SetActive(false);
                splashes.Add(g);
            }

            // blob shadow (cheap replacement for real-time shadows on mobile)
            var shadow = ShapeFactory.Prim(PrimitiveType.Cylinder, transform, new Vector3(0, 0.02f, 0), new Vector3(0.9f, 0.005f, 0.9f),
                                           Palette.Transparent(new Color(0, 0, 0, 0.35f)));
            shadow.name = "BlobShadow";

            // Water Shield bubble
            shield = ShapeFactory.Prim(PrimitiveType.Sphere, transform, new Vector3(0, 1.0f, 0), new Vector3(1.9f, 2.3f, 1.9f),
                                       Palette.Transparent(new Color(0.3f, 0.85f, 1f, 0.3f)));
            shield.name = "WaterShield";
            ShapeFactory.Prim(PrimitiveType.Sphere, shield.transform, new Vector3(0.2f, 0.25f, -0.35f), Vector3.one * 0.15f,
                              Palette.Transparent(new Color(1f, 1f, 1f, 0.5f)));
            shield.SetActive(false);

            magnetIcon = ShapeFactory.Root("MagnetIcon", transform);
            magnetIcon.transform.localPosition = new Vector3(0, 2.6f, 0);
            ShapeFactory.Prim(PrimitiveType.Cube, magnetIcon.transform, new Vector3(-0.12f, 0, 0), new Vector3(0.08f, 0.3f, 0.08f), Palette.Glow(Palette.Red));
            ShapeFactory.Prim(PrimitiveType.Cube, magnetIcon.transform, new Vector3(0.12f, 0, 0), new Vector3(0.08f, 0.3f, 0.08f), Palette.Glow(Palette.Red));
            ShapeFactory.Prim(PrimitiveType.Cube, magnetIcon.transform, new Vector3(0, -0.15f, 0), new Vector3(0.32f, 0.08f, 0.08f), Palette.Glow(Palette.Red));
            magnetIcon.SetActive(false);

            // Colour trail
            var trailGo = ShapeFactory.Root("ColorTrail", transform);
            trailGo.transform.localPosition = new Vector3(0, 1.0f, -0.3f);
            trail = trailGo.AddComponent<TrailRenderer>();
            trail.time = 0.45f;
            trail.minVertexDistance = 0.3f;
            trail.widthCurve = AnimationCurve.Linear(0, 1.1f, 1, 0f);
            trail.sharedMaterial = Palette.Particle();
            trail.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            trail.emitting = false;
        }

        Transform Limb(string name, Transform parent, Vector3 pivot, float length, float thick, Color c, Color end)
        {
            var p = ShapeFactory.Root(name, parent).transform;
            p.localPosition = pivot;
            ShapeFactory.Prim(PrimitiveType.Capsule, p, new Vector3(0, -length * 0.5f, 0), new Vector3(thick, length * 0.5f, thick), Palette.Lit(c), null, true);
            ShapeFactory.Prim(PrimitiveType.Cube, p, new Vector3(0, -length, thick * 0.4f), new Vector3(thick * 1.3f, thick * 0.8f, thick * 2.2f), Palette.Lit(end));
            return p;
        }

        public void SetColorLevel(int level)
        {
            for (int i = 0; i < splashes.Count; i++) splashes[i].SetActive(i < level);
        }

        public void SetShield(bool on) { if (shield != null) shield.SetActive(on); }
        public void SetMagnet(bool on) { if (magnetIcon != null) magnetIcon.SetActive(on); }

        public void SetTrail(bool on, bool rainbow)
        {
            if (trail == null) return;
            trail.emitting = on;
            var g = new Gradient();
            if (rainbow)
                g.SetKeys(new[] { new GradientColorKey(Palette.Red, 0f), new GradientColorKey(Palette.Yellow, 0.25f),
                                  new GradientColorKey(Palette.Green, 0.5f), new GradientColorKey(Palette.Blue, 0.75f),
                                  new GradientColorKey(Palette.Purple, 1f) },
                          new[] { new GradientAlphaKey(0.9f, 0f), new GradientAlphaKey(0f, 1f) });
            else
                g.SetKeys(new[] { new GradientColorKey(Palette.Magenta, 0f), new GradientColorKey(Palette.Cyan, 1f) },
                          new[] { new GradientAlphaKey(0.8f, 0f), new GradientAlphaKey(0f, 1f) });
            trail.colorGradient = g;
        }

        public void ClearTrail() { if (trail != null) trail.Clear(); }

        public void SetVisible(bool v) { if (model != null) model.gameObject.SetActive(v); }

        public void ResetPose()
        {
            deadT = 0f;
            model.localPosition = Vector3.zero;
            model.localRotation = Quaternion.identity;
            SetVisible(true);
        }

        public void Animate(PoseMode mode, float speed, float dt)
        {
            if (model == null) return;
            float legLA = 0f, legRA = 0f, armLA = 0f, armRA = 0f, armSpread = 0f, bodyPitch = 0f, y = 0f;
            switch (mode)
            {
                case PoseMode.Idle:
                    phase += dt * 2f;
                    armLA = Mathf.Sin(phase) * 6f; armRA = -armLA;
                    y = Mathf.Sin(phase * 2f) * 0.02f;
                    break;
                case PoseMode.Run:
                    phase += dt * (6f + speed * 0.35f);
                    legLA = Mathf.Sin(phase) * 50f; legRA = -legLA;
                    armLA = -Mathf.Sin(phase) * 45f; armRA = -armLA;
                    y = Mathf.Abs(Mathf.Sin(phase)) * 0.09f;
                    bodyPitch = 8f;
                    break;
                case PoseMode.Jump:
                    legLA = -35f; legRA = 40f; armLA = armRA = -150f; armSpread = 25f; bodyPitch = 4f;
                    break;
                case PoseMode.Slide:
                    bodyPitch = -62f; legLA = legRA = -20f; armLA = armRA = 30f; y = -0.35f;
                    break;
                case PoseMode.Dead:
                    deadT = Mathf.Min(1f, deadT + dt * 3f);
                    bodyPitch = Mathf.Lerp(0f, -85f, deadT); y = Mathf.Lerp(0f, -0.6f, deadT);
                    armLA = armRA = -120f; legLA = 15f; legRA = -10f;
                    break;
            }
            float k = 1f - Mathf.Exp(-20f * dt);
            model.localPosition = Vector3.Lerp(model.localPosition, new Vector3(0, y, 0), mode == PoseMode.Run ? 1f : k);
            hips.localRotation = Quaternion.Slerp(hips.localRotation, Quaternion.Euler(bodyPitch, 0, 0), k);
            legL.localRotation = Quaternion.Slerp(legL.localRotation, Quaternion.Euler(legLA, 0, 0), k);
            legR.localRotation = Quaternion.Slerp(legR.localRotation, Quaternion.Euler(legRA, 0, 0), k);
            armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(armLA, 0, -armSpread), k);
            armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(armRA, 0, armSpread), k);
            if (scarf != null) scarf.localRotation = Quaternion.Euler(Mathf.Sin(phase * 1.7f) * 12f + 8f, 0, 0);
        }
    }
}
