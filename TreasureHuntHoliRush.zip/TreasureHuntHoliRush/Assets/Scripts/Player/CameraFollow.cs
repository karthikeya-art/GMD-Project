using UnityEngine;

namespace HoliRush
{
    /// <summary>
    /// Smooth third-person runner camera: rigid on Z (no lag = you always see what's coming),
    /// smoothed on X/Y, slight roll when changing lanes, optional shake and Rainbow Dash FOV kick.
    /// </summary>
    public class CameraFollow : MonoBehaviour
    {
        public Vector3 offset = new Vector3(0f, 4.4f, -7.4f);
        public float lookAhead = 9f;
        public float baseFov = 62f;
        public float dashFov = 74f;

        GameManager gm;
        Camera cam;
        float x, y, roll, lastTargetX;
        float shakeTime, shakeAmount, shakeDuration;
        float menuAngle;
        float blend = 1f;

        /// <summary>Smoothly fly from the menu shot to the gameplay shot.</summary>
        public void BeginBlend() { blend = 0f; }

        public void Init(GameManager g, Camera c)
        {
            gm = g; cam = c;
            cam.fieldOfView = baseFov;
            cam.nearClipPlane = 0.3f;
            cam.farClipPlane = 320f;
        }

        public void Shake(float amount, float duration)
        {
            shakeAmount = Mathf.Max(shakeAmount * (shakeTime > 0 ? 1 : 0), amount);
            shakeDuration = duration;
            shakeTime = duration;
        }

        public void Snap()
        {
            if (gm == null || gm.Player == null) return;
            var p = gm.Player.transform.position;
            x = p.x; y = p.y; roll = 0f; lastTargetX = p.x;
            LateUpdate();
        }

        void LateUpdate()
        {
            if (gm == null || gm.Player == null) return;
            float dt = Time.unscaledDeltaTime;
            Vector3 p = gm.Player.transform.position;

            if (gm.State == GameState.Menu)
            {
                // slow cinematic swing in front of the hero on the menu
                menuAngle += dt * 12f;
                float a = (Mathf.Sin(menuAngle * Mathf.Deg2Rad) * 35f + 180f) * Mathf.Deg2Rad;
                Vector3 camPos = p + new Vector3(Mathf.Sin(a) * 6.5f, 2.4f, -Mathf.Cos(a) * 6.5f);
                transform.position = Vector3.Lerp(transform.position, camPos, 1f - Mathf.Exp(-3f * dt));
                transform.rotation = Quaternion.LookRotation((p + Vector3.up * 1.4f) - transform.position);
                cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, 50f, 1f - Mathf.Exp(-3f * dt));
                return;
            }

            if (gm.State == GameState.Paused) return;
            float k = 1f - Mathf.Exp(-8f * dt);
            x = Mathf.Lerp(x, p.x * 0.75f, k);
            y = Mathf.Lerp(y, p.y, 1f - Mathf.Exp(-5f * dt));
            float lateralVel = dt > 0f ? (p.x - lastTargetX) / dt : 0f;
            lastTargetX = p.x;
            roll = Mathf.Lerp(roll, Mathf.Clamp(-lateralVel * 0.25f, -3f, 3f), k);

            Vector3 pos = new Vector3(x + offset.x, y * 0.7f + offset.y, p.z + offset.z);
            Vector3 look = new Vector3(x * 0.9f, y * 0.7f + 1.3f, p.z + lookAhead);

            if (shakeTime > 0f)
            {
                shakeTime -= dt;
                float s = shakeAmount * Mathf.Clamp01(shakeTime / Mathf.Max(0.01f, shakeDuration));
                pos += new Vector3(Random.Range(-s, s), Random.Range(-s, s), 0f);
            }

            Quaternion rot = Quaternion.LookRotation(look - pos) * Quaternion.Euler(0, 0, roll);
            if (blend < 1f)
            {
                blend = Mathf.Min(1f, blend + dt * 1.6f);
                float b = Mathf.SmoothStep(0f, 1f, blend);
                transform.position = Vector3.Lerp(transform.position, pos, b);
                transform.rotation = Quaternion.Slerp(transform.rotation, rot, b);
            }
            else
            {
                transform.position = pos;
                transform.rotation = rot;
            }

            bool dash = gm.PowerUps != null && gm.PowerUps.IsActive(PowerUpType.RainbowDash) && gm.State == GameState.Playing;
            float speedFov = Mathf.Lerp(0f, 4f, (gm.CurrentSpeed - gm.Config.startSpeed) / Mathf.Max(1f, gm.Config.maxSpeed - gm.Config.startSpeed));
            cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, (dash ? dashFov : baseFov) + speedFov, 1f - Mathf.Exp(-4f * dt));
        }
    }
}
