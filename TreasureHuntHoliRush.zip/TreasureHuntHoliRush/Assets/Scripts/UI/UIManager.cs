using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace HoliRush
{
    /// <summary>
    /// Builds the whole Holi-themed UI in code (Main Menu, HUD, Pause, Game Over, Settings)
    /// and wires every button to the GameManager - nothing to hook up in the Inspector.
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        GameManager gm;
        Font font;
        Sprite rounded, dot;
        RectTransform canvasRect;

        GameObject menuPanel, hudPanel, pausePanel, overPanel, settingsPanel;
        Text menuBest, menuWallet, soundLabelMenu, soundLabelSettings;
        Text hudScore, hudDistance, hudCoins, hudGems, hudTokens, hudKeys, hudMultiplier;
        GameObject powerBar; Image powerFill; Text powerName;
        Text toastText; float toastTimer;
        Text overScore, overBest, overDistance, overCoins, overGems, overWallet, overNewBest;
        Button reviveButton; Text reviveLabel;
        readonly List<RectTransform> splashes = new List<RectTransform>();
        GameObject settingsReturn;

        int lastScore = -1, lastCoins = -1, lastGems = -1, lastTokens = -1, lastKeys = -1, lastDist = -1;

        public void Init(GameManager g)
        {
            gm = g;
            font = Palette.BuiltinFont();
            rounded = MakeRoundedSprite();
            dot = Sprite.Create(Palette.SoftDot(), new Rect(0, 0, 64, 64), new Vector2(0.5f, 0.5f));

            var canvasGo = new GameObject("HoliCanvas");
            canvasGo.transform.SetParent(transform, false);
            var canvas = canvasGo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;
            var scaler = canvasGo.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080, 1920);
            scaler.matchWidthOrHeight = 0.5f;
            canvasGo.AddComponent<GraphicRaycaster>();
            canvasRect = canvasGo.GetComponent<RectTransform>();

            BuildMenu();
            BuildHud();
            BuildPause();
            BuildGameOver();
            BuildSettings();
            BuildToast();

            gm.StateChanged += OnState;
            gm.Toast += OnToast;
        }

        // ================================================================== helpers
        static Sprite MakeRoundedSprite()
        {
            const int n = 64, r = 22;
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            var px = new Color[n * n];
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float cx = Mathf.Clamp(x + 0.5f, r, n - r), cy = Mathf.Clamp(y + 0.5f, r, n - r);
                    float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(cx, cy));
                    px[y * n + x] = new Color(1, 1, 1, Mathf.Clamp01(r - d + 0.5f));
                }
            tex.SetPixels(px); tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(r, r, r, r));
        }

        static RectTransform Rect(GameObject go, Vector2 anchor, Vector2 pos, Vector2 size)
        {
            var rt = go.GetComponent<RectTransform>();
            if (rt == null) rt = go.AddComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = anchor;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
            return rt;
        }

        GameObject Panel(Transform parent, string name, bool fullScreen, Color color, Vector2 size)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            if (fullScreen)
            {
                rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
                rt.offsetMin = rt.offsetMax = Vector2.zero;
            }
            else Rect(go, new Vector2(0.5f, 0.5f), Vector2.zero, size);
            if (color.a > 0f)
            {
                var img = go.AddComponent<Image>();
                img.color = color;
                if (!fullScreen) { img.sprite = rounded; img.type = Image.Type.Sliced; }
            }
            return go;
        }

        Text Label(Transform parent, string text, int size, Color color, Vector2 anchor, Vector2 pos, Vector2 box, TextAnchor align = TextAnchor.MiddleCenter, bool outline = true)
        {
            var go = new GameObject("Text", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            Rect(go, anchor, pos, box);
            var t = go.AddComponent<Text>();
            t.font = font; t.text = text; t.fontSize = size; t.color = color;
            t.alignment = align; t.fontStyle = FontStyle.Bold;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            if (outline)
            {
                var o = go.AddComponent<Outline>();
                o.effectColor = new Color(0.2f, 0.05f, 0.25f, 0.85f);
                o.effectDistance = new Vector2(3, -3);
            }
            return t;
        }

        Button MakeButton(Transform parent, string label, Color color, Vector2 anchor, Vector2 pos, Vector2 size, UnityAction onClick, int fontSize = 52)
        {
            var go = new GameObject("Button_" + label, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            Rect(go, anchor, pos, size);
            var img = go.AddComponent<Image>();
            img.sprite = rounded; img.type = Image.Type.Sliced; img.color = color;
            var shadow = go.AddComponent<Shadow>();
            shadow.effectColor = new Color(0.25f, 0.05f, 0.3f, 0.6f); shadow.effectDistance = new Vector2(0, -8);
            var b = go.AddComponent<Button>();
            var cb = b.colors;
            cb.highlightedColor = new Color(1f, 1f, 1f, 1f); cb.pressedColor = new Color(0.8f, 0.8f, 0.8f, 1f);
            cb.disabledColor = new Color(0.55f, 0.55f, 0.55f, 0.7f);
            b.colors = cb;
            b.onClick.AddListener(() => { if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.Click); });
            b.onClick.AddListener(onClick);
            var t = Label(go.transform, label, fontSize, Color.white, new Vector2(0.5f, 0.5f), Vector2.zero, size);
            t.name = "Label";
            return b;
        }

        Image Splash(Transform parent, Vector2 anchor, Vector2 pos, float size, Color c)
        {
            var go = new GameObject("Splash", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var rt = Rect(go, anchor, pos, new Vector2(size, size * Random.Range(0.7f, 1f)));
            rt.localRotation = Quaternion.Euler(0, 0, Random.Range(0f, 360f));
            var img = go.AddComponent<Image>();
            img.sprite = dot; img.color = c; img.raycastTarget = false;
            splashes.Add(rt);
            return img;
        }

        Image Icon(Transform parent, Vector2 anchor, Vector2 pos, float size, Color c)
        {
            var go = new GameObject("Icon", typeof(RectTransform));
            go.transform.SetParent(parent, false);
            Rect(go, anchor, pos, new Vector2(size, size));
            var img = go.AddComponent<Image>();
            img.sprite = rounded; img.type = Image.Type.Sliced; img.color = c; img.raycastTarget = false;
            return img;
        }

        // ================================================================== screens
        void BuildMenu()
        {
            menuPanel = Panel(canvasRect, "MainMenu", true, new Color(0.15f, 0.02f, 0.2f, 0.25f), Vector2.zero);
            var t = menuPanel.transform;
            Vector2 c = new Vector2(0.5f, 0.5f);
            for (int i = 0; i < 9; i++)
                Splash(t, c, new Vector2(Random.Range(-460f, 460f), Random.Range(250f, 760f)), Random.Range(180f, 380f),
                       new Color(Palette.Powder[i % 8].r, Palette.Powder[i % 8].g, Palette.Powder[i % 8].b, 0.75f));
            Label(t, "TREASURE HUNT", 118, Palette.Yellow, c, new Vector2(0, 600), new Vector2(1000, 160));
            Label(t, "HOLI RUSH", 150, Palette.Magenta, c, new Vector2(0, 450), new Vector2(1000, 180));
            Label(t, "Run the festival. Catch the colours.", 40, Color.white, c, new Vector2(0, 340), new Vector2(1000, 60));

            menuBest = Label(t, "BEST 0", 52, Color.white, c, new Vector2(0, -230), new Vector2(1000, 70));
            menuWallet = Label(t, "", 44, Palette.Gold, c, new Vector2(0, -300), new Vector2(1000, 60));

            MakeButton(t, "PLAY", Palette.Magenta, c, new Vector2(0, -440), new Vector2(560, 170), () => gm.StartRun(), 84);
            var s = MakeButton(t, "SOUND: ON", Palette.Purple, c, new Vector2(-150, -620), new Vector2(380, 110), ToggleSound, 40);
            soundLabelMenu = s.transform.Find("Label").GetComponent<Text>();
            MakeButton(t, "SETTINGS", Palette.Blue, c, new Vector2(240, -620), new Vector2(330, 110), () => OpenSettings(menuPanel), 40);
            Label(t, "PC: Arrows/WASD move & jump/slide, Space jump, Esc pause   |   Mobile: swipe", 28,
                  new Color(1, 1, 1, 0.9f), c, new Vector2(0, -740), new Vector2(1000, 50));
        }

        void BuildHud()
        {
            hudPanel = Panel(canvasRect, "HUD", true, Color.clear, Vector2.zero);
            var t = hudPanel.transform;
            Vector2 tl = new Vector2(0f, 1f), tr = new Vector2(1f, 1f), top = new Vector2(0.5f, 1f);

            Panel(t, "ScoreBack", false, new Color(0.3f, 0.05f, 0.4f, 0.45f), new Vector2(430, 170));
            var sb = t.Find("ScoreBack").GetComponent<RectTransform>();
            sb.anchorMin = sb.anchorMax = tl; sb.anchoredPosition = new Vector2(245, -120);
            hudScore = Label(t, "0", 72, Color.white, tl, new Vector2(245, -95), new Vector2(420, 90));
            hudDistance = Label(t, "0 m", 36, Palette.Yellow, tl, new Vector2(245, -165), new Vector2(420, 50));
            hudMultiplier = Label(t, "", 48, Palette.Yellow, tl, new Vector2(245, -235), new Vector2(420, 60));

            float y = -85f;
            hudCoins = Counter(t, tr, ref y, Palette.Gold);
            hudGems = Counter(t, tr, ref y, Palette.Cyan);
            hudTokens = Counter(t, tr, ref y, Palette.Magenta);
            hudKeys = Counter(t, tr, ref y, Palette.Orange);

            MakeButton(t, "II", new Color(0.55f, 0.25f, 0.9f, 0.9f), top, new Vector2(0, -90), new Vector2(120, 120), () => gm.Pause(), 54);

            powerBar = Panel(t, "PowerUpBar", false, new Color(0.15f, 0.05f, 0.2f, 0.55f), new Vector2(600, 90));
            var pr = powerBar.GetComponent<RectTransform>();
            pr.anchorMin = pr.anchorMax = new Vector2(0.5f, 0f); pr.anchoredPosition = new Vector2(0, 170);
            var fillGo = new GameObject("Fill", typeof(RectTransform));
            fillGo.transform.SetParent(powerBar.transform, false);
            var frt = fillGo.GetComponent<RectTransform>();
            frt.anchorMin = new Vector2(0, 0); frt.anchorMax = new Vector2(1, 1);
            frt.offsetMin = new Vector2(10, 10); frt.offsetMax = new Vector2(-10, -10);
            powerFill = fillGo.AddComponent<Image>();
            var white = new Texture2D(1, 1); white.SetPixel(0, 0, Color.white); white.Apply();
            powerFill.sprite = Sprite.Create(white, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f));
            powerFill.type = Image.Type.Filled; powerFill.fillMethod = Image.FillMethod.Horizontal;
            powerFill.raycastTarget = false;
            powerName = Label(powerBar.transform, "", 40, Color.white, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(600, 90));
            powerBar.SetActive(false);
        }

        Text Counter(Transform t, Vector2 anchor, ref float y, Color iconColor)
        {
            var back = Panel(t, "CounterBack", false, new Color(0.3f, 0.05f, 0.4f, 0.45f), new Vector2(300, 78));
            var br = back.GetComponent<RectTransform>();
            br.anchorMin = br.anchorMax = anchor; br.anchoredPosition = new Vector2(-180, y);
            Icon(back.transform, new Vector2(0f, 0.5f), new Vector2(42, 0), 52, iconColor);
            var txt = Label(back.transform, "0", 46, Color.white, new Vector2(0.5f, 0.5f), new Vector2(30, 0), new Vector2(220, 70), TextAnchor.MiddleRight);
            y -= 92f;
            return txt;
        }

        void BuildPause()
        {
            pausePanel = Panel(canvasRect, "PauseMenu", true, new Color(0.1f, 0.0f, 0.15f, 0.6f), Vector2.zero);
            var box = Panel(pausePanel.transform, "Box", false, new Color(1f, 0.95f, 0.98f, 0.95f), new Vector2(760, 900)).transform;
            Vector2 c = new Vector2(0.5f, 0.5f);
            Label(box, "PAUSED", 100, Palette.Magenta, c, new Vector2(0, 330), new Vector2(700, 130));
            MakeButton(box, "RESUME", Palette.Green, c, new Vector2(0, 150), new Vector2(560, 130), () => gm.Resume());
            MakeButton(box, "RESTART", Palette.Orange, c, new Vector2(0, 0), new Vector2(560, 130), () => gm.Retry());
            MakeButton(box, "HOME", Palette.Blue, c, new Vector2(0, -150), new Vector2(560, 130), () => gm.GoToMenu());
            MakeButton(box, "SETTINGS", Palette.Purple, c, new Vector2(0, -300), new Vector2(560, 130), () => OpenSettings(pausePanel));
        }

        void BuildGameOver()
        {
            overPanel = Panel(canvasRect, "GameOver", true, new Color(0.1f, 0.0f, 0.15f, 0.55f), Vector2.zero);
            var box = Panel(overPanel.transform, "Box", false, new Color(1f, 0.95f, 0.98f, 0.96f), new Vector2(860, 1150)).transform;
            Vector2 c = new Vector2(0.5f, 0.5f);
            for (int i = 0; i < 5; i++)
                Splash(box, new Vector2(0.5f, 1f), new Vector2(-340 + i * 170, -40), 170, new Color(Palette.Powder[i].r, Palette.Powder[i].g, Palette.Powder[i].b, 0.8f));
            Label(box, "CAUGHT IN THE COLOURS!", 64, Palette.Magenta, c, new Vector2(0, 460), new Vector2(820, 90));
            overNewBest = Label(box, "NEW BEST!", 52, Palette.Orange, c, new Vector2(0, 380), new Vector2(820, 70));
            overScore = Label(box, "0", 120, Palette.Purple, c, new Vector2(0, 280), new Vector2(820, 140));
            overBest = Label(box, "", 44, Palette.Dark, c, new Vector2(0, 180), new Vector2(820, 60), TextAnchor.MiddleCenter, false);
            overDistance = Label(box, "", 44, Palette.Dark, c, new Vector2(0, 120), new Vector2(820, 60), TextAnchor.MiddleCenter, false);
            overCoins = Label(box, "", 44, Palette.Dark, c, new Vector2(0, 60), new Vector2(820, 60), TextAnchor.MiddleCenter, false);
            overGems = Label(box, "", 44, Palette.Dark, c, new Vector2(0, 0), new Vector2(820, 60), TextAnchor.MiddleCenter, false);
            overWallet = Label(box, "", 36, Palette.Blue, c, new Vector2(0, -60), new Vector2(820, 50), TextAnchor.MiddleCenter, false);
            reviveButton = MakeButton(box, "REVIVE", Palette.Cyan, c, new Vector2(0, -180), new Vector2(620, 140), () => gm.TryRevive(), 50);
            reviveLabel = reviveButton.transform.Find("Label").GetComponent<Text>();
            MakeButton(box, "RETRY", Palette.Magenta, c, new Vector2(0, -350), new Vector2(620, 140), () => gm.Retry(), 60);
            MakeButton(box, "HOME", Palette.Blue, c, new Vector2(0, -500), new Vector2(620, 120), () => gm.GoToMenu(), 50);
        }

        void BuildSettings()
        {
            settingsPanel = Panel(canvasRect, "Settings", true, new Color(0.1f, 0.0f, 0.15f, 0.7f), Vector2.zero);
            var box = Panel(settingsPanel.transform, "Box", false, new Color(1f, 0.95f, 0.98f, 0.97f), new Vector2(760, 760)).transform;
            Vector2 c = new Vector2(0.5f, 0.5f);
            Label(box, "SETTINGS", 90, Palette.Purple, c, new Vector2(0, 270), new Vector2(700, 120));
            var s = MakeButton(box, "SOUND: ON", Palette.Green, c, new Vector2(0, 100), new Vector2(560, 130), ToggleSound);
            soundLabelSettings = s.transform.Find("Label").GetComponent<Text>();
            MakeButton(box, "RESET PROGRESS", Palette.Red, c, new Vector2(0, -50), new Vector2(560, 120), () =>
            {
                SaveManager.ResetProgress();
                SaveManager.EnsureInitialised(gm.Config.startingGems);
                RefreshMenu();
                gm.ShowToast("PROGRESS RESET", Palette.Orange);
            }, 44);
            MakeButton(box, "BACK", Palette.Blue, c, new Vector2(0, -230), new Vector2(560, 130), CloseSettings);
            settingsPanel.SetActive(false);
        }

        void BuildToast()
        {
            toastText = Label(canvasRect, "", 70, Palette.Yellow, new Vector2(0.5f, 0.7f), Vector2.zero, new Vector2(1000, 120));
            toastText.gameObject.SetActive(false);
        }

        // ================================================================== behaviour
        void ToggleSound()
        {
            SaveManager.SoundOn = !SaveManager.SoundOn;
            if (AudioManager.Instance != null) AudioManager.Instance.ApplySoundSetting();
            RefreshSoundLabels();
        }

        void RefreshSoundLabels()
        {
            string s = SaveManager.SoundOn ? "SOUND: ON" : "SOUND: OFF";
            if (soundLabelMenu != null) soundLabelMenu.text = s;
            if (soundLabelSettings != null) soundLabelSettings.text = s;
        }

        void OpenSettings(GameObject from)
        {
            settingsReturn = from;
            if (from != null) from.SetActive(false);
            settingsPanel.SetActive(true);
            RefreshSoundLabels();
        }

        void CloseSettings()
        {
            settingsPanel.SetActive(false);
            if (settingsReturn != null) settingsReturn.SetActive(true);
            else OnState(gm.State);
        }

        void RefreshMenu()
        {
            menuBest.text = "BEST  " + SaveManager.BestScore.ToString("N0");
            menuWallet.text = "COINS " + SaveManager.Coins.ToString("N0") + "    GEMS " + SaveManager.Gems + "    KEYS " + SaveManager.Keys;
            RefreshSoundLabels();
        }

        void OnState(GameState s)
        {
            settingsPanel.SetActive(false);
            menuPanel.SetActive(s == GameState.Menu);
            hudPanel.SetActive(s == GameState.Playing || s == GameState.Paused);
            pausePanel.SetActive(s == GameState.Paused);
            overPanel.SetActive(s == GameState.GameOver);
            if (s == GameState.Menu) RefreshMenu();
            if (s == GameState.GameOver) RefreshGameOver();
            if (s == GameState.Playing) lastScore = lastCoins = lastGems = lastTokens = lastKeys = lastDist = -1;
        }

        void RefreshGameOver()
        {
            overScore.text = Mathf.FloorToInt(gm.Score).ToString("N0");
            overNewBest.gameObject.SetActive(gm.NewBest);
            overBest.text = "Best Score:  " + SaveManager.BestScore.ToString("N0");
            overDistance.text = "Distance:  " + Mathf.FloorToInt(gm.Distance) + " m";
            overCoins.text = "Coins Collected:  " + gm.RunCoins;
            overGems.text = "Gems Collected:  " + gm.RunGems;
            overWallet.text = "Your gems: " + SaveManager.Gems;
            int cost = gm.ReviveCost;
            reviveLabel.text = "REVIVE  (" + cost + " GEM" + (cost > 1 ? "S" : "") + ")";
            reviveButton.interactable = gm.CanRevive;
        }

        void OnToast(string msg, Color c)
        {
            toastText.text = msg;
            toastText.color = c;
            toastTimer = 1.4f;
            toastText.gameObject.SetActive(true);
        }

        void Update()
        {
            if (gm == null) return;
            float dt = Time.unscaledDeltaTime;
            float t = Time.unscaledTime;

            // animated colour splashes
            for (int i = 0; i < splashes.Count; i++)
            {
                if (!splashes[i].gameObject.activeInHierarchy) continue;
                float s = 1f + Mathf.Sin(t * 1.5f + i * 1.3f) * 0.08f;
                splashes[i].localScale = new Vector3(s, s, 1f);
                splashes[i].Rotate(0, 0, dt * (i % 2 == 0 ? 6f : -6f));
            }

            if (toastTimer > 0f)
            {
                toastTimer -= dt;
                float a = Mathf.Clamp01(toastTimer / 0.4f);
                var col = toastText.color; col.a = a; toastText.color = col;
                float sc = 1f + Mathf.Clamp01(toastTimer - 1.1f) * 1.2f;
                toastText.rectTransform.localScale = new Vector3(sc, sc, 1f);
                if (toastTimer <= 0f) toastText.gameObject.SetActive(false);
            }

            if (gm.State == GameState.GameOver && overPanel.activeSelf && gm.Player.Input.ConfirmPressed()) { gm.Retry(); return; }
            if (!hudPanel.activeSelf) return;

            int score = Mathf.FloorToInt(gm.Score);
            if (score != lastScore) { lastScore = score; hudScore.text = score.ToString("N0"); }
            int dist = Mathf.FloorToInt(gm.Distance);
            if (dist != lastDist) { lastDist = dist; hudDistance.text = dist + " m"; }
            if (gm.RunCoins != lastCoins) { lastCoins = gm.RunCoins; hudCoins.text = lastCoins.ToString(); }
            if (gm.RunGems != lastGems) { lastGems = gm.RunGems; hudGems.text = lastGems.ToString(); }
            if (gm.RunTokens != lastTokens) { lastTokens = gm.RunTokens; hudTokens.text = lastTokens.ToString(); }
            if (gm.RunKeys != lastKeys) { lastKeys = gm.RunKeys; hudKeys.text = lastKeys.ToString(); }
            float m = gm.ScoreMultiplier;
            hudMultiplier.text = m > 1f ? "x" + m.ToString("0") + " SCORE" : "";

            float rem, dur;
            var p = gm.PowerUps.Primary(out rem, out dur);
            bool show = p != PowerUpType.None;
            if (powerBar.activeSelf != show) powerBar.SetActive(show);
            if (show)
            {
                powerName.text = PowerUpManager.DisplayName(p);
                powerFill.color = CollectibleManager.PowerUpColor(p);
                powerFill.fillAmount = Mathf.Clamp01(rem / dur);
            }
        }
    }
}
