using System.Collections.Generic;
using UnityEngine;

namespace HoliRush
{
    public enum Sfx { Coin, Token, Gem, Jump, Slide, Crash, Stumble, PowerUp, GameOver, TrainHorn, Step, Click, Lucky }

    /// <summary>
    /// Plays all game audio. Every sound is SYNTHESISED in code at startup (original audio,
    /// no external files), so the game always has sound and never breaks if assets are missing.
    /// Optional AudioClips can be dropped into the overrides array to replace a synthesised one.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance { get; private set; }

        const int Rate = 22050;
        readonly Dictionary<Sfx, AudioClip> clips = new Dictionary<Sfx, AudioClip>();
        AudioSource music, ambience;
        AudioSource[] sfxSources;
        int nextSource;

        void Awake()
        {
            Instance = this;
            music = gameObject.AddComponent<AudioSource>();
            music.loop = true; music.volume = 0.45f; music.playOnAwake = false;
            ambience = gameObject.AddComponent<AudioSource>();
            ambience.loop = true; ambience.volume = 0.18f; ambience.playOnAwake = false;
            sfxSources = new AudioSource[6];
            for (int i = 0; i < sfxSources.Length; i++)
            {
                sfxSources[i] = gameObject.AddComponent<AudioSource>();
                sfxSources[i].playOnAwake = false;
            }
            try { BuildClips(); }
            catch (System.Exception e) { Debug.LogWarning("[HoliRush] Audio synthesis failed, continuing silently: " + e.Message); }
            ApplySoundSetting();
        }

        public void ApplySoundSetting() { AudioListener.volume = SaveManager.SoundOn ? 1f : 0f; }

        public void StartMusic()
        {
            if (music.clip != null && !music.isPlaying) music.Play();
            if (ambience.clip != null && !ambience.isPlaying) ambience.Play();
        }

        public void SetMusicPaused(bool paused)
        {
            if (paused) { music.Pause(); ambience.Pause(); }
            else { music.UnPause(); ambience.UnPause(); }
        }

        public void Play(Sfx s, float volume = 1f, float pitch = 1f)
        {
            AudioClip c;
            if (!clips.TryGetValue(s, out c) || c == null) return;
            var src = sfxSources[nextSource];
            nextSource = (nextSource + 1) % sfxSources.Length;
            src.pitch = pitch;
            src.PlayOneShot(c, volume);
        }

        // ------------------------------------------------------------------ synthesis
        static float Env(float t, float len, float attack = 0.005f)
        {
            if (t < attack) return t / attack;
            return Mathf.Clamp01(1f - (t - attack) / Mathf.Max(0.0001f, len - attack));
        }

        static AudioClip Make(string name, float seconds, System.Func<float, float> f)
        {
            int n = Mathf.CeilToInt(seconds * Rate);
            var data = new float[n];
            for (int i = 0; i < n; i++) data[i] = Mathf.Clamp(f(i / (float)Rate), -1f, 1f);
            var clip = AudioClip.Create(name, n, 1, Rate, false);
            clip.SetData(data, 0);
            return clip;
        }

        static float Sine(float hz, float t) { return Mathf.Sin(2f * Mathf.PI * hz * t); }

        void BuildClips()
        {
            var rng = new System.Random(7);
            System.Func<float> noise = () => (float)(rng.NextDouble() * 2.0 - 1.0);

            clips[Sfx.Coin] = Make("coin", 0.22f, t =>
                (t < 0.07f ? Sine(1318f, t) : Sine(1975f, t)) * Env(t, 0.22f) * 0.35f);
            clips[Sfx.Token] = Make("token", 0.35f, t =>
                (Sine(880f, t) + Sine(1108f, t) + Sine(1318f, t)) / 3f * Env(t, 0.35f) * 0.5f);
            clips[Sfx.Gem] = Make("gem", 0.5f, t =>
                (Sine(1567f + 400f * t, t) * 0.6f + Sine(2349f, t) * 0.3f) * Env(t, 0.5f) * 0.45f);
            clips[Sfx.Jump] = Make("jump", 0.2f, t =>
                Sine(260f + 1400f * t, t) * Env(t, 0.2f) * 0.35f);
            clips[Sfx.Slide] = Make("slide", 0.3f, t => noise() * 0.5f * Env(t, 0.3f, 0.03f) * 0.35f);
            clips[Sfx.Crash] = Make("crash", 0.7f, t =>
                (noise() * 0.6f + Sine(70f - 30f * t, t)) * Env(t, 0.7f) * 0.6f);
            clips[Sfx.Stumble] = Make("stumble", 0.25f, t =>
                (noise() * 0.3f + Sine(140f, t) * 0.7f) * Env(t, 0.25f) * 0.5f);
            float[] arp = { 523f, 659f, 784f, 1046f };
            clips[Sfx.PowerUp] = Make("powerup", 0.5f, t =>
            {
                int i = Mathf.Min(3, (int)(t / 0.1f));
                return (Sine(arp[i], t) * 0.7f + Sine(arp[i] * 2f, t) * 0.2f) * Env(t, 0.5f) * 0.4f;
            });
            float[] down = { 659f, 587f, 523f, 392f };
            clips[Sfx.GameOver] = Make("gameover", 1.0f, t =>
            {
                int i = Mathf.Min(3, (int)(t / 0.22f));
                return Sine(down[i], t) * Env(t, 1.0f, 0.01f) * 0.4f;
            });
            clips[Sfx.TrainHorn] = Make("horn", 0.9f, t =>
                (Sine(311f, t) + Sine(370f, t) + Sine(466f, t)) / 3f * Mathf.Clamp01(t * 20f) * Mathf.Clamp01((0.9f - t) * 6f) * 0.45f);
            clips[Sfx.Step] = Make("step", 0.06f, t => noise() * Env(t, 0.06f) * 0.25f);
            clips[Sfx.Click] = Make("click", 0.05f, t => Sine(1200f, t) * Env(t, 0.05f) * 0.3f);
            clips[Sfx.Lucky] = Make("lucky", 1.2f, t =>
            {
                float s = 0f;
                for (int k = 0; k < 5; k++) s += Sine(523f * (1f + k * 0.25f), t) * (t > k * 0.12f ? 1f : 0f);
                return s / 5f * Env(t, 1.2f) * 0.6f;
            });

            // Dhol-inspired percussion loop (original pattern), 2 bars at 128 BPM
            float beat = 60f / 128f;
            float loopLen = beat * 8f;
            int[] bass = { 0, 3, 6, 8, 11, 14 };        // in 8th notes
            int[] treble = { 2, 4, 5, 7, 10, 12, 13, 15 };
            music.clip = Make("dhol_loop", loopLen, t =>
            {
                float v = 0f;
                float eighth = beat * 0.5f;
                foreach (int b in bass)
                {
                    float dt = t - b * eighth;
                    if (dt >= 0f && dt < 0.35f) v += Sine(95f - 50f * dt, dt) * Mathf.Exp(-dt * 11f) * 0.9f;
                }
                foreach (int b in treble)
                {
                    float dt = t - b * eighth;
                    if (dt >= 0f && dt < 0.12f) v += (Sine(420f, dt) * 0.5f + noise() * 0.35f) * Mathf.Exp(-dt * 40f);
                }
                // light festive drone
                v += (Sine(220f, t) + Sine(330f, t) * 0.5f) * 0.035f;
                return v * 0.55f;
            });

            // Crowd / festival ambience: amplitude-modulated noise
            ambience.clip = Make("crowd", 4f, t =>
            {
                float mod = 0.5f + 0.3f * Sine(0.7f, t) + 0.2f * Sine(1.9f, t);
                return noise() * mod * 0.25f;
            });
        }
    }
}
