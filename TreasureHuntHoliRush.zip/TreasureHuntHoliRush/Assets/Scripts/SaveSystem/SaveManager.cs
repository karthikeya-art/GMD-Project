using UnityEngine;

namespace HoliRush
{
    /// <summary>Persistent progress stored in PlayerPrefs (works on PC and Android).</summary>
    public static class SaveManager
    {
        const string KBest = "holi_best", KCoins = "holi_coins", KGems = "holi_gems", KKeys = "holi_keys",
                     KTokens = "holi_tokens", KSound = "holi_sound", KInit = "holi_init";

        public static int BestScore { get { return PlayerPrefs.GetInt(KBest, 0); } }
        public static int Coins { get { return PlayerPrefs.GetInt(KCoins, 0); } }
        public static int Gems { get { return PlayerPrefs.GetInt(KGems, 0); } }
        public static int Keys { get { return PlayerPrefs.GetInt(KKeys, 0); } }
        public static int Tokens { get { return PlayerPrefs.GetInt(KTokens, 0); } }
        public static bool SoundOn
        {
            get { return PlayerPrefs.GetInt(KSound, 1) == 1; }
            set { PlayerPrefs.SetInt(KSound, value ? 1 : 0); PlayerPrefs.Save(); }
        }

        public static void EnsureInitialised(int startingGems)
        {
            if (PlayerPrefs.GetInt(KInit, 0) == 1) return;
            PlayerPrefs.SetInt(KInit, 1);
            PlayerPrefs.SetInt(KGems, startingGems);
            PlayerPrefs.Save();
        }

        /// <summary>Returns true if this is a new best score.</summary>
        public static bool SubmitRun(int score, int coins, int gems, int keys, int tokens)
        {
            bool best = score > BestScore;
            if (best) PlayerPrefs.SetInt(KBest, score);
            PlayerPrefs.SetInt(KCoins, Coins + coins);
            PlayerPrefs.SetInt(KGems, Gems + gems);
            PlayerPrefs.SetInt(KKeys, Keys + keys);
            PlayerPrefs.SetInt(KTokens, Tokens + tokens);
            PlayerPrefs.Save();
            return best;
        }

        public static bool TrySpendGems(int amount)
        {
            if (Gems < amount) return false;
            PlayerPrefs.SetInt(KGems, Gems - amount);
            PlayerPrefs.Save();
            return true;
        }

        public static void ResetProgress()
        {
            bool s = SoundOn;
            PlayerPrefs.DeleteKey(KBest); PlayerPrefs.DeleteKey(KCoins); PlayerPrefs.DeleteKey(KGems);
            PlayerPrefs.DeleteKey(KKeys); PlayerPrefs.DeleteKey(KTokens); PlayerPrefs.DeleteKey(KInit);
            SoundOn = s;
        }
    }
}
