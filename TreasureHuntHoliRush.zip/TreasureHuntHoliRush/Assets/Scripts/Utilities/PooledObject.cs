using System;
using UnityEngine;

namespace HoliRush
{
    /// <summary>Marks which pool an object belongs to, so it can be returned.</summary>
    public class PooledObject : MonoBehaviour
    {
        public string poolKey;
        [NonSerialized] public bool inPool;
    }
}
