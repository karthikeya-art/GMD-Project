using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace HoliRush
{
    /// <summary>
    /// Central place that creates and caches every material used by the game.
    /// Works with the Built-in render pipeline and URP. Template materials are
    /// assigned by the editor setup tool so the shaders are always included in builds.
    /// </summary>
    public static class Palette
    {
        // Holi palette
        public static readonly Color Magenta = new Color(0.93f, 0.12f, 0.62f);
        public static readonly Color Pink = new Color(1f, 0.45f, 0.72f);
        public static readonly Color Purple = new Color(0.55f, 0.25f, 0.9f);
        public static readonly Color Cyan = new Color(0.1f, 0.85f, 0.95f);
        public static readonly Color Blue = new Color(0.15f, 0.4f, 1f);
        public static readonly Color Yellow = new Color(1f, 0.86f, 0.1f);
        public static readonly Color Orange = new Color(1f, 0.52f, 0.1f);
        public static readonly Color Green = new Color(0.25f, 0.85f, 0.3f);
        public static readonly Color Red = new Color(0.95f, 0.18f, 0.2f);
        public static readonly Color Gold = new Color(1f, 0.78f, 0.15f);
        public static readonly Color Wood = new Color(0.55f, 0.33f, 0.16f);
        public static readonly Color Stone = new Color(0.78f, 0.72f, 0.66f);
        public static readonly Color Dark = new Color(0.16f, 0.14f, 0.2f);
        public static readonly Color Cream = new Color(1f, 0.95f, 0.85f);
        public static readonly Color Skin = new Color(0.78f, 0.55f, 0.38f);
        public static readonly Color Water = new Color(0.2f, 0.6f, 0.9f);

        public static readonly Color[] Powder = { Pink, Purple, Blue, Yellow, Orange, Green, Magenta, Cyan };

        public static Material LitTemplate;      // assigned by GameBootstrap (from editor setup)
        public static Material UnlitTemplate;    // Sprites/Default style material for particles & transparency
        public static Material GlowTemplate;     // lit + _EMISSION enabled (keeps the emissive shader variant in builds)

        static readonly Dictionary<string, Material> cache = new Dictionary<string, Material>();
        static Texture2D softDot;

        /// <summary>Editor hook: lets the setup tool persist generated materials as assets.</summary>
        public static System.Action<Material, string> OnMaterialCreated;

        public static void ClearCache() { cache.Clear(); }

        public static Color RandomPowder() { return Powder[Random.Range(0, Powder.Length)]; }

        public static Shader FindLitShader()
        {
            Shader s = null;
            if (GraphicsSettings.currentRenderPipeline != null)
            {
                s = Shader.Find("Universal Render Pipeline/Simple Lit");
                if (s == null) s = Shader.Find("Universal Render Pipeline/Lit");
            }
            if (s == null) s = Shader.Find("Standard");
            if (s == null) s = Shader.Find("Legacy Shaders/Diffuse");
            if (s == null) s = Shader.Find("Sprites/Default");
            return s;
        }

        public static Shader FindUnlitShader()
        {
            Shader s = Shader.Find("Sprites/Default");
            if (s == null) s = Shader.Find("Unlit/Color");
            return s;
        }

        /// <summary>Opaque lit material of the given color (cached).</summary>
        public static Material Lit(Color c, float smooth = 0.25f)
        {
            string key = "L" + ColorUtility.ToHtmlStringRGBA(c) + smooth.ToString("0.00");
            Material m;
            if (cache.TryGetValue(key, out m) && m != null) return m;
            m = LitTemplate != null ? new Material(LitTemplate) : new Material(FindLitShader());
            m.color = c;
            if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", c);
            if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smooth);
            if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smooth);
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", 0f);
            m.enableInstancing = true;
            m.name = "Holi_" + key;
            cache[key] = m;
            if (OnMaterialCreated != null) OnMaterialCreated(m, key);
            return m;
        }

        /// <summary>Glowing (emissive) material - used for lights, coins, power-ups.</summary>
        public static Material Glow(Color c)
        {
            string key = "G" + ColorUtility.ToHtmlStringRGBA(c);
            Material m;
            if (cache.TryGetValue(key, out m) && m != null) return m;
            m = GlowTemplate != null ? new Material(GlowTemplate)
              : LitTemplate != null ? new Material(LitTemplate) : new Material(FindLitShader());
            m.color = c;
            if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", c);
            if (m.HasProperty("_EmissionColor"))
            {
                m.EnableKeyword("_EMISSION");
                m.SetColor("_EmissionColor", c * 0.8f);
            }
            m.enableInstancing = true;
            m.name = "HoliGlow_" + key;
            cache[key] = m;
            if (OnMaterialCreated != null) OnMaterialCreated(m, key);
            return m;
        }

        /// <summary>Alpha-blended unlit material (shield bubble, water, particles).</summary>
        public static Material Transparent(Color c)
        {
            string key = "T" + ColorUtility.ToHtmlStringRGBA(c);
            Material m;
            if (cache.TryGetValue(key, out m) && m != null) return m;
            m = UnlitTemplate != null ? new Material(UnlitTemplate) : new Material(FindUnlitShader());
            m.color = c;
            m.name = "HoliTrans_" + key;
            cache[key] = m;
            if (OnMaterialCreated != null) OnMaterialCreated(m, key);
            return m;
        }

        /// <summary>Particle material with a soft round powder-puff texture.</summary>
        public static Material Particle()
        {
            const string key = "PARTICLE";
            Material m;
            if (cache.TryGetValue(key, out m) && m != null) return m;
            m = UnlitTemplate != null ? new Material(UnlitTemplate) : new Material(FindUnlitShader());
            m.mainTexture = SoftDot();
            m.color = Color.white;
            m.name = "HoliParticle";
            cache[key] = m;
            if (OnMaterialCreated != null) OnMaterialCreated(m, key);
            return m;
        }

        static Font font;
        /// <summary>Unity's built-in font (name changed in 2022.2).</summary>
        public static Font BuiltinFont()
        {
            if (font != null) return font;
#if UNITY_2022_2_OR_NEWER
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
            return font;
        }

        public static Texture2D SoftDot()
        {
            if (softDot != null) return softDot;
            const int n = 64;
            softDot = new Texture2D(n, n, TextureFormat.RGBA32, false);
            softDot.name = "HoliSoftDot";
            softDot.wrapMode = TextureWrapMode.Clamp;
            var px = new Color[n * n];
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float dx = (x - n * 0.5f + 0.5f) / (n * 0.5f);
                    float dy = (y - n * 0.5f + 0.5f) / (n * 0.5f);
                    float d = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.Clamp01(1f - d);
                    a = a * a * (3f - 2f * a);
                    px[y * n + x] = new Color(1f, 1f, 1f, a);
                }
            softDot.SetPixels(px);
            softDot.Apply();
            return softDot;
        }
    }
}
