using System;
using System.Collections.Generic;
using UnityEngine;

namespace HoliRush
{
    /// <summary>
    /// Keyed GameObject pool. Objects are built once by a factory function and then
    /// recycled forever, so the endless track creates almost no garbage while running.
    /// </summary>
    public class ObjectPool : MonoBehaviour
    {
        readonly Dictionary<string, Func<GameObject>> factories = new Dictionary<string, Func<GameObject>>();
        readonly Dictionary<string, Stack<GameObject>> free = new Dictionary<string, Stack<GameObject>>();
        Transform storage;

        public static ObjectPool Instance { get; private set; }

        void Awake()
        {
            Instance = this;
            storage = new GameObject("PoolStorage").transform;
            storage.SetParent(transform, false);
        }

        public void Register(string key, Func<GameObject> factory)
        {
            factories[key] = factory;
            if (!free.ContainsKey(key)) free[key] = new Stack<GameObject>();
        }

        public bool Has(string key) { return factories.ContainsKey(key); }

        public void Prewarm(string key, int count)
        {
            var tmp = new List<GameObject>();
            for (int i = 0; i < count; i++) tmp.Add(Get(key, Vector3.zero, null));
            foreach (var g in tmp) Release(g);
        }

        public GameObject Get(string key, Vector3 position, Transform parent)
        {
            Stack<GameObject> stack;
            if (!free.TryGetValue(key, out stack))
            {
                Debug.LogError("[HoliRush] Pool key not registered: " + key);
                return null;
            }
            GameObject go = null;
            while (stack.Count > 0 && go == null) go = stack.Pop();   // skip destroyed entries
            if (go == null)
            {
                go = factories[key]();
                var po = go.GetComponent<PooledObject>();
                if (po == null) po = go.AddComponent<PooledObject>();
                po.poolKey = key;
            }
            var p = go.GetComponent<PooledObject>();
            p.inPool = false;
            go.transform.SetParent(parent, false);
            go.transform.position = position;
            go.SetActive(true);
            return go;
        }

        public void Release(GameObject go)
        {
            if (go == null) return;
            var po = go.GetComponent<PooledObject>();
            if (po == null || !free.ContainsKey(po.poolKey)) { Destroy(go); return; }
            if (po.inPool) return;               // already released - never double-queue
            po.inPool = true;
            go.SetActive(false);
            go.transform.SetParent(storage, false);
            free[po.poolKey].Push(go);
        }
    }
}
