using UnityEngine;
using UnityEngine.Rendering;

namespace HoliRush
{
    /// <summary>
    /// Builds all game art procedurally out of Unity primitives, so the project needs no
    /// external model files. Every mesh is original geometry generated at runtime.
    /// </summary>
    public static class ShapeFactory
    {
        public static GameObject Root(string name, Transform parent = null)
        {
            var go = new GameObject(name);
            if (parent != null) go.transform.SetParent(parent, false);
            return go;
        }

        /// <summary>Creates a primitive WITHOUT its default collider.</summary>
        public static GameObject Prim(PrimitiveType type, Transform parent, Vector3 localPos, Vector3 scale,
                                      Material mat, Vector3? euler = null, bool castShadows = false)
        {
            var go = GameObject.CreatePrimitive(type);
            var col = go.GetComponent<Collider>();
            if (col != null) Object.DestroyImmediate(col);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localScale = scale;
            if (euler.HasValue) go.transform.localEulerAngles = euler.Value;
            var r = go.GetComponent<MeshRenderer>();
            r.sharedMaterial = mat;
            r.shadowCastingMode = castShadows ? ShadowCastingMode.On : ShadowCastingMode.Off;
            r.receiveShadows = castShadows;
            r.lightProbeUsage = LightProbeUsage.Off;
            r.reflectionProbeUsage = ReflectionProbeUsage.Off;
            return go;
        }

        public static GameObject Box(Transform p, Vector3 pos, Vector3 size, Color c, bool shadows = false)
        { return Prim(PrimitiveType.Cube, p, pos, size, Palette.Lit(c), null, shadows); }

        public static GameObject Ball(Transform p, Vector3 pos, Vector3 size, Color c)
        { return Prim(PrimitiveType.Sphere, p, pos, size, Palette.Lit(c)); }

        public static GameObject Cyl(Transform p, Vector3 pos, Vector3 size, Color c, Vector3? euler = null)
        { return Prim(PrimitiveType.Cylinder, p, pos, size, Palette.Lit(c), euler); }

        /// <summary>Editor hook so the setup tool can save baked meshes as assets.</summary>
        public static System.Action<Mesh> OnMeshCreated;

        /// <summary>
        /// Merges every mesh under 'visual' into one mesh per material, parented to 'target',
        /// then deletes 'visual'. Hundreds of primitives become a handful of draw calls.
        /// </summary>
        public static void Bake(GameObject visual, Transform target)
        {
            var groups = new System.Collections.Generic.Dictionary<Material, System.Collections.Generic.List<CombineInstance>>();
            var vcount = new System.Collections.Generic.Dictionary<Material, int>();
            Matrix4x4 toLocal = target.worldToLocalMatrix;
            foreach (var f in visual.GetComponentsInChildren<MeshFilter>(true))
            {
                var r = f.GetComponent<MeshRenderer>();
                if (r == null || f.sharedMesh == null || r.sharedMaterial == null) continue;
                System.Collections.Generic.List<CombineInstance> list;
                if (!groups.TryGetValue(r.sharedMaterial, out list))
                {
                    list = new System.Collections.Generic.List<CombineInstance>();
                    groups[r.sharedMaterial] = list;
                    vcount[r.sharedMaterial] = 0;
                }
                var ci = new CombineInstance { mesh = f.sharedMesh, transform = toLocal * f.transform.localToWorldMatrix };
                list.Add(ci);
                vcount[r.sharedMaterial] += f.sharedMesh.vertexCount;
            }
            int idx = 0;
            foreach (var kv in groups)
            {
                var go = new GameObject("Baked_" + idx++);
                go.transform.SetParent(target, false);
                var mesh = new Mesh();
                mesh.name = target.name + "_" + kv.Key.name;
                if (vcount[kv.Key] > 65000) mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
                mesh.CombineMeshes(kv.Value.ToArray(), true, true);
                mesh.RecalculateBounds();
                go.AddComponent<MeshFilter>().sharedMesh = mesh;
                var mr = go.AddComponent<MeshRenderer>();
                mr.sharedMaterial = kv.Key;
                mr.shadowCastingMode = ShadowCastingMode.Off;
                mr.receiveShadows = false;
                mr.lightProbeUsage = LightProbeUsage.Off;
                mr.reflectionProbeUsage = ReflectionProbeUsage.Off;
                if (OnMeshCreated != null) OnMeshCreated(mesh);
            }
            Object.DestroyImmediate(visual);
        }

        /// <summary>Adds a box collider (in local space of 'go').</summary>
        public static BoxCollider AddBox(GameObject go, Vector3 center, Vector3 size, bool trigger = false)
        {
            var bc = go.AddComponent<BoxCollider>();
            bc.center = center;
            bc.size = size;
            bc.isTrigger = trigger;
            return bc;
        }

        /// <summary>Random flattened colour blobs - the "gulal has hit this" look.</summary>
        public static void Splashes(Transform p, Vector3 center, Vector3 extents, int count, float size = 0.5f)
        {
            for (int i = 0; i < count; i++)
            {
                var pos = center + new Vector3(Random.Range(-extents.x, extents.x),
                                               Random.Range(-extents.y, extents.y),
                                               Random.Range(-extents.z, extents.z));
                float s = size * Random.Range(0.6f, 1.4f);
                Prim(PrimitiveType.Sphere, p, pos, new Vector3(s, s * 0.35f, s), Palette.Lit(Palette.RandomPowder()),
                     new Vector3(Random.Range(0, 360f), Random.Range(0, 360f), 0));
            }
        }

        /// <summary>A triangular festival bunting string between two points.</summary>
        public static void Bunting(Transform p, Vector3 a, Vector3 b, int flags)
        {
            Vector3 dir = b - a;
            var rope = Prim(PrimitiveType.Cube, p, (a + b) * 0.5f, new Vector3(0.04f, 0.04f, dir.magnitude),
                            Palette.Lit(Palette.Cream));
            rope.transform.localRotation = Quaternion.LookRotation(dir.normalized == Vector3.zero ? Vector3.forward : dir.normalized);
            for (int i = 1; i < flags; i++)
            {
                float t = i / (float)flags;
                Vector3 pos = Vector3.Lerp(a, b, t) + Vector3.down * (Mathf.Sin(t * Mathf.PI) * 0.4f + 0.25f);
                var f = Prim(PrimitiveType.Cube, p, pos, new Vector3(0.35f, 0.45f, 0.03f),
                             Palette.Lit(Palette.Powder[i % Palette.Powder.Length]));
                f.transform.localRotation = Quaternion.LookRotation(dir.normalized == Vector3.zero ? Vector3.forward : dir.normalized) * Quaternion.Euler(0, 90, 45);
            }
        }

        /// <summary>Flat rangoli-inspired ring pattern made of coloured petals.</summary>
        public static void Rangoli(Transform p, Vector3 center, float radius)
        {
            Prim(PrimitiveType.Cylinder, p, center, new Vector3(radius * 2f, 0.02f, radius * 2f), Palette.Lit(Palette.Cream));
            int petals = 10;
            for (int ring = 0; ring < 2; ring++)
            {
                float r = radius * (ring == 0 ? 0.75f : 0.4f);
                for (int i = 0; i < petals; i++)
                {
                    float ang = (i + ring * 0.5f) / petals * Mathf.PI * 2f;
                    var pos = center + new Vector3(Mathf.Cos(ang) * r, 0.03f, Mathf.Sin(ang) * r);
                    var petal = Prim(PrimitiveType.Sphere, p, pos, new Vector3(radius * 0.32f, 0.02f, radius * 0.16f),
                                     Palette.Lit(Palette.Powder[(i + ring * 3) % Palette.Powder.Length]));
                    petal.transform.localRotation = Quaternion.Euler(0, -ang * Mathf.Rad2Deg, 0);
                }
            }
            Prim(PrimitiveType.Cylinder, p, center + Vector3.up * 0.04f, new Vector3(radius * 0.35f, 0.02f, radius * 0.35f),
                 Palette.Lit(Palette.Yellow));
        }
    }
}
