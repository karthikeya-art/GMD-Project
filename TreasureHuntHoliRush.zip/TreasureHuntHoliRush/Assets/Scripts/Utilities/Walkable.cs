using UnityEngine;

namespace HoliRush
{
    /// <summary>Marks a collider as a surface the player can run on (train roofs, ramps).</summary>
    public class Walkable : MonoBehaviour { }
}
