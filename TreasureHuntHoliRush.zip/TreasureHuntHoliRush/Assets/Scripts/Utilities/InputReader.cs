using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace HoliRush
{
    public enum RunnerAction { None, Left, Right, Jump, Slide, Pause }

    /// <summary>
    /// Reads keyboard + swipe input and turns it into one discrete action per frame.
    /// Works with the legacy Input Manager AND the new Input System (whichever the project uses).
    /// A swipe triggers exactly ONE action (dominant axis wins), so diagonal swipes never double-fire.
    /// </summary>
    public class InputReader : MonoBehaviour
    {
        [Tooltip("Swipe distance as a fraction of screen height")]
        public float swipeThreshold = 0.05f;

        bool tracking;
        bool consumed;
        Vector2 startPos;

        /// <summary>Escape / P only (used to resume while the game is paused).</summary>
        public bool PausePressed()
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            return k != null && (k.escapeKey.wasPressedThisFrame || k.pKey.wasPressedThisFrame);
#elif ENABLE_LEGACY_INPUT_MANAGER
            return Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P);
#else
            return false;
#endif
        }

        /// <summary>Enter / Space (start from the menu, retry from game over).</summary>
        public bool ConfirmPressed()
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            return k != null && (k.enterKey.wasPressedThisFrame || k.spaceKey.wasPressedThisFrame);
#elif ENABLE_LEGACY_INPUT_MANAGER
            return Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space);
#else
            return false;
#endif
        }

        public RunnerAction Poll()
        {
            RunnerAction a = ReadKeyboard();
            if (a != RunnerAction.None) return a;
            return ReadSwipe();
        }

        RunnerAction ReadKeyboard()
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            if (k != null)
            {
                if (k.leftArrowKey.wasPressedThisFrame || k.aKey.wasPressedThisFrame) return RunnerAction.Left;
                if (k.rightArrowKey.wasPressedThisFrame || k.dKey.wasPressedThisFrame) return RunnerAction.Right;
                if (k.upArrowKey.wasPressedThisFrame || k.spaceKey.wasPressedThisFrame || k.wKey.wasPressedThisFrame) return RunnerAction.Jump;
                if (k.downArrowKey.wasPressedThisFrame || k.sKey.wasPressedThisFrame) return RunnerAction.Slide;
                if (k.escapeKey.wasPressedThisFrame || k.pKey.wasPressedThisFrame) return RunnerAction.Pause;
            }
            return RunnerAction.None;
#elif ENABLE_LEGACY_INPUT_MANAGER
            if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) return RunnerAction.Left;
            if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) return RunnerAction.Right;
            if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W)) return RunnerAction.Jump;
            if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) return RunnerAction.Slide;
            if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P)) return RunnerAction.Pause;
            return RunnerAction.None;
#else
            return RunnerAction.None;
#endif
        }

        // Returns pointer state: began / held / position
        bool GetPointer(out bool began, out Vector2 pos)
        {
            began = false; pos = Vector2.zero;
#if ENABLE_INPUT_SYSTEM
            var ts = Touchscreen.current;
            if (ts != null && ts.primaryTouch.press.isPressed)
            {
                began = ts.primaryTouch.press.wasPressedThisFrame;
                pos = ts.primaryTouch.position.ReadValue();
                return true;
            }
            var m = Mouse.current;
            if (m != null && m.leftButton.isPressed)
            {
                began = m.leftButton.wasPressedThisFrame;
                pos = m.position.ReadValue();
                return true;
            }
            return false;
#elif ENABLE_LEGACY_INPUT_MANAGER
            if (Input.touchCount > 0)
            {
                var t = Input.GetTouch(0);
                began = t.phase == TouchPhase.Began;
                pos = t.position;
                return t.phase != TouchPhase.Ended && t.phase != TouchPhase.Canceled;
            }
            if (Input.GetMouseButton(0))
            {
                began = Input.GetMouseButtonDown(0);
                pos = Input.mousePosition;
                return true;
            }
            return false;
#else
            return false;
#endif
        }

        RunnerAction ReadSwipe()
        {
            bool began; Vector2 pos;
            bool down = GetPointer(out began, out pos);
            if (!down) { tracking = false; consumed = false; return RunnerAction.None; }
            if (began || !tracking)
            {
                tracking = true; consumed = false; startPos = pos;
                return RunnerAction.None;
            }
            if (consumed) return RunnerAction.None;

            Vector2 d = pos - startPos;
            float min = Screen.height * swipeThreshold;
            if (d.magnitude < min) return RunnerAction.None;
            consumed = true;   // one action per touch - kills diagonal double triggers
            if (Mathf.Abs(d.x) > Mathf.Abs(d.y))
                return d.x > 0 ? RunnerAction.Right : RunnerAction.Left;
            return d.y > 0 ? RunnerAction.Jump : RunnerAction.Slide;
        }
    }
}
