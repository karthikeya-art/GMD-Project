using System.Collections.Generic;
using UnityEngine;

namespace HoliRush
{
    /// <summary>One recyclable stretch of track and everything spawned on it.</summary>
    public class TrackSegment
    {
        public float startZ, endZ;
        public Zone zone;
        public readonly List<GameObject> objects = new List<GameObject>();
    }

    /// <summary>
    /// Endless procedural track. Content is generated as "rows" of obstacles. A SAFE LANE is
    /// planned first for every row (moving at most one lane between rows) and nothing that blocks
    /// the safe lane is ever spawned in it - so every pattern is always survivable.
    /// Trains are only placed on lane stretches that are never the safe lane.
    /// </summary>
    public class TrackGenerator : MonoBehaviour
    {
        GameManager gm;
        ObjectPool pool;
        EnvironmentManager env;
        ObstacleSpawner obstacles;
        CollectibleManager collectibles;
        Transform world;

        readonly List<TrackSegment> segments = new List<TrackSegment>();
        float nextSegmentZ;
        float nextRowZ;
        int safeLane;
        int segmentCount;

        struct Row
        {
            public float z;
            public int safe;
            public bool[] occupied;          // lane filled by a train
            public ObstacleKind?[] kinds;
        }

        public void Init(GameManager g, ObjectPool p, EnvironmentManager e, ObstacleSpawner o, CollectibleManager c)
        {
            gm = g; pool = p; env = e; obstacles = o; collectibles = c;
            world = new GameObject("World").transform;
            world.SetParent(transform, false);
        }

        public void ResetTrack()
        {
            foreach (var s in segments) ReleaseSegment(s);
            segments.Clear();
            nextSegmentZ = -20f;
            nextRowZ = 0f;
            safeLane = 0;
            segmentCount = 0;
            env.ResetZones();
            Fill(0f);
        }

        void Update()
        {
            if (gm == null || gm.Player == null) return;
            float pz = gm.Player.transform.position.z;
            Fill(pz);
            // recycle segments well behind the player
            while (segments.Count > 0 && segments[0].endZ < pz - 25f)
            {
                ReleaseSegment(segments[0]);
                segments.RemoveAt(0);
            }
            // which zone is the player in? (drives sky/fog tint and celebration effects)
            for (int i = 0; i < segments.Count; i++)
                if (pz >= segments[i].startZ && pz < segments[i].endZ) { env.PlayerZone = segments[i].zone; break; }
        }

        void Fill(float playerZ)
        {
            float ahead = gm.Config.segmentLength * gm.Config.segmentsAhead;
            while (nextSegmentZ < playerZ + ahead) SpawnSegment();
        }

        void ReleaseSegment(TrackSegment s)
        {
            for (int i = 0; i < s.objects.Count; i++) pool.Release(s.objects[i]);
            s.objects.Clear();
        }

        float Difficulty { get { return Mathf.Clamp01(gm.Distance / 3500f); } }

        void SpawnSegment()
        {
            float L = gm.Config.segmentLength;
            bool newZone;
            var seg = new TrackSegment { startZ = nextSegmentZ, endZ = nextSegmentZ + L };
            seg.zone = env.NextSegmentZone(out newZone);
            if (segmentCount == 0) newZone = true;
            env.Decorate(seg.zone, seg.startZ, L, newZone, seg.objects, world);

            bool safeStart = segmentCount < gm.Config.safeStartSegments;
            if (nextRowZ < seg.startZ + 6f) nextRowZ = seg.startZ + 6f;
            if (safeStart) { CoinRun(seg, 0, seg.startZ + 22f, seg.endZ - 4f); nextRowZ = seg.endZ + 8f; }
            else GenerateRows(seg);

            segments.Add(seg);
            nextSegmentZ = seg.endZ;
            segmentCount++;
        }

        float LaneX(int lane) { return lane * gm.Config.laneWidth; }

        void GenerateRows(TrackSegment seg)
        {
            float d = Difficulty;
            // spacing grows with speed so there is always time to react
            float spacing = Mathf.Clamp(gm.CurrentBaseSpeed * 1.05f, 15f, 28f) * Mathf.Lerp(1.15f, 0.95f, d);
            var rows = new List<Row>();
            while (nextRowZ < seg.endZ - 3f)
            {
                if (Random.value < 0.35f + d * 0.15f) safeLane = Mathf.Clamp(safeLane + (Random.value < 0.5f ? -1 : 1), -1, 1);
                rows.Add(new Row { z = nextRowZ, safe = safeLane, occupied = new bool[3], kinds = new ObstacleKind?[3] });
                nextRowZ += spacing;
            }
            if (rows.Count == 0) return;

            // ---- 1) trains on stretches that are never the safe lane
            float trainChance = Mathf.Lerp(0.35f, 0.7f, d);
            float movingChance = Mathf.Lerp(0.0f, 0.45f, d);
            for (int lane = -1; lane <= 1; lane++)
            {
                int i = 0;
                while (i < rows.Count)
                {
                    if (rows[i].safe == lane) { i++; continue; }
                    int j = i;
                    while (j + 1 < rows.Count && rows[j + 1].safe != lane) j++;
                    int runLen = j - i + 1;
                    if (runLen >= 2 && Random.value < trainChance)
                        PlaceTrain(seg, rows, lane, i, j, runLen >= 3 && Random.value < movingChance);
                    i = j + 1;
                }
            }

            // ---- 2) row obstacles
            for (int r = 0; r < rows.Count; r++)
            {
                var row = rows[r];
                for (int lane = -1; lane <= 1; lane++)
                {
                    int li = lane + 1;
                    if (row.occupied[li]) continue;
                    ObstacleKind? kind = null;
                    float v = Random.value;
                    if (lane == row.safe)
                    {
                        // the safe lane may only hold jump/slide obstacles (always passable)
                        float passChance = Mathf.Lerp(0.15f, 0.5f, d);
                        if (v < passChance) kind = Random.value < 0.5f ? ObstacleKind.Jump : ObstacleKind.Slide;
                    }
                    else
                    {
                        if (v < 0.5f) kind = ObstacleKind.Block;
                        else if (v < 0.68f) kind = ObstacleKind.Jump;
                        else if (v < 0.86f) kind = ObstacleKind.Slide;
                    }
                    row.kinds[li] = kind;
                    if (kind.HasValue)
                    {
                        string key = ObstacleSpawner.KeyFor(kind.Value, d);
                        seg.objects.Add(obstacles.Spawn(key, new Vector3(LaneX(lane), 0f, row.z), world));
                    }
                }
                rows[r] = row;
            }

            // ---- 3) collectibles along the safe route
            for (int r = 0; r < rows.Count; r++)
            {
                var row = rows[r];
                var k = row.kinds[row.safe + 1];
                if (k.HasValue && k.Value == ObstacleKind.Jump) CoinArc(seg, row.safe, row.z);
                else if (k.HasValue && k.Value == ObstacleKind.Slide) CoinLine(seg, row.safe, row.z - 2f, row.z + 2f, 0.55f, 2f);

                float gapStart = row.z + 5.5f;
                float gapEnd = (r + 1 < rows.Count ? rows[r + 1].z : row.z + spacing) - 5.5f;
                int nextSafe = r + 1 < rows.Count ? rows[r + 1].safe : row.safe;
                int coinLane = nextSafe;
                float coinStart = nextSafe == row.safe ? gapStart : (gapStart + gapEnd) * 0.5f;
                if (gapEnd - coinStart > 2f) SpecialOrCoins(seg, coinLane, coinStart, gapEnd, d);
            }
        }

        void PlaceTrain(TrackSegment seg, List<Row> rows, int lane, int first, int last, bool moving)
        {
            float regionStart = rows[first].z - 2f;
            float regionEnd = rows[last].z + 2f;
            float region = regionEnd - regionStart;
            int li = lane + 1;
            if (moving)
            {
                int cars = Mathf.Clamp(Mathf.FloorToInt((region - 10f) / TrainFactory.CarLength), 1, 3);
                float len = cars * TrainFactory.CarLength;
                float front = regionEnd - len;
                var go = obstacles.Spawn("train_moving_" + cars, new Vector3(LaneX(lane), 0f, front), world);
                go.GetComponent<TrainController>().Configure(true, Random.Range(6f, 10f) + Difficulty * 4f, regionStart);
                seg.objects.Add(go);
                for (int r = first; r <= last; r++) MarkOccupied(rows, r, li);
            }
            else
            {
                int cars = Mathf.Clamp(Mathf.FloorToInt(region / TrainFactory.CarLength), 1, 3);
                float len = cars * TrainFactory.CarLength;
                bool ramp = Random.value < 0.4f;
                var go = obstacles.Spawn((ramp ? "train_ramp_" : "train_") + cars, new Vector3(LaneX(lane), 0f, regionStart), world);
                go.GetComponent<TrainController>().Configure(false, 0f, regionStart);
                seg.objects.Add(go);
                for (int r = first; r <= last; r++)
                    if (rows[r].z >= regionStart - 1f && rows[r].z <= regionStart + len + 1f) MarkOccupied(rows, r, li);
                // reward the brave: coins on the roof
                if (Random.value < (ramp ? 0.8f : 0.35f))
                    CoinLine(seg, lane, regionStart + 1.5f, regionStart + len - 1.5f, TrainFactory.Height + 0.9f, 2.2f);
                // (row spacing >= 15 > ramp length + 2, so no row obstacle can ever sit on a ramp)
            }
        }

        static void MarkOccupied(List<Row> rows, int r, int li)
        {
            rows[r].occupied[li] = true;   // arrays are reference types, so this updates the row
        }

        // ------------------------------------------------------------------ collectibles
        void SpecialOrCoins(TrackSegment seg, int lane, float z0, float z1, float d)
        {
            float mid = (z0 + z1) * 0.5f;
            float v = Random.value;
            string special = null;
            if (v < 0.07f) special = "pu_" + RandomPowerUp();
            else if (v < 0.095f) special = "gem";
            else if (v < 0.11f) special = "key";
            else if (v < 0.122f) special = "treasure";
            else if (v < 0.128f) special = "lucky_color";
            else if (v < 0.132f) special = "golden_token";

            if (special != null)
            {
                Spawn(seg, special, new Vector3(LaneX(lane), 1.1f, mid));
                CoinLine(seg, lane, z0, mid - 2.5f, 0.9f, 2f);
                CoinLine(seg, lane, mid + 2.5f, z1, 0.9f, 2f);
                return;
            }
            if (Random.value < 0.22f)
            {
                string token = "token_" + Random.Range(0, 5);
                for (float z = z0; z <= z1; z += 2.4f) Spawn(seg, token, new Vector3(LaneX(lane), 0.9f, z));
                return;
            }
            CoinLine(seg, lane, z0, z1, 0.9f, 2f);
        }

        static PowerUpType RandomPowerUp()
        {
            PowerUpType[] all = { PowerUpType.ColorBurst, PowerUpType.ColorMagnet, PowerUpType.WaterShield, PowerUpType.RainbowDash, PowerUpType.FestivalMultiplier };
            return all[Random.Range(0, all.Length)];
        }

        void CoinRun(TrackSegment seg, int lane, float z0, float z1) { CoinLine(seg, lane, z0, z1, 0.9f, 2f); }

        void CoinLine(TrackSegment seg, int lane, float z0, float z1, float y, float step)
        {
            for (float z = z0; z <= z1; z += step) Spawn(seg, "coin", new Vector3(LaneX(lane), y, z));
        }

        void CoinArc(TrackSegment seg, int lane, float z)
        {
            for (int i = -3; i <= 3; i++)
            {
                float t = i / 3f;
                Spawn(seg, "coin", new Vector3(LaneX(lane), 0.9f + 1.4f * (1f - t * t), z + i * 1.6f));
            }
        }

        void Spawn(TrackSegment seg, string key, Vector3 pos)
        {
            seg.objects.Add(collectibles.Spawn(key, pos, world));
        }

        /// <summary>Used by Revive: hide every obstacle overlapping [z0, z1].</summary>
        public void ClearObstacles(float z0, float z1)
        {
            var list = Obstacle.Active;
            for (int i = list.Count - 1; i >= 0; i--)
            {
                if (i >= list.Count) continue;
                var o = list[i];
                if (o.hitCollider == null) continue;
                var b = o.hitCollider.bounds;
                if (b.max.z >= z0 && b.min.z <= z1) o.root.SetActive(false);
            }
        }
    }
}
