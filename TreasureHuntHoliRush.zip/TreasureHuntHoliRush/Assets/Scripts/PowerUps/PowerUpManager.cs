using UnityEngine;

namespace HoliRush
{
    /// <summary>Timers and effects for every Holi power-up.</summary>
    public class PowerUpManager : MonoBehaviour
    {
        GameManager gm;
        float magnet, shield, dash, multiplier, burstTrail;

        public void Init(GameManager g) { gm = g; }

        public void ResetAll() { magnet = shield = dash = multiplier = burstTrail = 0f; RefreshVisuals(); }

        public bool IsActive(PowerUpType t) { return Remaining(t) > 0f; }

        public float Remaining(PowerUpType t)
        {
            switch (t)
            {
                case PowerUpType.ColorMagnet: return magnet;
                case PowerUpType.WaterShield: return shield;
                case PowerUpType.RainbowDash: return dash;
                case PowerUpType.FestivalMultiplier: return multiplier;
                default: return 0f;
            }
        }

        public float Duration(PowerUpType t)
        {
            var c = gm.Config;
            switch (t)
            {
                case PowerUpType.ColorMagnet: return c.magnetDuration;
                case PowerUpType.WaterShield: return c.shieldDuration;
                case PowerUpType.RainbowDash: return c.rainbowDashDuration;
                case PowerUpType.FestivalMultiplier: return c.multiplierDuration;
                default: return 1f;
            }
        }

        /// <summary>Score multiplier from power-ups (Festival x2, Rainbow Dash x2 - they stack).</summary>
        public float ScoreMultiplier
        {
            get
            {
                float m = 1f;
                if (multiplier > 0f) m *= 2f;
                if (dash > 0f) m *= 2f;
                return m;
            }
        }

        public float SpeedMultiplier { get { return dash > 0f ? gm.Config.rainbowDashSpeedMultiplier : 1f; } }

        public void Activate(PowerUpType t)
        {
            var c = gm.Config;
            var p = gm.Player;
            if (AudioManager.Instance != null) AudioManager.Instance.Play(Sfx.PowerUp);
            Color col = CollectibleManager.PowerUpColor(t);
            if (HoliFX.Instance != null) HoliFX.Instance.Burst(p.transform.position + Vector3.up, col, 35, 1.2f);
            switch (t)
            {
                case PowerUpType.ColorBurst:
                    if (HoliFX.Instance != null) HoliFX.Instance.Explosion(p.transform.position + Vector3.up * 1.5f, 1.4f);
                    int n = CollectibleManager.Instance.CollectInRadius(p.transform.position, c.colorBurstRadius);
                    gm.AddScore(500 + n * 5);
                    burstTrail = 3f;
                    gm.CameraRig.Shake(0.25f, 0.3f);
                    break;
                case PowerUpType.ColorMagnet: magnet = c.magnetDuration; break;
                case PowerUpType.WaterShield: shield = c.shieldDuration; break;
                case PowerUpType.RainbowDash: dash = c.rainbowDashDuration; break;
                case PowerUpType.FestivalMultiplier: multiplier = c.multiplierDuration; break;
            }
            RefreshVisuals();
        }

        /// <summary>Called when the shield absorbs a hit.</summary>
        public void ConsumeShield() { shield = 0f; RefreshVisuals(); }

        void Update()
        {
            if (gm == null || gm.State != GameState.Playing) return;
            float dt = Time.deltaTime;
            bool changed = false;
            changed |= Tick(ref magnet, dt);
            changed |= Tick(ref shield, dt);
            changed |= Tick(ref dash, dt);
            changed |= Tick(ref multiplier, dt);
            changed |= Tick(ref burstTrail, dt);
            if (changed) RefreshVisuals();
        }

        static bool Tick(ref float timer, float dt)
        {
            if (timer <= 0f) return false;
            timer -= dt;
            if (timer <= 0f) { timer = 0f; return true; }
            return false;
        }

        void RefreshVisuals()
        {
            if (gm == null || gm.Player == null) return;
            var v = gm.Player.Visual;
            v.SetShield(shield > 0f);
            v.SetTrail(dash > 0f || burstTrail > 0f, dash > 0f);
            v.SetMagnet(magnet > 0f);
        }

        /// <summary>The most important active power-up, for the HUD.</summary>
        public PowerUpType Primary(out float remaining, out float duration)
        {
            PowerUpType[] order = { PowerUpType.RainbowDash, PowerUpType.WaterShield, PowerUpType.ColorMagnet, PowerUpType.FestivalMultiplier };
            foreach (var t in order)
            {
                float r = Remaining(t);
                if (r > 0f) { remaining = r; duration = Duration(t); return t; }
            }
            remaining = 0f; duration = 1f;
            return PowerUpType.None;
        }

        public static string DisplayName(PowerUpType t)
        {
            switch (t)
            {
                case PowerUpType.ColorBurst: return "COLOR BURST";
                case PowerUpType.ColorMagnet: return "COLOR MAGNET";
                case PowerUpType.WaterShield: return "WATER SHIELD";
                case PowerUpType.RainbowDash: return "RAINBOW DASH";
                case PowerUpType.FestivalMultiplier: return "FESTIVAL x2";
                default: return "";
            }
        }
    }
}
