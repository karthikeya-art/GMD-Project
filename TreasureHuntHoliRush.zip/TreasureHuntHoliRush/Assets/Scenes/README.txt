HoliRush.unity is generated automatically the first time the project is opened
(or via the menu: Holi Rush > 1. Build Complete Game Setup).
