using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace HoliRush.EditorTools
{
    /// <summary>Build + export helpers (menu items and batch-mode entry points).</summary>
    public static class HoliRushBuild
    {
        const string ApkPath = "Builds/Android/TreasureHuntHoliRush.apk";
        const string WinPath = "Builds/Windows/TreasureHuntHoliRush.exe";
        const string PackagePath = "TreasureHuntHoliRush.unitypackage";

        static string[] Scenes()
        {
            if (!File.Exists(HoliRushSetup.ScenePath)) HoliRushSetup.BuildAll(false);
            return new[] { HoliRushSetup.ScenePath };
        }

        [MenuItem("Holi Rush/4. Build Android APK", priority = 20)]
        public static void BuildAndroidMenu() { BuildAndroid(true); }

        /// <summary>Batch: Unity -batchmode -quit -projectPath . -executeMethod HoliRush.EditorTools.HoliRushBuild.BatchBuildAndroid</summary>
        public static void BatchBuildAndroid() { BuildAndroid(false); }

        static void BuildAndroid(bool interactive)
        {
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
            {
                string msg = "Android Build Support is not installed for this Unity version.\n" +
                             "Install it from Unity Hub > Installs > (your version) > Add modules > Android Build Support (incl. SDK & NDK, OpenJDK).";
                Debug.LogError("[HoliRush] " + msg);
                if (interactive) EditorUtility.DisplayDialog("Holi Rush", msg, "OK");
                return;
            }
            Directory.CreateDirectory(Path.GetDirectoryName(ApkPath));
            EditorUserBuildSettings.buildAppBundle = false;
            var options = new BuildPlayerOptions
            {
                scenes = Scenes(),
                locationPathName = ApkPath,
                target = BuildTarget.Android,
                targetGroup = BuildTargetGroup.Android,
                options = BuildOptions.None
            };
            Report(BuildPipeline.BuildPlayer(options), ApkPath, interactive);
        }

        [MenuItem("Holi Rush/5. Build Windows (PC)", priority = 21)]
        public static void BuildWindows()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(WinPath));
            var options = new BuildPlayerOptions
            {
                scenes = Scenes(),
                locationPathName = WinPath,
                target = BuildTarget.StandaloneWindows64,
                targetGroup = BuildTargetGroup.Standalone,
                options = BuildOptions.None
            };
            Report(BuildPipeline.BuildPlayer(options), WinPath, true);
        }

        static void Report(BuildReport report, string path, bool interactive)
        {
            var s = report.summary;
            string msg = s.result == BuildResult.Succeeded
                ? "BUILD SUCCEEDED\n" + Path.GetFullPath(path) + "\nSize: " + (s.totalSize / (1024f * 1024f)).ToString("0.0") + " MB"
                : "BUILD " + s.result.ToString().ToUpper() + " with " + s.totalErrors + " error(s). See the Console.";
            Debug.Log("[HoliRush] " + msg);
            if (interactive) EditorUtility.DisplayDialog("Holi Rush Build", msg, "OK");
        }

        [MenuItem("Holi Rush/6. Export .unitypackage", priority = 40)]
        public static void ExportPackageMenu() { ExportPackage(true); }

        public static void BatchExportPackage() { ExportPackage(false); }

        static void ExportPackage(bool interactive)
        {
            string[] roots = { "Assets/Scripts", "Assets/Editor", "Assets/Scenes", "Assets/Materials", "Assets/Prefabs",
                               "Assets/Models", "Assets/Textures", "Assets/Audio", "Assets/Settings" };
            var existing = System.Array.FindAll(roots, AssetDatabase.IsValidFolder);
            AssetDatabase.ExportPackage(existing, PackagePath, ExportPackageOptions.Recurse);
            string msg = "Exported " + Path.GetFullPath(PackagePath);
            Debug.Log("[HoliRush] " + msg);
            if (interactive) EditorUtility.RevealInFinder(PackagePath);
        }
    }
}
