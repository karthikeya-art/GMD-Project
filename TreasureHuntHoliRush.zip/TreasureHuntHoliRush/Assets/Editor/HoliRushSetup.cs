using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

namespace HoliRush.EditorTools
{
    /// <summary>
    /// One-click (and automatic first-open) setup for TREASURE HUNT - HOLI RUSH.
    /// Menu: Holi Rush > 1. Build Complete Game Setup
    /// Creates folders, material templates, generated materials/meshes/prefabs, the main scene
    /// with the GameBootstrap (all references assigned), lighting/fog, build settings, then validates.
    /// </summary>
    [InitializeOnLoad]
    public static class HoliRushSetup
    {
        public const string ScenePath = "Assets/Scenes/HoliRush.unity";
        const string AutoKey = "HoliRush_AutoSetupDone_";

        static HoliRushSetup()
        {
            EditorApplication.delayCall += AutoRun;
        }

        static void AutoRun()
        {
            if (Application.isBatchMode) return;
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += AutoRun;
                return;
            }
            string key = AutoKey + Application.dataPath.GetHashCode();
            if (File.Exists(ScenePath) || EditorPrefs.GetBool(key, false)) return;
            EditorPrefs.SetBool(key, true);
            Debug.Log("[HoliRush] First open detected - building the complete game setup automatically...");
            BuildAll(false);
        }

        [MenuItem("Holi Rush/1. Build Complete Game Setup", priority = 1)]
        public static void BuildAllMenu()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            BuildAll(true);
        }

        [MenuItem("Holi Rush/2. Open Game Scene", priority = 2)]
        public static void OpenScene()
        {
            if (!File.Exists(ScenePath)) { BuildAll(true); return; }
            if (EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) EditorSceneManager.OpenScene(ScenePath);
        }

        [MenuItem("Holi Rush/3. Validate Project", priority = 3)]
        public static void ValidateMenu()
        {
            var report = Validate();
            EditorUtility.DisplayDialog("Holi Rush - Validation", report.Length > 1500 ? report.Substring(0, 1500) + "..." : report, "OK");
        }

        /// <summary>Entry point for batch mode: Unity -batchmode -executeMethod HoliRush.EditorTools.HoliRushSetup.BatchSetup -quit</summary>
        public static void BatchSetup()
        {
            BuildAll(false);
        }

        public static void BuildAll(bool interactive)
        {
            try
            {
                Progress("Creating folders", 0.05f);
                EnsureFolders();

                Progress("Creating material templates", 0.15f);
                Material lit, glow, unlit;
                CreateTemplates(out lit, out glow, out unlit);

                Progress("Creating scene", 0.25f);
                var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

                Progress("Generating prefabs, materials and meshes", 0.35f);
                try { GeneratePrefabs(lit, glow, unlit); }
                catch (System.Exception e) { Debug.LogWarning("[HoliRush] Prefab generation skipped: " + e); }

                Progress("Building scene objects", 0.75f);
                BuildSceneObjects(lit, glow, unlit);
                EditorSceneManager.MarkSceneDirty(scene);
                EditorSceneManager.SaveScene(scene, ScenePath);

                Progress("Configuring build settings", 0.85f);
                ConfigureProject();

                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                Progress("Validating", 0.95f);
                string report = Validate();
                Debug.Log(report);
                EditorUtility.ClearProgressBar();
                if (interactive)
                    EditorUtility.DisplayDialog("Treasure Hunt - Holi Rush",
                        "Setup complete!\n\nScene: " + ScenePath + "\n\nPress PLAY to run the game.\n\n" +
                        (report.Contains("FAIL") ? "Some validation checks failed - see the Console." : "All validation checks passed."), "Let's play");
            }
            catch (System.Exception e)
            {
                EditorUtility.ClearProgressBar();
                Debug.LogError("[HoliRush] Setup failed: " + e);
                if (interactive) EditorUtility.DisplayDialog("Holi Rush", "Setup failed:\n" + e.Message, "OK");
            }
            finally
            {
                Palette.OnMaterialCreated = null;
                ShapeFactory.OnMeshCreated = null;
                Palette.ClearCache();
            }
        }

        static void Progress(string msg, float p)
        {
            if (!Application.isBatchMode) EditorUtility.DisplayProgressBar("Treasure Hunt - Holi Rush", msg, p);
        }

        static void EnsureFolders()
        {
            string[] folders =
            {
                "Assets/Scenes", "Assets/Prefabs", "Assets/Prefabs/Trains", "Assets/Prefabs/Obstacles", "Assets/Prefabs/Collectibles",
                "Assets/Prefabs/Environment", "Assets/Prefabs/Player", "Assets/Materials", "Assets/Materials/Generated",
                "Assets/Models", "Assets/Models/Generated", "Assets/Textures", "Assets/Audio", "Assets/Settings"
            };
            foreach (var f in folders)
            {
                if (AssetDatabase.IsValidFolder(f)) continue;
                string parent = Path.GetDirectoryName(f).Replace('\\', '/');
                AssetDatabase.CreateFolder(parent, Path.GetFileName(f));
            }
        }

        static Material SaveMat(Material m, string path)
        {
            var existing = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (existing != null)
            {
                existing.shader = m.shader;
                existing.CopyPropertiesFromMaterial(m);
                existing.shaderKeywords = m.shaderKeywords;
                EditorUtility.SetDirty(existing);
                return existing;
            }
            AssetDatabase.CreateAsset(m, path);
            return m;
        }

        static void CreateTemplates(out Material lit, out Material glow, out Material unlit)
        {
            Shader litShader = Palette.FindLitShader();
            var l = new Material(litShader) { name = "HoliLitTemplate" };
            l.enableInstancing = true;
            lit = SaveMat(l, "Assets/Materials/HoliLitTemplate.mat");

            var g = new Material(litShader) { name = "HoliGlowTemplate" };
            g.enableInstancing = true;
            if (g.HasProperty("_EmissionColor")) { g.EnableKeyword("_EMISSION"); g.SetColor("_EmissionColor", Color.white * 0.5f); }
            g.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
            glow = SaveMat(g, "Assets/Materials/HoliGlowTemplate.mat");

            var u = new Material(Palette.FindUnlitShader()) { name = "HoliUnlitTemplate" };
            unlit = SaveMat(u, "Assets/Materials/HoliUnlitTemplate.mat");
        }

        // ------------------------------------------------------------------ prefabs
        static int meshCounter;

        static void GeneratePrefabs(Material lit, Material glow, Material unlit)
        {
            Palette.ClearCache();
            Palette.LitTemplate = lit; Palette.GlowTemplate = glow; Palette.UnlitTemplate = unlit;
            meshCounter = 0;
            // clean previously generated assets so re-running is idempotent
            foreach (var dir in new[] { "Assets/Materials/Generated", "Assets/Models/Generated" })
                foreach (var guid in AssetDatabase.FindAssets("", new[] { dir }))
                    AssetDatabase.DeleteAsset(AssetDatabase.GUIDToAssetPath(guid));

            var tex = Palette.SoftDot();
            if (!AssetDatabase.Contains(tex)) AssetDatabase.CreateAsset(tex, "Assets/Textures/HoliSoftDot.asset");

            Palette.OnMaterialCreated = (m, key) =>
            {
                string safe = key.Replace('.', '_');
                AssetDatabase.CreateAsset(m, "Assets/Materials/Generated/" + safe + ".mat");
            };
            ShapeFactory.OnMeshCreated = mesh =>
            {
                meshCounter++;
                AssetDatabase.CreateAsset(mesh, "Assets/Models/Generated/Mesh_" + meshCounter.ToString("0000") + ".asset");
            };

            int made = 0;
            System.Action<GameObject, string> save = (go, path) =>
            {
                if (go == null) return;
                PrefabUtility.SaveAsPrefabAsset(go, path);
                Object.DestroyImmediate(go);
                made++;
            };

            // trains
            for (int cars = 1; cars <= 3; cars++)
            {
                save(TrainFactory.Build(cars, false, false, cars), "Assets/Prefabs/Trains/RangExpress_" + cars + "Car.prefab");
                save(TrainFactory.Build(cars, true, false, cars + 1), "Assets/Prefabs/Trains/RangExpress_" + cars + "Car_Ramp.prefab");
                save(TrainFactory.Build(cars, false, true, cars + 2), "Assets/Prefabs/Trains/RangExpress_" + cars + "Car_Moving.prefab");
            }
            // obstacles
            var obsKeys = new List<string>();
            obsKeys.AddRange(ObstacleSpawner.JumpKeys); obsKeys.AddRange(ObstacleSpawner.SlideKeys); obsKeys.AddRange(ObstacleSpawner.BlockKeys);
            foreach (var k in obsKeys) save(ObstacleSpawner.BuildByKey(k), "Assets/Prefabs/Obstacles/" + k + ".prefab");
            // collectibles + power-ups
            var colKeys = new List<string> { "coin", "gem", "key", "treasure", "golden_token", "lucky_color" };
            for (int i = 0; i < 5; i++) colKeys.Add("token_" + i);
            foreach (PowerUpType t in System.Enum.GetValues(typeof(PowerUpType)))
                if (t != PowerUpType.None) colKeys.Add("pu_" + t);
            foreach (var k in colKeys) save(CollectibleManager.BuildByKey(k), "Assets/Prefabs/Collectibles/" + k + ".prefab");
            // environment
            var envGo = new GameObject("TempEnv");
            var env = envGo.AddComponent<EnvironmentManager>();
            for (int z = 0; z < EnvironmentManager.ZoneCount; z++)
            {
                save(env.BuildFloor((Zone)z), "Assets/Prefabs/Environment/Floor_" + (Zone)z + ".prefab");
                save(env.BuildArch((Zone)z), "Assets/Prefabs/Environment/Gate_" + (Zone)z + ".prefab");
                for (int v = 0; v < 2; v++)
                    save(env.BuildDecor((Zone)z, v), "Assets/Prefabs/Environment/Decor_" + (Zone)z + "_" + v + ".prefab");
            }
            Object.DestroyImmediate(envGo);
            // player model (visual reference - the game builds its own at runtime)
            var player = new GameObject("Rangu_TreasureHunter");
            player.AddComponent<PlayerVisual>().Build();
            save(player, "Assets/Prefabs/Player/Rangu_TreasureHunter.prefab");

            Debug.Log("[HoliRush] Generated " + made + " prefabs, " + meshCounter + " meshes.");
        }

        // ------------------------------------------------------------------ scene
        static void BuildSceneObjects(Material lit, Material glow, Material unlit)
        {
            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            var cam = camGo.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(1f, 0.82f, 0.88f);
            cam.fieldOfView = 62f;
            camGo.AddComponent<AudioListener>();
            camGo.AddComponent<CameraFollow>();
            camGo.transform.position = new Vector3(0, 4.4f, -7.4f);
            camGo.transform.rotation = Quaternion.Euler(18f, 0, 0);

            var sunGo = new GameObject("Holi Sun");
            var sun = sunGo.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.color = new Color(1f, 0.93f, 0.82f);
            sun.intensity = 1.15f;
            sun.shadows = LightShadows.None;
            sunGo.transform.rotation = Quaternion.Euler(48f, -35f, 0f);

            // fog must be ON in the saved scene, otherwise fog shader variants get stripped from builds
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 55f;
            RenderSettings.fogEndDistance = 250f;
            RenderSettings.fogColor = new Color(1f, 0.82f, 0.88f);
            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(1f, 0.85f, 0.95f);
            RenderSettings.ambientEquatorColor = new Color(0.95f, 0.75f, 0.7f);
            RenderSettings.ambientGroundColor = new Color(0.55f, 0.45f, 0.5f);
            RenderSettings.skybox = null;

            var boot = new GameObject("GameBootstrap").AddComponent<GameBootstrap>();
            boot.litTemplate = lit;
            boot.glowTemplate = glow;
            boot.unlitTemplate = unlit;
            EditorUtility.SetDirty(boot);
        }

        static void ConfigureProject()
        {
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            var sceneAsset = AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath);
            if (sceneAsset != null) EditorSceneManager.playModeStartScene = sceneAsset;

            PlayerSettings.companyName = "HoliRush Studio";
            PlayerSettings.productName = "Treasure Hunt - Holi Rush";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.holirush.treasurehunt");
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel23;
            PlayerSettings.defaultScreenWidth = 720;
            PlayerSettings.defaultScreenHeight = 1280;
            PlayerSettings.fullScreenMode = FullScreenMode.Windowed;
            PlayerSettings.resizableWindow = true;
        }

        // ------------------------------------------------------------------ validation
        public static string Validate()
        {
            var sb = new StringBuilder();
            int fails = 0;
            System.Action<bool, string> check = (ok, msg) =>
            {
                sb.AppendLine((ok ? "PASS  " : "FAIL  ") + msg);
                if (!ok) fails++;
            };
            sb.AppendLine("=== TREASURE HUNT - HOLI RUSH : project validation ===");
            sb.AppendLine("Unity " + Application.unityVersion + "   Render pipeline: " +
                          (GraphicsSettings.currentRenderPipeline != null ? GraphicsSettings.currentRenderPipeline.name : "Built-in"));

            check(File.Exists(ScenePath), "Main scene exists: " + ScenePath);
            check(EditorBuildSettings.scenes.Length > 0 && EditorBuildSettings.scenes[0].path == ScenePath, "Main scene is first in Build Settings");
            check(AssetDatabase.LoadAssetAtPath<Material>("Assets/Materials/HoliLitTemplate.mat") != null, "Lit material template exists");
            check(AssetDatabase.LoadAssetAtPath<Material>("Assets/Materials/HoliGlowTemplate.mat") != null, "Glow material template exists");
            check(AssetDatabase.LoadAssetAtPath<Material>("Assets/Materials/HoliUnlitTemplate.mat") != null, "Unlit/particle material template exists");
            check(Palette.FindLitShader() != null, "A lit shader is available (" + (Palette.FindLitShader() != null ? Palette.FindLitShader().name : "none") + ")");
            check(Shader.Find("Sprites/Default") != null, "Sprites/Default shader available for particles");
            check(Palette.BuiltinFont() != null, "Built-in UI font available");

            if (File.Exists(ScenePath))
            {
                var active = SceneManager.GetActiveScene();
                bool opened = active.path == ScenePath;
                Scene s = opened ? active : EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Additive);
                GameBootstrap boot = null;
                foreach (var root in s.GetRootGameObjects())
                {
                    boot = root.GetComponentInChildren<GameBootstrap>();
                    if (boot != null) break;
                }
                check(boot != null, "GameBootstrap present in main scene");
                if (boot != null)
                {
                    check(boot.litTemplate != null, "GameBootstrap.litTemplate assigned");
                    check(boot.glowTemplate != null, "GameBootstrap.glowTemplate assigned");
                    check(boot.unlitTemplate != null, "GameBootstrap.unlitTemplate assigned");
                    check(boot.config != null && boot.config.laneWidth > 2f, "GameConfig present with sane lane width");
                }
                if (!opened) EditorSceneManager.CloseScene(s, true);
            }

            int prefabs = AssetDatabase.FindAssets("t:Prefab", new[] { "Assets/Prefabs" }).Length;
            check(prefabs >= 40, "Generated prefabs found: " + prefabs);

            // all runtime systems compiled
            System.Type[] required =
            {
                typeof(PlayerController), typeof(GameManager), typeof(TrackGenerator), typeof(EnvironmentManager), typeof(ObstacleSpawner),
                typeof(TrainController), typeof(CollectibleManager), typeof(PowerUpManager), typeof(UIManager), typeof(AudioManager),
                typeof(ObjectPool), typeof(HoliFX), typeof(InputReader), typeof(CameraFollow)
            };
            check(required.Length == 14, "All 14 core runtime systems compiled");
            check(typeof(SaveManager) != null, "SaveManager compiled");

            sb.AppendLine(fails == 0 ? "RESULT: ALL CHECKS PASSED" : "RESULT: " + fails + " CHECK(S) FAILED");
            string text = sb.ToString();
            try
            {
                Directory.CreateDirectory("Assets/Settings");
                File.WriteAllText("Assets/Settings/ValidationReport.txt", text);
                AssetDatabase.ImportAsset("Assets/Settings/ValidationReport.txt");
            }
            catch { }
            return text;
        }
    }
}
